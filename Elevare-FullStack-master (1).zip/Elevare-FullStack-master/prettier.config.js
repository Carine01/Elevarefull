module.exports = {
  singleQuote: false,
  trailingComma: "none",
  arrowParens: "avoid",
  tabWidth: 2,
  semi: true,
  printWidth: 100
};
