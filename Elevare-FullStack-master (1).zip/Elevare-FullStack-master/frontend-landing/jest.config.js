/**
 * Configuração Jest para Testes Unitários
 * Elevare Landing Page
 * 
 * Criado em: 28/11/2025
 */

module.exports = {
    testEnvironment: 'jsdom',
    
    // Cobertura de testes
    collectCoverage: true,
    coverageDirectory: 'coverage',
    
    // Arquivos a serem testados
    collectCoverageFrom: [
        'js/**/*.js',
        '!js/**/*.min.js',
        '!js/**/*.test.js',
        '!js/**/*-supabase.js',
        '!**/node_modules/**',
        '!**/tests/**'
    ],
    
    // Thresholds de cobertura (40% mínimo - realista para fase inicial)
    coverageThreshold: {
        global: {
            branches: 40,
            functions: 40,
            lines: 40,
            statements: 40
        }
    },
    
    // Relatórios de cobertura
    coverageReporters: ['text', 'lcov', 'html'],
    
    // Setup
    setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],
    
    // Transformações
    transform: {
        '^.+\.js$': 'babel-jest'
    },
    
    // Ignorar
    testPathIgnorePatterns: [
        '/node_modules/',
        '/tests/e2e/'
    ],
    
    // Timeout
    testTimeout: 10000,
    
    // Verbose
    verbose: true
};
