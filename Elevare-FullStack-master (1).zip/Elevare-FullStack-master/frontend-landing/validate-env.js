#!/usr/bin/env node
/**
 * Script de Validação de Variáveis de Ambiente
 * Elevare Landing Page
 * 
 * Executa antes do build para garantir que todas as variáveis necessárias estão configuradas
 */

const requiredEnvVars = [
  'VITE_SUPABASE_URL',
  'VITE_SUPABASE_ANON_KEY'
];

const optionalEnvVars = [
  'VITE_ENV',
  'VITE_APP_URL'
];

console.log('🔍 Validando variáveis de ambiente...\n');

let hasErrors = false;
let hasWarnings = false;

// Verificar variáveis obrigatórias
console.log('📋 Variáveis Obrigatórias:');
requiredEnvVars.forEach(varName => {
  const value = process.env[varName];
  if (!value) {
    console.error(`❌ ${varName}: NÃO CONFIGURADA`);
    hasErrors = true;
  } else {
    // Mascarar valores sensíveis
    const maskedValue = varName.includes('KEY') 
      ? `${value.substring(0, 10)}...${value.substring(value.length - 10)}`
      : value;
    console.log(`✅ ${varName}: ${maskedValue}`);
  }
});

console.log('\n📋 Variáveis Opcionais:');
optionalEnvVars.forEach(varName => {
  const value = process.env[varName];
  if (!value) {
    console.warn(`⚠️  ${varName}: não configurada (usando padrão)`);
    hasWarnings = true;
  } else {
    console.log(`✅ ${varName}: ${value}`);
  }
});

console.log('\n' + '='.repeat(50));

if (hasErrors) {
  console.error('\n❌ VALIDAÇÃO FALHOU!');
  console.error('\nVariáveis faltando. Configure em:');
  console.error('- Local: arquivo .env na raiz do projeto');
  console.error('- Vercel: https://vercel.com/[seu-projeto]/settings/environment-variables');
  console.error('\nExemplo de .env:');
  console.error('VITE_SUPABASE_URL=https://seu-projeto.supabase.co');
  console.error('VITE_SUPABASE_ANON_KEY=***REMOVED***CI6IkpXVCJ9...');
  process.exit(1);
}

if (hasWarnings) {
  console.warn('\n⚠️  VALIDAÇÃO PASSOU COM AVISOS');
  console.warn('Algumas variáveis opcionais não estão configuradas.');
} else {
  console.log('\n✅ VALIDAÇÃO PASSOU!');
  console.log('Todas as variáveis de ambiente estão configuradas corretamente.');
}

process.exit(0);
