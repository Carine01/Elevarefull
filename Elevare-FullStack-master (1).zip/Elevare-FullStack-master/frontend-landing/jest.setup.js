/**
 * Configuração de Mocks Globais para Jest
 * Elevare Landing Page
 * 
 * Este arquivo configura todos os mocks necessários para os testes unitários
 * funcionarem sem erros de ReferenceError (document, window, localStorage, etc.)
 */

// ========================================
// MOCK DO DOM
// ========================================

global.document = {
  referrer: 'https://google.com',
  
  createElement: jest.fn((tagName) => ({
    tagName: tagName.toUpperCase(),
    setAttribute: jest.fn(),
    getAttribute: jest.fn(),
    appendChild: jest.fn(),
    removeChild: jest.fn(),
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    click: jest.fn(),
    focus: jest.fn(),
    blur: jest.fn(),
    style: {},
    classList: {
      add: jest.fn(),
      remove: jest.fn(),
      toggle: jest.fn(),
      contains: jest.fn(() => false)
    }
  })),
  
  getElementById: jest.fn((id) => ({
    id,
    innerHTML: '',
    textContent: '',
    value: '',
    style: {},
    classList: {
      add: jest.fn(),
      remove: jest.fn(),
      toggle: jest.fn()
    },
    addEventListener: jest.fn(),
    removeEventListener: jest.fn()
  })),
  
  querySelector: jest.fn((selector) => ({
    selector,
    innerHTML: '',
    textContent: '',
    value: '',
    style: {},
    classList: {
      add: jest.fn(),
      remove: jest.fn()
    },
    addEventListener: jest.fn()
  })),
  
  querySelectorAll: jest.fn(() => []),
  
  body: {
    appendChild: jest.fn(),
    removeChild: jest.fn(),
    innerHTML: '',
    classList: {
      add: jest.fn(),
      remove: jest.fn()
    }
  },
  
  head: {
    appendChild: jest.fn(),
    removeChild: jest.fn()
  },
  
  cookie: ''
};

// ========================================
// MOCK DO WINDOW
// ========================================

global.window = {
  screen: {
    width: 1920,
    height: 1080,
    availWidth: 1920,
    availHeight: 1040
  },
  
  location: {
    href: 'https://elevare-landing.vercel.app',
    protocol: 'https:',
    host: 'elevare-landing.vercel.app',
    hostname: 'elevare-landing.vercel.app',
    port: '',
    pathname: '/',
    search: '',
    hash: '',
    origin: 'https://elevare-landing.vercel.app',
    reload: jest.fn(),
    replace: jest.fn(),
    assign: jest.fn()
  },
  
  history: {
    pushState: jest.fn(),
    replaceState: jest.fn(),
    back: jest.fn(),
    forward: jest.fn(),
    go: jest.fn()
  },
  
  addEventListener: jest.fn(),
  removeEventListener: jest.fn(),
  
  setTimeout: jest.fn((callback, delay) => {
    return setTimeout(callback, delay);
  }),
  
  clearTimeout: jest.fn((id) => {
    clearTimeout(id);
  }),
  
  setInterval: jest.fn((callback, delay) => {
    return setInterval(callback, delay);
  }),
  
  clearInterval: jest.fn((id) => {
    clearInterval(id);
  }),
  
  requestAnimationFrame: jest.fn((callback) => {
    return setTimeout(callback, 16);
  }),
  
  cancelAnimationFrame: jest.fn((id) => {
    clearTimeout(id);
  }),
  
  alert: jest.fn(),
  confirm: jest.fn(() => true),
  prompt: jest.fn(() => 'test'),
  
  open: jest.fn(),
  close: jest.fn(),
  
  scrollTo: jest.fn(),
  scrollBy: jest.fn(),
  
  getComputedStyle: jest.fn(() => ({
    getPropertyValue: jest.fn(() => '')
  }))
};

// ========================================
// MOCK DO NAVIGATOR
// ========================================

global.navigator = {
  userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  language: 'pt-BR',
  languages: ['pt-BR', 'pt', 'en-US', 'en'],
  platform: 'Win32',
  vendor: 'Google Inc.',
  onLine: true,
  cookieEnabled: true,
  
  geolocation: {
    getCurrentPosition: jest.fn((success) => {
      success({
        coords: {
          latitude: -20.3155,
          longitude: -40.3128,
          accuracy: 100
        }
      });
    }),
    watchPosition: jest.fn()
  },
  
  clipboard: {
    writeText: jest.fn(() => Promise.resolve()),
    readText: jest.fn(() => Promise.resolve(''))
  }
};

// ========================================
// MOCK DO LOCALSTORAGE
// ========================================

const localStorageMock = (() => {
  let store = {
    'pageViews': '[]',
    'leadData': '{}',
    'sessionStart': Date.now().toString()
  };

  return {
    getItem: jest.fn((key) => {
      return store[key] || null;
    }),
    
    setItem: jest.fn((key, value) => {
      store[key] = value.toString();
    }),
    
    removeItem: jest.fn((key) => {
      delete store[key];
    }),
    
    clear: jest.fn(() => {
      store = {};
    }),
    
    get length() {
      return Object.keys(store).length;
    },
    
    key: jest.fn((index) => {
      const keys = Object.keys(store);
      return keys[index] || null;
    }),
    
    // Helper para testes
    _reset: () => {
      store = {
        'pageViews': '[]',
        'leadData': '{}',
        'sessionStart': Date.now().toString()
      };
    }
  };
})();

global.localStorage = localStorageMock;

// ========================================
// MOCK DO SESSIONSTORAGE
// ========================================

const sessionStorageMock = (() => {
  let store = {
    'pageLoadTime': Date.now().toString(),
    'scrollDepth': '0'
  };

  return {
    getItem: jest.fn((key) => {
      return store[key] || null;
    }),
    
    setItem: jest.fn((key, value) => {
      store[key] = value.toString();
    }),
    
    removeItem: jest.fn((key) => {
      delete store[key];
    }),
    
    clear: jest.fn(() => {
      store = {};
    }),
    
    get length() {
      return Object.keys(store).length;
    },
    
    key: jest.fn((index) => {
      const keys = Object.keys(store);
      return keys[index] || null;
    }),
    
    // Helper para testes
    _reset: () => {
      store = {
        'pageLoadTime': Date.now().toString(),
        'scrollDepth': '0'
      };
    }
  };
})();

global.sessionStorage = sessionStorageMock;

// ========================================
// MOCK DO INTL (TIMEZONE)
// ========================================

global.Intl = {
  DateTimeFormat: jest.fn(() => ({
    resolvedOptions: () => ({
      timeZone: 'America/Sao_Paulo',
      locale: 'pt-BR'
    }),
    format: jest.fn((date) => date.toLocaleDateString('pt-BR'))
  })),
  
  NumberFormat: jest.fn(() => ({
    format: jest.fn((number) => number.toLocaleString('pt-BR'))
  }))
};

// ========================================
// MOCK DO JSON.PARSE (PARA TESTES DE EDGE CASES)
// ========================================

const originalParse = JSON.parse;
global.JSON.parse = jest.fn((str) => {
  // Simular erro para strings inválidas
  if (str === 'invalid json' || str === '{invalid}') {
    throw new SyntaxError('Unexpected token i in JSON at position 0');
  }
  return originalParse(str);
});

// ========================================
// MOCK DO FETCH API
// ========================================

global.fetch = jest.fn((url, options) => {
  // Mock de resposta padrão
  return Promise.resolve({
    ok: true,
    status: 200,
    statusText: 'OK',
    json: () => Promise.resolve({ data: [], error: null }),
    text: () => Promise.resolve(''),
    blob: () => Promise.resolve(new Blob()),
    headers: new Map(),
    url: url
  });
});

// ========================================
// MOCK DO CONSOLE (PARA EVITAR POLUIÇÃO NOS LOGS)
// ========================================

// Salvar console original
const originalConsole = { ...console };

// Silenciar console.error e console.warn em testes (opcional)
global.console = {
  ...console,
  error: jest.fn((...args) => {
    // Descomentar para debug:
    // originalConsole.error(...args);
  }),
  warn: jest.fn((...args) => {
    // Descomentar para debug:
    // originalConsole.warn(...args);
  })
};

// ========================================
// HELPERS PARA TESTES
// ========================================

// Reset de todos os mocks entre testes
beforeEach(() => {
  localStorage._reset();
  sessionStorage._reset();
  jest.clearAllMocks();
});

// Cleanup após todos os testes
afterAll(() => {
  jest.restoreAllMocks();
});

// ========================================
// EXPORTS (SE NECESSÁRIO)
// ========================================

module.exports = {
  localStorageMock,
  sessionStorageMock
};
