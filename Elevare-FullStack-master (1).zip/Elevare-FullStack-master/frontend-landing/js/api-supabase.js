// 🎯 Elevare Supabase API - Fase 1
// Integração completa com Supabase para autenticação e captura de leads

class ElevareSupabase {
  constructor() {
    // Carrega variáveis de ambiente do .env
    this.SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
    this.SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

    // Validação de credenciais
    if (!this.SUPABASE_URL || !this.SUPABASE_ANON_KEY) {
      console.error("❌ Credenciais Supabase não encontradas no .env");
      console.error("Certifique-se de que o arquivo .env existe e contém:");
      console.error("VITE_SUPABASE_URL=https://seu-projeto.supabase.co");
      console.error("VITE_SUPABASE_ANON_KEY=sua-chave-aqui");
      alert("Erro: Configure o arquivo .env com as credenciais do Supabase");
      return;
    }

    // Headers padrão para requisições
    this.headers = {
      apikey: this.SUPABASE_ANON_KEY,
      "Content-Type": "application/json"
    };

    console.log("✅ Supabase API inicializada");
    console.log("📍 URL:", this.SUPABASE_URL);
  }

  // ========================================
  // LEADS
  // ========================================

  /**
   * 🔥 CRITÉRIO DE VALIDAÇÃO 1: Captura de Lead
   * Cria um novo lead no Supabase
   * @param {string} email - E-mail do lead
   * @param {string} name - Nome do lead (opcional)
   * @param {object} metadata - Dados adicionais (score, milestones, etc.)
   * @returns {Promise<object>} Lead criado
   */
  async createLead(email, name = null, metadata = {}) {
    try {
      const leadData = {
        email,
        name: name || email.split("@")[0],
        metadata,
        user_agent: navigator.userAgent,
        referrer: document.referrer || "direct",
        screen_resolution: `${window.screen.width}x${window.screen.height}`,
        language: navigator.language,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
      };

      console.log("📤 Enviando lead para Supabase:", leadData);

      const response = await fetch(`${this.SUPABASE_URL}/rest/v1/leads`, {
        method: "POST",
        headers: {
          ...this.headers,
          Prefer: "return=representation"
        },
        body: JSON.stringify(leadData)
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Falha ao criar lead");
      }

      const [lead] = await response.json();
      console.log("✅ Lead criado com sucesso:", lead);

      // Remove leads pendentes do localStorage (se houver)
      this.clearPendingLeads();

      return lead;
    } catch (error) {
      console.error("❌ Erro ao criar lead:", error);

      // Fallback: Salva localmente para retry posterior
      this.storeLeadLocally(email, name, metadata);

      throw error;
    }
  }

  /**
   * Salva lead localmente quando offline ou erro
   */
  storeLeadLocally(email, name, metadata) {
    try {
      const pending = JSON.parse(localStorage.getItem("pendingLeads") || "[]");
      pending.push({
        email,
        name,
        metadata,
        timestamp: new Date().toISOString(),
        user_agent: navigator.userAgent,
        referrer: document.referrer || "direct"
      });
      localStorage.setItem("pendingLeads", JSON.stringify(pending));
      console.log("💾 Lead salvo localmente (modo offline)");
    } catch (err) {
      console.error("❌ Erro ao salvar lead localmente:", err);
    }
  }

  /**
   * Limpa leads pendentes do localStorage
   */
  clearPendingLeads() {
    try {
      localStorage.removeItem("pendingLeads");
    } catch (err) {
      console.error("❌ Erro ao limpar leads pendentes:", err);
    }
  }

  /**
   * Busca leads (requer autenticação)
   */
  async getLeads(limit = 10) {
    try {
      const token = localStorage.getItem("elev_token");

      const response = await fetch(
        `${this.SUPABASE_URL}/rest/v1/leads?order=created_at.desc&limit=${limit}`,
        {
          method: "GET",
          headers: {
            ...this.headers,
            ...(token && { Authorization: `Bearer ${token}` })
          }
        }
      );

      if (!response.ok) {
        throw new Error("Falha ao buscar leads");
      }

      return response.json();
    } catch (error) {
      console.error("❌ Erro ao buscar leads:", error);
      throw error;
    }
  }

  // ========================================
  // AUTENTICAÇÃO
  // ========================================

  /**
   * 🔥 CRITÉRIO DE VALIDAÇÃO 2: Registro de Usuário
   * Registra um novo usuário no Supabase Auth
   * @param {string} email - E-mail do usuário
   * @param {string} password - Senha do usuário
   * @param {string} name - Nome do usuário
   * @returns {Promise<object>} Dados do usuário registrado
   */
  async register(email, password, name) {
    try {
      console.log("📤 Registrando usuário:", email);

      const response = await fetch(`${this.SUPABASE_URL}/auth/v1/signup`, {
        method: "POST",
        headers: this.headers,
        body: JSON.stringify({
          email,
          password,
          data: { name }
        })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.msg || error.error_description || "Erro no registro");
      }

      const data = await response.json();
      console.log("✅ Registro bem-sucedido:", data);

      // Salva sessão
      if (data.access_token) {
        localStorage.setItem("elev_token", data.access_token);
        localStorage.setItem("elev_user", JSON.stringify(data.user));
      }

      // Cria lead automaticamente
      await this.createLead(email, name, { source: "registration", score: 100 });

      return data;
    } catch (error) {
      console.error("❌ Erro no registro:", error);
      throw error;
    }
  }

  /**
   * 🔥 CRITÉRIO DE VALIDAÇÃO 3: Login
   * Faz login de um usuário existente
   * @param {string} email - E-mail do usuário
   * @param {string} password - Senha do usuário
   * @returns {Promise<object>} Dados da sessão
   */
  async login(email, password) {
    try {
      console.log("📤 Fazendo login:", email);

      const response = await fetch(`${this.SUPABASE_URL}/auth/v1/token?grant_type=password`, {
        method: "POST",
        headers: this.headers,
        body: JSON.stringify({ email, password })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error_description || error.msg || "Erro no login");
      }

      const data = await response.json();
      console.log("✅ Login bem-sucedido:", data);

      // Salva sessão
      localStorage.setItem("elev_token", data.access_token);
      localStorage.setItem("elev_user", JSON.stringify(data.user));

      return data;
    } catch (error) {
      console.error("❌ Erro no login:", error);
      throw error;
    }
  }

  /**
   * 🔥 CRITÉRIO DE VALIDAÇÃO 4: Verificar sessão
   * Verifica se o usuário está autenticado
   * @returns {Promise<object|null>} Dados do usuário ou null
   */
  async getUser() {
    const token = localStorage.getItem("elev_token");
    if (!token) return null;

    try {
      const response = await fetch(`${this.SUPABASE_URL}/auth/v1/user`, {
        method: "GET",
        headers: {
          ...this.headers,
          Authorization: `Bearer ${token}`
        }
      });

      if (!response.ok) {
        // Token inválido ou expirado
        this.logout();
        return null;
      }

      const user = await response.json();
      console.log("✅ Usuário autenticado:", user);
      return user;
    } catch (error) {
      console.error("❌ Erro ao verificar sessão:", error);
      this.logout();
      return null;
    }
  }

  /**
   * Faz logout do usuário
   */
  logout() {
    localStorage.removeItem("elev_token");
    localStorage.removeItem("elev_user");
    console.log("✅ Logout realizado");
  }

  /**
   * Verifica se o usuário está autenticado
   * @returns {boolean}
   */
  isAuthenticated() {
    return !!localStorage.getItem("elev_token");
  }
}

// ========================================
// EXPORTAÇÃO GLOBAL
// ========================================
// Cria instância global para uso em toda a aplicação
window.elevareAPI = new ElevareSupabase();

// Exporta para módulos ES6 (se necessário)
export default ElevareSupabase;
