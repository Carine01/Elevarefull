// Frontend Integration - Exemplo de integração com API IARA
// JavaScript para dashboard e portal do cliente

class IARAApiClient {
  constructor(baseUrl, authToken) {
    this.baseUrl = baseUrl;
    this.authToken = authToken;
    
    // Configurar interceptores para todas as requisições
    this.setupInterceptors();
  }
  
  setupInterceptors() {
    // Adicionar token de autenticação em todas as requisições
    this.authenticatedFetch = async (url, options = {}) => {
      const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.authToken}`,
        ...options.headers
      };
      
      try {
        const response = await fetch(`${this.baseUrl}${url}`, {
          ...options,
          headers
        });
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return await response.json();
      } catch (error) {
        console.error('API request failed:', error);
        throw error;
      }
    };
  }
  
  // Templates API
  async getTemplates() {
    return this.authenticatedFetch('/api/v1/templates');
  }
  
  async createTemplate(templateData) {
    return this.authenticatedFetch('/api/v1/templates', {
      method: 'POST',
      body: JSON.stringify(templateData)
    });
  }
  
  async updateTemplate(id, templateData) {
    return this.authenticatedFetch(`/api/v1/templates/${id}`, {
      method: 'PUT',
      body: JSON.stringify(templateData)
    });
  }
  
  async deleteTemplate(id) {
    return this.authenticatedFetch(`/api/v1/templates/${id}`, {
      method: 'DELETE'
    });
  }
  
  async optimizeTemplate(id) {
    return this.authenticatedFetch(`/api/v1/templates/${id}/optimize`, {
      method: 'POST'
    });
  }
  
  // Leads API
  async getLeads(filters = {}) {
    const queryParams = new URLSearchParams(filters);
    return this.authenticatedFetch(`/api/v1/leads?${queryParams}`);
  }
  
  async getLead(id) {
    return this.authenticatedFetch(`/api/v1/leads/${id}`);
  }
  
  async updateLead(id, leadData) {
    return this.authenticatedFetch(`/api/v1/leads/${id}`, {
      method: 'PUT',
      body: JSON.stringify(leadData)
    });
  }
  
  // WhatsApp API
  async sendWhatsAppMessage(templateId, leadId, variables) {
    return this.authenticatedFetch('/api/v1/whatsapp/send', {
      method: 'POST',
      body: JSON.stringify({
        templateId,
        leadId,
        variables
      })
    });
  }
  
  async getWhatsAppStatus() {
    return this.authenticatedFetch('/api/v1/whatsapp/status');
  }
  
  // Analytics API
  async getAnalytics(params) {
    const queryParams = new URLSearchParams(params);
    return this.authenticatedFetch(`/api/v1/analytics/leads?${queryParams}`);
  }
  
  async getCampaignPerformance(campaignId) {
    return this.authenticatedFetch(`/api/v1/analytics/campaigns/${campaignId}`);
  }
  
  async getFunnelData(params) {
    const queryParams = new URLSearchParams(params);
    return this.authenticatedFetch(`/api/v1/analytics/funnel?${queryParams}`);
  }
}

// Classe para gerenciar o estado do dashboard
class IARADashboard {
  constructor(apiClient) {
    this.api = apiClient;
    this.templates = [];
    this.leads = [];
    this.analytics = {};
    this.isLoading = false;
    
    this.initializeDashboard();
  }
  
  async initializeDashboard() {
    try {
      this.showLoading();
      
      // Carregar dados iniciais
      await Promise.all([
        this.loadTemplates(),
        this.loadLeads(),
        this.loadAnalytics()
      ]);
      
      this.renderDashboard();
      this.setupEventListeners();
      
    } catch (error) {
      console.error('Erro ao inicializar dashboard:', error);
      this.showError('Erro ao carregar dados do dashboard');
    } finally {
      this.hideLoading();
    }
  }
  
  async loadTemplates() {
    try {
      this.templates = await this.api.getTemplates();
    } catch (error) {
      console.error('Erro ao carregar templates:', error);
      throw error;
    }
  }
  
  async loadLeads(filters = {}) {
    try {
      this.leads = await this.api.getLeads(filters);
    } catch (error) {
      console.error('Erro ao carregar leads:', error);
      throw error;
    }
  }
  
  async loadAnalytics() {
    try {
      const endDate = new Date();
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - 30);
      
      this.analytics = await this.api.getAnalytics({
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString()
      });
    } catch (error) {
      console.error('Erro ao carregar analytics:', error);
      throw error;
    }
  }
  
  renderDashboard() {
    // Renderizar templates
    this.renderTemplates();
    
    // Renderizar leads
    this.renderLeads();
    
    // Renderizar gráficos de analytics
    this.renderAnalytics();
  }
  
  renderTemplates() {
    const container = document.getElementById('templates-container');
    if (!container) return;
    
    container.innerHTML = this.templates.map(template => `
      <div class="template-card" data-template-id="${template.id}">
        <h3>${template.name}</h3>
        <p class="category">${template.category}</p>
        <p class="content-preview">${template.content.substring(0, 100)}...</p>
        <div class="template-actions">
          <button class="btn-edit" onclick="dashboard.editTemplate('${template.id}')">
            Editar
          </button>
          <button class="btn-optimize" onclick="dashboard.optimizeTemplate('${template.id}')">
            Otimizar com IARA
          </button>
          <button class="btn-delete" onclick="dashboard.deleteTemplate('${template.id}')">
            Excluir
          </button>
        </div>
      </div>
    `).join('');
  }
  
  renderLeads() {
    const container = document.getElementById('leads-container');
    if (!container) return;
    
    container.innerHTML = this.leads.map(lead => `
      <tr class="lead-row" data-lead-id="${lead.id}">
        <td>${lead.name}</td>
        <td>${lead.email || '-'}</td>
        <td>${lead.phone || '-'}</td>
        <td>
          <span class="stage-badge stage-${lead.stage}">
            ${lead.stage}
          </span>
        </td>
        <td>
          <span class="score-badge score-${lead.score > 60 ? 'high' : lead.score > 30 ? 'medium' : 'low'}">
            ${lead.score}
          </span>
        </td>
        <td>
          <button class="btn-send-message" onclick="dashboard.sendMessage('${lead.id}')">
            Enviar Mensagem
          </button>
        </td>
      </tr>
    `).join('');
  }
  
  renderAnalytics() {
    // Renderizar gráficos usando Chart.js ou similar
    if (this.analytics.length === 0) return;
    
    const ctx = document.getElementById('analytics-chart');
    if (!ctx) return;
    
    // Dados para o gráfico de leads ao longo do tempo
    const labels = this.analytics.map(item => item.date);
    const totalLeads = this.analytics.map(item => item.total_leads);
    const convertedLeads = this.analytics.map(item => item.converted_leads);
    
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Total de Leads',
          data: totalLeads,
          borderColor: 'rgb(75, 192, 192)',
          tension: 0.1
        }, {
          label: 'Leads Convertidos',
          data: convertedLeads,
          borderColor: 'rgb(255, 99, 132)',
          tension: 0.1
        }]
      },
      options: {
        responsive: true,
        plugins: {
          title: {
            display: true,
            text: 'Performance dos Leads (Últimos 30 dias)'
          }
        }
      }
    });
  }
  
  setupEventListeners() {
    // Filtros de leads
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const filter = e.target.dataset.filter;
        this.filterLeads(filter);
      });
    });
    
    // Busca de templates
    const searchInput = document.getElementById('template-search');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.searchTemplates(e.target.value);
      });
    }
  }
  
  async editTemplate(templateId) {
    try {
      const template = this.templates.find(t => t.id === templateId);
      if (!template) return;
      
      // Abrir modal de edição
      this.openEditModal(template);
    } catch (error) {
      console.error('Erro ao editar template:', error);
      this.showError('Erro ao editar template');
    }
  }
  
  async optimizeTemplate(templateId) {
    try {
      this.showLoading();
      
      const result = await this.api.optimizeTemplate(templateId);
      
      // Atualizar template na lista
      const index = this.templates.findIndex(t => t.id === templateId);
      if (index !== -1) {
        this.templates[index] = result;
        this.renderTemplates();
      }
      
      this.showSuccess('Template otimizado com sucesso!');
    } catch (error) {
      console.error('Erro ao otimizar template:', error);
      this.showError('Erro ao otimizar template');
    } finally {
      this.hideLoading();
    }
  }
  
  async deleteTemplate(templateId) {
    if (!confirm('Tem certeza que deseja excluir este template?')) {
      return;
    }
    
    try {
      await this.api.deleteTemplate(templateId);
      
      // Remover da lista
      this.templates = this.templates.filter(t => t.id !== templateId);
      this.renderTemplates();
      
      this.showSuccess('Template excluído com sucesso!');
    } catch (error) {
      console.error('Erro ao excluir template:', error);
      this.showError('Erro ao excluir template');
    }
  }
  
  async sendMessage(leadId) {
    try {
      // Abrir modal de seleção de template
      const templateId = await this.selectTemplateModal();
      if (!templateId) return;
      
      const variables = await this.getTemplateVariables(templateId);
      
      const result = await this.api.sendWhatsAppMessage(templateId, leadId, variables);
      
      this.showSuccess('Mensagem enviada com sucesso!');
    } catch (error) {
      console.error('Erro ao enviar mensagem:', error);
      this.showError('Erro ao enviar mensagem');
    }
  }
  
  // Métodos de UI
  showLoading() {
    this.isLoading = true;
    const loader = document.getElementById('loading-overlay');
    if (loader) {
      loader.style.display = 'flex';
    }
  }
  
  hideLoading() {
    this.isLoading = false;
    const loader = document.getElementById('loading-overlay');
    if (loader) {
      loader.style.display = 'none';
    }
  }
  
  showError(message) {
    this.showNotification(message, 'error');
  }
  
  showSuccess(message) {
    this.showNotification(message, 'success');
  }
  
  showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.remove();
    }, 5000);
  }
}

// Inicialização do dashboard
let dashboard;

document.addEventListener('DOMContentLoaded', () => {
  // Obter token de autenticação do SaaS Elevare
  const authToken = localStorage.getItem('elevare_auth_token');
  if (!authToken) {
    // Redirecionar para login do SaaS
    window.location.href = '/login';
    return;
  }
  
  // Criar cliente API
  const apiClient = new IARAApiClient('/api', authToken);
  
  // Inicializar dashboard
  dashboard = new IARADashboard(apiClient);
});

// Exportar para uso em outros módulos
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { IARAApiClient, IARADashboard };
}