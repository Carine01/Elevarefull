/**
 * Onboarding Progress Bar
 * Barra de progresso visual que indica engajamento do lead
 *
 * Criado em: 28/11/2025
 * Baseado em: Plano de Ação Estratégico - Gamificação
 */

/**
 * Inicializa a barra de progresso de onboarding
 */
function initOnboardingProgress() {
  // Cria elemento da barra de progresso se não existir
  if (!document.getElementById("onboarding-progress")) {
    const progressBar = document.createElement("div");
    progressBar.id = "onboarding-progress";
    progressBar.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            height: 3px;
            background: linear-gradient(90deg, #667eea, #764ba2);
            width: 0%;
            z-index: 9999;
            transition: width 0.5s ease-out;
            box-shadow: 0 0 10px rgba(102, 126, 234, 0.5);
        `;
    document.body.insertBefore(progressBar, document.body.firstChild);
  }
}

/**
 * Atualiza a barra de progresso baseado nos milestones do LeadTracker
 */
function updateOnboardingProgress() {
  if (window.leadTracker) {
    const { milestones } = window.leadTracker;
    const completed = Object.values(milestones).filter(Boolean).length;
    const total = Object.keys(milestones).length;
    const progress = (completed / total) * 100;

    const progressBar = document.getElementById("onboarding-progress");
    if (progressBar) {
      progressBar.style.width = `${progress}%`;

      // Adiciona efeito de pulso quando completa
      if (progress === 100) {
        progressBar.style.animation = "pulse 1s ease-in-out 3";
      }
    }
  }
}

// Adiciona CSS de animação
const style = document.createElement("style");
style.textContent = `
    @keyframes pulse {
        0%, 100% {
            opacity: 1;
            box-shadow: 0 0 10px rgba(102, 126, 234, 0.5);
        }
        50% {
            opacity: 0.8;
            box-shadow: 0 0 20px rgba(102, 126, 234, 0.8);
        }
    }
`;
document.head.appendChild(style);

// Inicializa quando DOM estiver pronto
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initOnboardingProgress);
} else {
  initOnboardingProgress();
}

// Expõe globalmente
window.initOnboardingProgress = initOnboardingProgress;
window.updateOnboardingProgress = updateOnboardingProgress;
