/**
 * Lead Tracker - Sistema de Rastreamento de Comportamento
 * Rastreia interações do usuário para qualificar leads
 *
 * Criado em: 28/11/2025
 * Baseado em: Plano de Ação Estratégico
 */

class LeadTracker {
  constructor() {
    this.leadId = this.getOrCreateLeadId();
    this.pageLoadTime = Date.now();
    this.milestones = {
      "scroll-50": false,
      "form-focus": false,
      "plan-open": false,
      "time-30s": false,
      "time-60s": false
    };

    this.init();
  }

  /**
   * Inicializa o tracker
   */
  init() {
    this.trackPageView();
    this.setupEventListeners();
    this.startTimeTracking();
    console.log("🎯 Lead Tracker inicializado:", this.leadId);
  }

  /**
   * Obtém ou cria ID único do lead
   * @returns {string} Lead ID
   */
  getOrCreateLeadId() {
    let leadId = localStorage.getItem("leadId");
    if (!leadId) {
      leadId = `lead_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem("leadId", leadId);
      localStorage.setItem("leadCreatedAt", new Date().toISOString());
    }
    return leadId;
  }

  /**
   * Registra visualização de página
   */
  trackPageView() {
    const pages = JSON.parse(localStorage.getItem("pageViews") || "[]");
    pages.push({
      page: window.location.pathname,
      time: Date.now(),
      title: document.title,
      referrer: document.referrer
    });
    localStorage.setItem("pageViews", JSON.stringify(pages));

    // Incrementa contador de visitas
    const visits = parseInt(sessionStorage.getItem("pageVisits") || "0") + 1;
    sessionStorage.setItem("pageVisits", visits);
  }

  /**
   * Configura event listeners para tracking
   */
  setupEventListeners() {
    // Tracking de scroll
    window.addEventListener("scroll", () => this.trackScroll());

    // Tracking de foco em formulário
    const leadEmail = document.getElementById("lead-email");
    if (leadEmail) {
      leadEmail.addEventListener("focus", () => this.trackMilestone("form-focus"));
    }

    // Tracking de abertura de modal de planos
    // (será chamado externamente quando modal abrir)
    window.trackPlanModalOpen = () => this.trackMilestone("plan-open");
  }

  /**
   * Rastreia scroll da página
   */
  trackScroll() {
    const scrollPercent =
      (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;

    if (scrollPercent > 50 && !this.milestones["scroll-50"]) {
      this.trackMilestone("scroll-50");
    }
  }

  /**
   * Registra milestone alcançado
   * @param {string} milestone - Nome do milestone
   */
  trackMilestone(milestone) {
    if (!this.milestones[milestone]) {
      this.milestones[milestone] = true;
      this.updateProgress();

      console.log("✅ Milestone alcançado:", milestone);

      // Salva no localStorage
      const milestones = JSON.parse(localStorage.getItem("milestones") || "{}");
      milestones[milestone] = {
        achieved: true,
        timestamp: new Date().toISOString()
      };
      localStorage.setItem("milestones", JSON.stringify(milestones));
    }
  }

  /**
   * Inicia tracking de tempo na página
   */
  startTimeTracking() {
    // Marca milestone de 30 segundos
    setTimeout(() => {
      this.trackMilestone("time-30s");
    }, 30000);

    // Marca milestone de 60 segundos
    setTimeout(() => {
      this.trackMilestone("time-60s");
    }, 60000);
  }

  /**
   * Atualiza barra de progresso de onboarding
   */
  updateProgress() {
    const completed = Object.values(this.milestones).filter(Boolean).length;
    const total = Object.keys(this.milestones).length;
    const progress = (completed / total) * 100;

    const progressBar = document.getElementById("onboarding-progress");
    if (progressBar) {
      progressBar.style.width = `${progress}%`;
    }

    // Se completou todos os milestones, marca como lead de alta intenção
    if (progress === 100) {
      this.markAsHighIntentLead();
    }
  }

  /**
   * Marca lead como alta intenção
   */
  markAsHighIntentLead() {
    localStorage.setItem("highIntentLead", "true");
    localStorage.setItem("highIntentTimestamp", new Date().toISOString());

    console.log("🔥 Lead de alta intenção identificado!");

    // Envia evento para analytics (se configurado)
    if (window.gtag) {
      gtag("event", "high_intent_lead", {
        lead_id: this.leadId,
        score: this.getLeadScore()
      });
    }
  }

  /**
   * Calcula score do lead baseado em comportamento
   * @returns {number} Score de 0 a 100
   */
  getLeadScore() {
    const pages = JSON.parse(localStorage.getItem("pageViews") || "[]");
    const visits = parseInt(sessionStorage.getItem("pageVisits") || "0");
    const milestonesCompleted = Object.values(this.milestones).filter(Boolean).length;
    const timeOnPage = Math.floor((Date.now() - this.pageLoadTime) / 1000);

    // Cálculo de score
    let score = 0;

    // Pontos por visualizações de página (max 20)
    score += Math.min(20, pages.length * 5);

    // Pontos por visitas (max 20)
    score += Math.min(20, visits * 4);

    // Pontos por milestones (max 30)
    score += (milestonesCompleted / Object.keys(this.milestones).length) * 30;

    // Pontos por tempo na página (max 30)
    score += Math.min(30, (timeOnPage / 120) * 30); // 2 minutos = 30 pontos

    return Math.min(100, Math.round(score));
  }

  /**
   * Obtém dados completos do lead para envio
   * @returns {object} Dados do lead
   */
  getLeadData() {
    return {
      leadId: this.leadId,
      score: this.getLeadScore(),
      milestones: this.milestones,
      pageViews: JSON.parse(localStorage.getItem("pageViews") || "[]"),
      visits: parseInt(sessionStorage.getItem("pageVisits") || "0"),
      timeOnPage: Math.floor((Date.now() - this.pageLoadTime) / 1000),
      userAgent: navigator.userAgent,
      referrer: document.referrer,
      screenResolution: `${window.screen.width}x${window.screen.height}`,
      language: navigator.language,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      createdAt: localStorage.getItem("leadCreatedAt"),
      highIntent: localStorage.getItem("highIntentLead") === "true"
    };
  }

  /**
   * Limpa dados do lead (útil para testes)
   */
  clearLeadData() {
    localStorage.removeItem("leadId");
    localStorage.removeItem("leadCreatedAt");
    localStorage.removeItem("pageViews");
    localStorage.removeItem("milestones");
    localStorage.removeItem("highIntentLead");
    localStorage.removeItem("highIntentTimestamp");
    sessionStorage.removeItem("pageVisits");

    console.log("🗑️ Dados do lead limpos");
  }
}

// Inicializa automaticamente quando DOM estiver pronto
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    window.leadTracker = new LeadTracker();
  });
} else {
  window.leadTracker = new LeadTracker();
}

// Expõe globalmente para debug
window.LeadTracker = LeadTracker;
