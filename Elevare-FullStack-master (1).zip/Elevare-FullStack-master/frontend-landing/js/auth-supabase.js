// 🎯 Elevare Auth System - Fase 1
// Sistema de autenticação integrado com Supabase

class ElevareAuth {
  constructor() {
    this.token = localStorage.getItem("elev_token");
    this.user = null;
    this.init();
  }

  async init() {
    console.log("🔐 Inicializando sistema de autenticação...");

    // Verifica sessão ao carregar
    if (this.token) {
      this.user = await window.elevareAPI.getUser();
      this.updateUI();
    }

    // Aguarda DOM carregar
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => this.setupAuthModal());
    } else {
      this.setupAuthModal();
    }
  }

  setupAuthModal() {
    // Cria modal se não existir
    if (document.getElementById("auth-modal")) {
      console.log("✅ Modal de autenticação já existe");
      this.attachEventListeners();
      return;
    }

    const modalHTML = `
            <div id="auth-modal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden transition-opacity duration-300">
                <div class="bg-white rounded-3xl p-8 max-w-md w-full mx-4 transform transition-transform duration-300">
                    <div class="text-center mb-6">
                        <div class="w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4">
                            <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                        </div>
                        <h3 id="auth-modal-title" class="text-2xl font-bold text-gray-900">Entrar na Elevare</h3>
                        <p id="auth-modal-subtitle" class="text-sm text-gray-600 mt-2">Acesse sua conta ou crie uma nova</p>
                    </div>

                    <form id="auth-form" class="space-y-4">
                        <input type="hidden" id="auth-mode" value="login">
                        
                        <div id="name-field" class="hidden">
                            <label class="block text-sm font-medium text-gray-700 mb-1">Nome Completo</label>
                            <input type="text" id="auth-name" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all" placeholder="Seu nome completo">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">E-mail</label>
                            <input type="email" id="auth-email" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all" placeholder="seu@email.com">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Senha</label>
                            <input type="password" id="auth-password" required minlength="6" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all" placeholder="••••••••">
                            <p class="text-xs text-gray-500 mt-1">Mínimo 6 caracteres</p>
                        </div>

                        <div id="auth-error" class="hidden p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600"></div>
                        <div id="auth-success" class="hidden p-3 bg-green-50 border border-green-200 rounded-lg text-sm text-green-600"></div>

                        <button type="submit" id="auth-submit" class="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-xl font-medium hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed">
                            <span id="auth-submit-text">Entrar</span>
                            <span id="auth-submit-loading" class="hidden">
                                <svg class="animate-spin inline-block w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Processando...
                            </span>
                        </button>
                    </form>

                    <div class="text-center mt-4">
                        <button type="button" id="auth-toggle" class="text-purple-600 text-sm font-medium hover:underline transition-all">
                            Não tem conta? Criar conta
                        </button>
                    </div>

                    <button id="auth-close" class="absolute top-4 right-4 p-2 text-gray-400 hover:text-gray-600 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>
            </div>
        `;

    document.body.insertAdjacentHTML("beforeend", modalHTML);
    console.log("✅ Modal de autenticação criado");

    this.attachEventListeners();
  }

  attachEventListeners() {
    // Event Listeners
    const toggleBtn = document.getElementById("auth-toggle");
    const form = document.getElementById("auth-form");
    const closeBtn = document.getElementById("auth-close");
    const modal = document.getElementById("auth-modal");

    if (toggleBtn) {
      toggleBtn.addEventListener("click", () => this.toggleMode());
    }

    if (form) {
      form.addEventListener("submit", e => this.handleSubmit(e));
    }

    if (closeBtn) {
      closeBtn.addEventListener("click", () => this.close());
    }

    if (modal) {
      modal.addEventListener("click", e => {
        if (e.target.id === "auth-modal") this.close();
      });
    }

    console.log("✅ Event listeners configurados");
  }

  toggleMode() {
    const mode = document.getElementById("auth-mode").value;
    const isLogin = mode === "login";

    document.getElementById("auth-mode").value = isLogin ? "register" : "login";
    document.getElementById("auth-modal-title").textContent = isLogin
      ? "Criar Conta"
      : "Entrar na Elevare";
    document.getElementById("auth-modal-subtitle").textContent = isLogin
      ? "Comece sua jornada hoje"
      : "Acesse sua conta ou crie uma nova";
    document.getElementById("auth-submit-text").textContent = isLogin ? "Criar Conta" : "Entrar";
    document.getElementById("auth-toggle").textContent = isLogin
      ? "Já tem conta? Entrar"
      : "Não tem conta? Criar conta";

    // Mostra/esconde campo de nome
    const nameField = document.getElementById("name-field");
    if (isLogin) {
      nameField.classList.remove("hidden");
      document.getElementById("auth-name").required = true;
    } else {
      nameField.classList.add("hidden");
      document.getElementById("auth-name").required = false;
    }

    // Limpa mensagens
    this.hideMessage("auth-error");
    this.hideMessage("auth-success");
  }

  async handleSubmit(e) {
    e.preventDefault();

    const mode = document.getElementById("auth-mode").value;
    const email = document.getElementById("auth-email").value;
    const password = document.getElementById("auth-password").value;
    const name = document.getElementById("auth-name").value;

    // Validação básica
    if (!email || !password) {
      this.showMessage("auth-error", "Preencha todos os campos");
      return;
    }

    if (password.length < 6) {
      this.showMessage("auth-error", "A senha deve ter no mínimo 6 caracteres");
      return;
    }

    if (mode === "register" && !name) {
      this.showMessage("auth-error", "Preencha seu nome completo");
      return;
    }

    // Desabilita botão e mostra loading
    this.setLoading(true);
    this.hideMessage("auth-error");
    this.hideMessage("auth-success");

    try {
      if (mode === "register") {
        await this.register(email, password, name);
      } else {
        await this.login(email, password);
      }
    } catch (error) {
      this.showMessage("auth-error", error.message);
    } finally {
      this.setLoading(false);
    }
  }

  async register(email, password, name) {
    try {
      const data = await window.elevareAPI.register(email, password, name);

      this.showMessage("auth-success", "Conta criada com sucesso! Redirecionando...");
      this.user = data.user;

      // Aguarda 1 segundo e redireciona
      setTimeout(() => {
        this.close();
        this.updateUI();
        window.location.href = "/dashboard.html";
      }, 1000);
    } catch (error) {
      throw new Error(error.message || "Erro ao criar conta. Tente novamente.");
    }
  }

  async login(email, password) {
    try {
      const data = await window.elevareAPI.login(email, password);

      this.showMessage("auth-success", "Login realizado com sucesso! Redirecionando...");
      this.user = data.user;

      // Aguarda 1 segundo e redireciona
      setTimeout(() => {
        this.close();
        this.updateUI();
        window.location.href = "/dashboard.html";
      }, 1000);
    } catch (error) {
      throw new Error(error.message || "Email ou senha incorretos.");
    }
  }

  logout() {
    window.elevareAPI.logout();
    this.user = null;
    this.token = null;
    this.updateUI();
    window.location.href = "/";
  }

  updateUI() {
    // Atualiza botões de login/logout
    const loginButtons = document.querySelectorAll('[data-auth="login"]');
    const logoutButtons = document.querySelectorAll('[data-auth="logout"]');
    const userNameElements = document.querySelectorAll('[data-auth="user-name"]');

    if (this.user) {
      // Usuário logado
      loginButtons.forEach(btn => btn.classList.add("hidden"));
      logoutButtons.forEach(btn => btn.classList.remove("hidden"));
      userNameElements.forEach(el => {
        el.textContent = this.user.user_metadata?.name || this.user.email;
      });
    } else {
      // Usuário não logado
      loginButtons.forEach(btn => btn.classList.remove("hidden"));
      logoutButtons.forEach(btn => btn.classList.add("hidden"));
    }
  }

  open() {
    const modal = document.getElementById("auth-modal");
    if (modal) {
      modal.classList.remove("hidden");
      document.body.style.overflow = "hidden";
    }
  }

  close() {
    const modal = document.getElementById("auth-modal");
    if (modal) {
      modal.classList.add("hidden");
      document.body.style.overflow = "auto";

      // Limpa formulário
      document.getElementById("auth-form").reset();
      this.hideMessage("auth-error");
      this.hideMessage("auth-success");
    }
  }

  showMessage(elementId, message) {
    const element = document.getElementById(elementId);
    if (element) {
      element.textContent = message;
      element.classList.remove("hidden");
    }
  }

  hideMessage(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
      element.classList.add("hidden");
    }
  }

  setLoading(isLoading) {
    const submitBtn = document.getElementById("auth-submit");
    const submitText = document.getElementById("auth-submit-text");
    const submitLoading = document.getElementById("auth-submit-loading");

    if (isLoading) {
      submitBtn.disabled = true;
      submitText.classList.add("hidden");
      submitLoading.classList.remove("hidden");
    } else {
      submitBtn.disabled = false;
      submitText.classList.remove("hidden");
      submitLoading.classList.add("hidden");
    }
  }

  // Verifica se usuário está autenticado
  isAuthenticated() {
    return !!this.user;
  }
}

// ========================================
// EXPORTAÇÃO GLOBAL
// ========================================
// Cria instância global
window.elevareAuth = new ElevareAuth();

// Funções globais para compatibilidade
window.openAuthModal = () => window.elevareAuth.open();
window.closeAuthModal = () => window.elevareAuth.close();
window.logout = () => window.elevareAuth.logout();

// Exporta para módulos ES6 (se necessário)
export default ElevareAuth;
