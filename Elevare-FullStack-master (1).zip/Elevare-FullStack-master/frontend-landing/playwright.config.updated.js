/**
 * Configuração Playwright para Testes E2E
 * Elevare Landing Page
 * 
 * Criado em: 28/11/2025
 * Atualizado para refletir realidade atual do projeto
 */

const { defineConfig, devices } = require('@playwright/test');

module.exports = defineConfig({
    // Diretório de testes
    testDir: './tests/e2e',
    
    // Timeout
    timeout: 30000,
    expect: {
        timeout: 5000
    },
    
    // Configurações de execução
    fullyParallel: true,
    forbidOnly: !!process.env.CI,
    retries: process.env.CI ? 2 : 0,
    workers: process.env.CI ? 1 : undefined,
    
    // Reporter
    reporter: [
        ['html', { outputFolder: 'playwright-report' }],
        ['json', { outputFile: 'test-results.json' }],
        ['list']
    ],
    
    // Configurações compartilhadas
    use: {
        baseURL: 'http://localhost:5173',
        trace: 'on-first-retry',
        screenshot: 'only-on-failure',
        video: 'retain-on-failure',
    },
    
    // Projetos (navegadores)
    projects: [
        {
            name: 'chromium',
            use: { ...devices['Desktop Chrome'] },
        },
        {
            name: 'firefox',
            use: { ...devices['Desktop Firefox'] },
        },
        {
            name: 'webkit',
            use: { ...devices['Desktop Safari'] },
        },
        {
            name: 'mobile-chrome',
            use: { ...devices['Pixel 5'] },
        },
        {
            name: 'mobile-safari',
            use: { ...devices['iPhone 12'] },
        },
    ],
    
    // Web Server (inicia automaticamente)
    webServer: {
        command: 'npm run dev',
        url: 'http://localhost:5173',
        reuseExistingServer: !process.env.CI,
        timeout: 120000,
    },
});
