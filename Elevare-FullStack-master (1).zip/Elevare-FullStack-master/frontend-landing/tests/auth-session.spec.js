// @ts-check
const { test, expect } = require('@playwright/test');

/**
 * Testes E2E para Autenticação e Sessão
 * Verifica login, logout e alternância de UI conforme estado de autenticação
 */

test.describe('Autenticação e Sessão', () => {
  
  test.beforeEach(async ({ page }) => {
    // Limpar localStorage antes de cada teste
    await page.goto('/');
    await page.evaluate(() => localStorage.clear());
  });

  test('deve exibir botão "Entrar" quando usuário não está logado', async ({ page }) => {
    await page.goto('/');
    
    // Verificar que botão "Entrar" está visível
    const authButton = page.locator('.auth-button');
    await expect(authButton).toBeVisible();
    
    // Verificar que botões de usuário logado estão ocultos
    const dashboardButton = page.locator('.dashboard-button');
    const logoutButton = page.locator('.logout-button');
    
    await expect(dashboardButton).toBeHidden();
    await expect(logoutButton).toBeHidden();
  });

  test('deve exibir botões "Dashboard" e "Sair" quando usuário está logado', async ({ page }) => {
    // Simular login
    await page.goto('/');
    await page.evaluate(() => {
      localStorage.setItem('token', 'test-token-123');
      updateAuthUI();
    });
    
    // Verificar que botão "Entrar" está oculto
    const authButton = page.locator('.auth-button');
    await expect(authButton).toBeHidden();
    
    // Verificar que botões de usuário logado estão visíveis
    const dashboardButton = page.locator('.dashboard-button');
    const logoutButton = page.locator('.logout-button');
    
    await expect(dashboardButton).toBeVisible();
    await expect(logoutButton).toBeVisible();
  });

  test('deve alternar UI ao fazer login', async ({ page }) => {
    await page.goto('/');
    
    // Estado inicial: não logado
    await expect(page.locator('.auth-button')).toBeVisible();
    
    // Simular login
    await page.evaluate(() => {
      localStorage.setItem('token', 'test-token-123');
      updateAuthUI();
    });
    
    // Verificar mudança de UI
    await expect(page.locator('.auth-button')).toBeHidden();
    await expect(page.locator('.dashboard-button')).toBeVisible();
    await expect(page.locator('.logout-button')).toBeVisible();
  });

  test('deve alternar UI ao fazer logout', async ({ page }) => {
    // Iniciar logado
    await page.goto('/');
    await page.evaluate(() => {
      localStorage.setItem('token', 'test-token-123');
      updateAuthUI();
    });
    
    // Verificar estado logado
    await expect(page.locator('.dashboard-button')).toBeVisible();
    
    // Fazer logout
    await page.evaluate(() => logout());
    
    // Verificar mudança de UI
    await expect(page.locator('.auth-button')).toBeVisible();
    await expect(page.locator('.dashboard-button')).toBeHidden();
    await expect(page.locator('.logout-button')).toBeHidden();
  });

  test('deve limpar token do localStorage ao fazer logout', async ({ page }) => {
    await page.goto('/');
    
    // Definir token
    await page.evaluate(() => {
      localStorage.setItem('token', 'test-token-123');
    });
    
    // Verificar que token existe
    let token = await page.evaluate(() => localStorage.getItem('token'));
    expect(token).toBe('test-token-123');
    
    // Fazer logout
    await page.evaluate(() => logout());
    
    // Verificar que token foi removido
    token = await page.evaluate(() => localStorage.getItem('token'));
    expect(token).toBeNull();
  });

  test('deve detectar usuário logado ao carregar página', async ({ page }) => {
    // Definir token antes de carregar página
    await page.goto('/');
    await page.evaluate(() => {
      localStorage.setItem('token', 'test-token-123');
    });
    
    // Recarregar página
    await page.reload();
    
    // Aguardar DOMContentLoaded e updateAuthUI()
    await page.waitForLoadState('domcontentloaded');
    
    // Verificar que UI está no estado logado
    await expect(page.locator('.dashboard-button')).toBeVisible();
    await expect(page.locator('.logout-button')).toBeVisible();
    await expect(page.locator('.auth-button')).toBeHidden();
  });

  test('deve redirecionar para dashboard ao clicar no botão Dashboard', async ({ page }) => {
    await page.goto('/');
    
    // Simular login
    await page.evaluate(() => {
      localStorage.setItem('token', 'test-token-123');
      updateAuthUI();
    });
    
    // Clicar no botão Dashboard
    await page.click('.dashboard-button');
    
    // Verificar redirecionamento
    await expect(page).toHaveURL(/dashboard\.html/);
  });

  test('deve persistir sessão após recarregar página', async ({ page }) => {
    await page.goto('/');
    
    // Fazer login
    await page.evaluate(() => {
      localStorage.setItem('token', 'test-token-123');
      updateAuthUI();
    });
    
    // Recarregar página
    await page.reload();
    
    // Verificar que sessão persiste
    const token = await page.evaluate(() => localStorage.getItem('token'));
    expect(token).toBe('test-token-123');
    
    // Verificar UI
    await expect(page.locator('.dashboard-button')).toBeVisible();
  });

  test('função updateAuthUI deve existir e ser chamável', async ({ page }) => {
    await page.goto('/');
    
    // Verificar que função existe
    const functionExists = await page.evaluate(() => typeof updateAuthUI === 'function');
    expect(functionExists).toBe(true);
    
    // Verificar que função pode ser chamada sem erro
    await page.evaluate(() => updateAuthUI());
  });

  test('função logout deve existir e ser chamável', async ({ page }) => {
    await page.goto('/');
    
    // Verificar que função existe
    const functionExists = await page.evaluate(() => typeof logout === 'function');
    expect(functionExists).toBe(true);
    
    // Verificar que função pode ser chamada sem erro
    await page.evaluate(() => logout());
  });
});
