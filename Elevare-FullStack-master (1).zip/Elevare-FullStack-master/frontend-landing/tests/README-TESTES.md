# 🧪 SUITE DE TESTES - Elevare Landing Page

**Versão:** 2.0  
**Data:** 28/11/2025  
**Status:** Pronto para Execução

---

## 📋 VISÃO GERAL

Suite completa de testes para a landing page da Elevare, incluindo:
- **Testes Unitários** (Jest)
- **Testes E2E** (Playwright)
- **Cobertura de Código**
- **Testes em Múltiplos Navegadores**

---

## 🎯 TESTES IMPLEMENTADOS

### Testes Unitários (Jest)

**Arquivo:** `tests/unit/lead-tracker.test.js`  
**Cobertura:** Lead Tracker

**Categorias:**
1. ✅ Constructor e Inicialização (4 testes)
2. ✅ Milestone Tracking (4 testes)
3. ✅ Lead Scoring (5 testes)
4. ✅ Data Collection (7 testes)
5. ✅ Edge Cases (3 testes)

**Total:** 23 testes unitários

---

### Testes E2E (Playwright)

**Arquivo:** `tests/e2e/landing-page.spec.js`  
**Cobertura:** Landing Page completa

**Categorias:**
1. ✅ Carregamento e Estrutura (4 testes)
2. ✅ Formulário de Captura de Leads (3 testes)
3. ✅ Modal de Planos (2 testes)
4. ✅ Menu Mobile (2 testes)
5. ✅ Navegação Interna (2 testes)
6. ✅ Ícones e Elementos Visuais (2 testes)
7. ✅ Responsividade (3 testes)
8. ✅ Performance (2 testes)
9. ✅ SEO e Meta Tags (2 testes)
10. ✅ Lead Tracker (2 testes)

**Total:** 24 testes E2E

**Navegadores Testados:**
- Chromium (Desktop)
- Firefox (Desktop)
- WebKit/Safari (Desktop)
- Chrome Mobile (Pixel 5)
- Safari Mobile (iPhone 12)

---

## 🚀 INSTALAÇÃO

### 1. Instalar Dependências

```bash
cd frontend-landing

# Instalar Jest e dependências
npm install --save-dev jest @testing-library/jest-dom babel-jest @babel/core @babel/preset-env

# Instalar Playwright
npm install --save-dev @playwright/test
npx playwright install
```

### 2. Configurar package.json

Adicione ao `package.json`:

```json
{
  "scripts": {
    "test": "jest",
    "test:coverage": "jest --coverage",
    "test:watch": "jest --watch",
    "test:e2e": "playwright test",
    "test:e2e:ui": "playwright test --ui",
    "test:e2e:headed": "playwright test --headed",
    "test:all": "npm run test && npm run test:e2e"
  }
}
```

### 3. Criar .babelrc

```json
{
  "presets": ["@babel/preset-env"]
}
```

---

## 🧪 EXECUTAR TESTES

### Testes Unitários (Jest)

```bash
# Executar todos os testes
npm test

# Executar com cobertura
npm run test:coverage

# Executar em modo watch
npm run test:watch

# Executar teste específico
npm test -- lead-tracker.test.js
```

**Resultado Esperado:**
```
PASS  tests/unit/lead-tracker.test.js
  🎯 Lead Tracker - Unit Tests
    Constructor e Inicialização
      ✓ deve criar ID único no primeiro acesso
      ✓ deve reutilizar ID existente
      ✓ deve inicializar milestones como false
      ✓ deve salvar timestamp de criação
    ...

Test Suites: 1 passed, 1 total
Tests:       23 passed, 23 total
```

---

### Testes E2E (Playwright)

```bash
# Executar todos os testes E2E
npm run test:e2e

# Executar com UI interativa
npm run test:e2e:ui

# Executar com navegador visível
npm run test:e2e:headed

# Executar em navegador específico
npx playwright test --project=chromium

# Executar teste específico
npx playwright test landing-page.spec.js
```

**Resultado Esperado:**
```
Running 24 tests using 5 workers

  ✓ [chromium] › landing-page.spec.js:10:9 › Landing Page - Testes E2E › Carregamento e Estrutura › deve carregar a página principal
  ✓ [chromium] › landing-page.spec.js:14:9 › Landing Page - Testes E2E › Carregamento e Estrutura › deve exibir logo da Elevare
  ...

  24 passed (1m)
```

---

## 📊 COBERTURA DE CÓDIGO

### Visualizar Relatório de Cobertura

```bash
npm run test:coverage
```

**Relatório gerado em:** `coverage/lcov-report/index.html`

**Thresholds Configurados:**
- Branches: 70%
- Functions: 70%
- Lines: 70%
- Statements: 70%

---

## 🎯 ESTRUTURA DE TESTES

```
frontend-landing/
├── tests/
│   ├── setup.js                    # Setup Jest (mocks globais)
│   ├── unit/
│   │   └── lead-tracker.test.js    # Testes unitários Lead Tracker
│   ├── e2e/
│   │   └── landing-page.spec.js    # Testes E2E Landing Page
│   └── README-TESTES.md            # Esta documentação
├── jest.config.js                  # Configuração Jest
├── playwright.config.updated.js    # Configuração Playwright
└── package.json                    # Scripts de teste
```

---

## 🐛 TROUBLESHOOTING

### Problema: Jest não encontra módulos

**Solução:**
```bash
npm install --save-dev @babel/core @babel/preset-env babel-jest
```

Criar `.babelrc`:
```json
{
  "presets": ["@babel/preset-env"]
}
```

---

### Problema: Playwright não inicia navegador

**Solução:**
```bash
npx playwright install
npx playwright install-deps
```

---

### Problema: Testes E2E falham com "page not found"

**Solução:**
```bash
# Certifique-se de que o dev server está rodando
npm run dev

# Em outro terminal
npm run test:e2e
```

---

### Problema: Cobertura baixa

**Solução:**
1. Verificar quais arquivos não estão cobertos:
   ```bash
   npm run test:coverage
   ```

2. Adicionar testes para arquivos descobertos

3. Ajustar thresholds em `jest.config.js` se necessário

---

## 📈 MÉTRICAS ATUAIS

**Testes Implementados:**
- Unitários: 23 testes
- E2E: 24 testes
- **Total: 47 testes**

**Navegadores Cobertos:**
- Desktop: 3 (Chrome, Firefox, Safari)
- Mobile: 2 (Pixel 5, iPhone 12)
- **Total: 5 navegadores**

**Viewports Testados:**
- Desktop: 1920x1080
- Tablet: 1024x768
- Mobile: 375x667

---

## 🎯 PRÓXIMOS PASSOS

### Curto Prazo
1. [ ] Executar testes pela primeira vez
2. [ ] Corrigir falhas identificadas
3. [ ] Atingir 70% de cobertura

### Médio Prazo
4. [ ] Adicionar testes de integração
5. [ ] Implementar testes de acessibilidade
6. [ ] Configurar CI/CD para rodar testes automaticamente

### Longo Prazo
7. [ ] Atingir 90% de cobertura
8. [ ] Adicionar testes de performance
9. [ ] Implementar testes de regressão visual

---

## 📚 REFERÊNCIAS

- **Jest:** https://jestjs.io/
- **Playwright:** https://playwright.dev/
- **Testing Library:** https://testing-library.com/

---

**Última atualização:** 28/11/2025  
**Responsável:** Sistema Manus  
**Status:** ✅ Pronto para Execução
