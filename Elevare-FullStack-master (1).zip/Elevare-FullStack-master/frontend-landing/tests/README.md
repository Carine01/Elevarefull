# 🧪 Testes Automatizados - Elevare Landing Page

Este diretório contém todos os testes automatizados E2E (End-to-End) para a landing page da Elevare, implementados com Playwright.

---

## 📋 Estrutura de Testes

### auth-modals.spec.js
Testa funcionalidades dos modais de autenticação:
- Abertura e fechamento de modais
- Foco em campos
- Bloqueio/desbloqueio de scroll
- Fechamento com tecla ESC

### auth-session.spec.js
Testa autenticação e gerenciamento de sessão:
- Detecção de usuário logado
- Alternância de botões conforme estado de login
- Persistência de sessão
- Função logout

### mobile-menu.spec.js
Testa funcionalidade do menu mobile:
- Abertura e fechamento do menu
- Responsividade em diferentes dispositivos
- Navegação no menu mobile

### icons-navigation.spec.js
Testa ícones Lucide e navegação:
- Carregamento de ícones
- Renderização após alterações dinâmicas
- Links internos e externos
- Navegação suave

### forms.spec.js
Testa formulários de login e registro:
- Validação de campos
- Interceptação de submit
- Mensagens de erro
- Tipos de input corretos

---

## 🚀 Como Executar

### Executar todos os testes
```bash
npm test
```

### Executar com interface visual
```bash
npm run test:ui
```

### Executar em modo headed (ver navegador)
```bash
npm run test:headed
```

### Executar em modo debug
```bash
npm run test:debug
```

### Ver relatório de testes
```bash
npm run test:report
```

---

## 📊 Cobertura de Testes

Os testes cobrem:

- ✅ Modais de autenticação (10 testes)
- ✅ Sessão e login/logout (10 testes)
- ✅ Menu mobile (11 testes)
- ✅ Ícones e navegação (10 testes)
- ✅ Formulários (20 testes)

**Total:** ~60 testes automatizados

---

## 🎯 Requisitos

### Navegadores Testados

- Chromium (Desktop)
- Firefox (Desktop)
- WebKit/Safari (Desktop)
- Mobile Chrome (Pixel 5)
- Mobile Safari (iPhone 12)
- iPad Pro

### Pré-requisitos

```bash
# Instalar dependências
npm install

# Instalar navegadores Playwright
npx playwright install
```

---

## 📝 Escrevendo Novos Testes

### Template Básico

```javascript
// @ts-check
const { test, expect } = require('@playwright/test');

test.describe('Nome do Grupo de Testes', () => {
  
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('deve fazer algo específico', async ({ page }) => {
    // Arrange
    const elemento = page.locator('#id-elemento');
    
    // Act
    await elemento.click();
    
    // Assert
    await expect(elemento).toBeVisible();
  });
});
```

### Boas Práticas

1. **Nomes Descritivos:** Use nomes claros que descrevam o que está sendo testado
2. **Isolamento:** Cada teste deve ser independente
3. **Limpeza:** Use `beforeEach` para resetar estado
4. **Esperas:** Use `waitFor` quando necessário
5. **Seletores:** Prefira IDs e data-testid a classes CSS

---

## 🐛 Debugging

### Ver teste em execução
```bash
npm run test:headed
```

### Pausar execução
```javascript
await page.pause();
```

### Screenshots
```javascript
await page.screenshot({ path: 'debug.png' });
```

### Console logs
```javascript
page.on('console', msg => console.log(msg.text()));
```

---

## 📊 Relatórios

Após executar os testes, os relatórios são gerados em:

- `playwright-report/` - Relatório HTML
- `test-results/` - Resultados JSON e screenshots

---

## 🔄 CI/CD

Os testes são executados automaticamente:

- Em cada push para `master`/`main`
- Em cada Pull Request
- Via GitHub Actions

Veja: `.github/workflows/landing-page-ci.yml`

---

## 🆘 Problemas Comuns

### Testes falhando localmente?

1. Limpar cache:
   ```bash
   rm -rf node_modules
   npm install
   ```

2. Reinstalar navegadores:
   ```bash
   npx playwright install
   ```

3. Verificar servidor local:
   ```bash
   npm run dev
   # Em outro terminal:
   npm test
   ```

### Timeouts?

Aumente o timeout no `playwright.config.js`:
```javascript
timeout: 60 * 1000, // 60 segundos
```

---

## 📚 Documentação

- [Playwright Docs](https://playwright.dev/docs/intro)
- [Best Practices](https://playwright.dev/docs/best-practices)
- [API Reference](https://playwright.dev/docs/api/class-playwright)

---

**Última atualização:** 28/11/2025
