// @ts-check
const { test, expect } = require('@playwright/test');

/**
 * Testes E2E para Modais de Autenticação
 * Verifica abertura, fechamento e funcionalidades dos modais de login/registro
 */

test.describe('Modais de Autenticação', () => {
  
  test.beforeEach(async ({ page }) => {
    // Navegar para a landing page antes de cada teste
    await page.goto('/');
  });

  test('deve abrir modal de login ao clicar no botão "Entrar"', async ({ page }) => {
    // Clicar no botão "Entrar"
    await page.click('button.auth-button, a:has-text("Entrar")');
    
    // Verificar que o modal de login está visível
    const loginModal = page.locator('#loginModal');
    await expect(loginModal).toBeVisible();
    
    // Verificar que o modal não tem a classe 'hidden'
    await expect(loginModal).not.toHaveClass(/hidden/);
    
    // Verificar que o scroll do body está bloqueado
    const bodyOverflow = await page.evaluate(() => document.body.style.overflow);
    expect(bodyOverflow).toBe('hidden');
  });

  test('deve fechar modal de login ao clicar no botão fechar', async ({ page }) => {
    // Abrir modal de login
    await page.evaluate(() => openLoginModal());
    
    // Verificar que está aberto
    await expect(page.locator('#loginModal')).toBeVisible();
    
    // Clicar no botão fechar
    await page.click('#loginModal button[onclick*="closeLoginModal"]');
    
    // Verificar que o modal foi fechado
    await expect(page.locator('#loginModal')).toHaveClass(/hidden/);
    
    // Verificar que o scroll foi restaurado
    const bodyOverflow = await page.evaluate(() => document.body.style.overflow);
    expect(bodyOverflow).toBe('');
  });

  test('deve fechar modal de login ao pressionar ESC', async ({ page }) => {
    // Abrir modal de login
    await page.evaluate(() => openLoginModal());
    
    // Verificar que está aberto
    await expect(page.locator('#loginModal')).toBeVisible();
    
    // Pressionar ESC
    await page.keyboard.press('Escape');
    
    // Verificar que o modal foi fechado
    await expect(page.locator('#loginModal')).toHaveClass(/hidden/);
  });

  test('deve abrir modal de registro ao clicar em "Criar conta"', async ({ page }) => {
    // Abrir modal de login primeiro
    await page.evaluate(() => openLoginModal());
    
    // Clicar em "Criar conta"
    await page.click('a:has-text("Criar conta")');
    
    // Verificar que modal de login foi fechado
    await expect(page.locator('#loginModal')).toHaveClass(/hidden/);
    
    // Verificar que modal de registro está aberto
    await expect(page.locator('#registerModal')).toBeVisible();
    await expect(page.locator('#registerModal')).not.toHaveClass(/hidden/);
  });

  test('deve focar no primeiro campo ao abrir modal de login', async ({ page }) => {
    // Abrir modal de login
    await page.evaluate(() => openLoginModal());
    
    // Verificar que o campo de email está focado
    const focusedElement = await page.evaluate(() => document.activeElement.id);
    expect(focusedElement).toBe('login-email');
  });

  test('deve focar no primeiro campo ao abrir modal de registro', async ({ page }) => {
    // Abrir modal de registro
    await page.evaluate(() => openRegisterModal());
    
    // Verificar que o campo de nome está focado
    const focusedElement = await page.evaluate(() => document.activeElement.id);
    expect(focusedElement).toBe('register-nome');
  });

  test('deve exibir campos corretos no modal de login', async ({ page }) => {
    // Abrir modal de login
    await page.evaluate(() => openLoginModal());
    
    // Verificar campos
    await expect(page.locator('#login-email')).toBeVisible();
    await expect(page.locator('#login-password')).toBeVisible();
    await expect(page.locator('button[type="submit"]')).toBeVisible();
  });

  test('deve exibir campos corretos no modal de registro', async ({ page }) => {
    // Abrir modal de registro
    await page.evaluate(() => openRegisterModal());
    
    // Verificar campos
    await expect(page.locator('#register-nome')).toBeVisible();
    await expect(page.locator('#register-email')).toBeVisible();
    await expect(page.locator('#register-password')).toBeVisible();
    await expect(page.locator('button[type="submit"]')).toBeVisible();
  });

  test('deve bloquear scroll ao abrir modal', async ({ page }) => {
    // Verificar scroll inicial
    const initialOverflow = await page.evaluate(() => document.body.style.overflow);
    expect(initialOverflow).toBe('');
    
    // Abrir modal
    await page.evaluate(() => openLoginModal());
    
    // Verificar que scroll foi bloqueado
    const blockedOverflow = await page.evaluate(() => document.body.style.overflow);
    expect(blockedOverflow).toBe('hidden');
  });

  test('deve restaurar scroll ao fechar modal', async ({ page }) => {
    // Abrir e fechar modal
    await page.evaluate(() => {
      openLoginModal();
      closeLoginModal();
    });
    
    // Verificar que scroll foi restaurado
    const restoredOverflow = await page.evaluate(() => document.body.style.overflow);
    expect(restoredOverflow).toBe('');
  });
});
