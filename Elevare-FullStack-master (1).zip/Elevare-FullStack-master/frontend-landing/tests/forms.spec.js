// @ts-check
const { test, expect } = require('@playwright/test');

/**
 * Testes E2E para Formulários
 * Verifica validação e submissão de formulários de login e registro
 */

test.describe('Formulário de Login', () => {
  
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => openLoginModal());
  });

  test('deve exibir formulário de login corretamente', async ({ page }) => {
    // Verificar campos
    await expect(page.locator('#login-email')).toBeVisible();
    await expect(page.locator('#login-password')).toBeVisible();
    await expect(page.locator('#loginForm button[type="submit"]')).toBeVisible();
  });

  test('deve validar campo de email vazio', async ({ page }) => {
    // Tentar submeter sem preencher
    await page.click('#loginForm button[type="submit"]');
    
    // Verificar validação HTML5
    const emailValid = await page.locator('#login-email').evaluate(
      (el) => (el as HTMLInputElement).validity.valid
    );
    expect(emailValid).toBe(false);
  });

  test('deve validar formato de email inválido', async ({ page }) => {
    // Preencher email inválido
    await page.fill('#login-email', 'email-invalido');
    
    // Verificar validação
    const emailValid = await page.locator('#login-email').evaluate(
      (el) => (el as HTMLInputElement).validity.valid
    );
    expect(emailValid).toBe(false);
  });

  test('deve aceitar email válido', async ({ page }) => {
    // Preencher email válido
    await page.fill('#login-email', 'usuario@exemplo.com');
    
    // Verificar validação
    const emailValid = await page.locator('#login-email').evaluate(
      (el) => (el as HTMLInputElement).validity.valid
    );
    expect(emailValid).toBe(true);
  });

  test('deve validar senha vazia', async ({ page }) => {
    // Preencher email mas não senha
    await page.fill('#login-email', 'usuario@exemplo.com');
    
    // Tentar submeter
    await page.click('#loginForm button[type="submit"]');
    
    // Verificar validação
    const passwordValid = await page.locator('#login-password').evaluate(
      (el) => (el as HTMLInputElement).validity.valid
    );
    expect(passwordValid).toBe(false);
  });

  test('deve interceptar submit do formulário', async ({ page }) => {
    // Preencher campos
    await page.fill('#login-email', 'usuario@exemplo.com');
    await page.fill('#login-password', 'senha123');
    
    // Submeter formulário
    await page.click('#loginForm button[type="submit"]');
    
    // Verificar que página não recarregou (preventDefault funcionou)
    await page.waitForTimeout(500);
    const url = page.url();
    expect(url).not.toContain('?'); // Não deve ter query string de form submit
  });

  test('campo de senha deve ser do tipo password', async ({ page }) => {
    const passwordType = await page.locator('#login-password').getAttribute('type');
    expect(passwordType).toBe('password');
  });

  test('deve focar no email ao abrir modal', async ({ page }) => {
    const focusedId = await page.evaluate(() => document.activeElement?.id);
    expect(focusedId).toBe('login-email');
  });
});

test.describe('Formulário de Registro', () => {
  
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => openRegisterModal());
  });

  test('deve exibir formulário de registro corretamente', async ({ page }) => {
    // Verificar campos
    await expect(page.locator('#register-nome')).toBeVisible();
    await expect(page.locator('#register-email')).toBeVisible();
    await expect(page.locator('#register-password')).toBeVisible();
    await expect(page.locator('#registerForm button[type="submit"]')).toBeVisible();
  });

  test('deve validar campo de nome vazio', async ({ page }) => {
    // Tentar submeter sem preencher
    await page.click('#registerForm button[type="submit"]');
    
    // Verificar validação
    const nomeValid = await page.locator('#register-nome').evaluate(
      (el) => (el as HTMLInputElement).validity.valid
    );
    expect(nomeValid).toBe(false);
  });

  test('deve validar campo de email vazio', async ({ page }) => {
    // Preencher nome mas não email
    await page.fill('#register-nome', 'João Silva');
    
    // Tentar submeter
    await page.click('#registerForm button[type="submit"]');
    
    // Verificar validação
    const emailValid = await page.locator('#register-email').evaluate(
      (el) => (el as HTMLInputElement).validity.valid
    );
    expect(emailValid).toBe(false);
  });

  test('deve validar formato de email', async ({ page }) => {
    // Preencher email inválido
    await page.fill('#register-email', 'email-invalido');
    
    // Verificar validação
    const emailValid = await page.locator('#register-email').evaluate(
      (el) => (el as HTMLInputElement).validity.valid
    );
    expect(emailValid).toBe(false);
  });

  test('deve validar senha vazia', async ({ page }) => {
    // Preencher nome e email mas não senha
    await page.fill('#register-nome', 'João Silva');
    await page.fill('#register-email', 'joao@exemplo.com');
    
    // Tentar submeter
    await page.click('#registerForm button[type="submit"]');
    
    // Verificar validação
    const passwordValid = await page.locator('#register-password').evaluate(
      (el) => (el as HTMLInputElement).validity.valid
    );
    expect(passwordValid).toBe(false);
  });

  test('deve aceitar todos os campos válidos', async ({ page }) => {
    // Preencher todos os campos
    await page.fill('#register-nome', 'João Silva');
    await page.fill('#register-email', 'joao@exemplo.com');
    await page.fill('#register-password', 'senha123');
    
    // Verificar validação de todos os campos
    const nomeValid = await page.locator('#register-nome').evaluate(
      (el) => (el as HTMLInputElement).validity.valid
    );
    const emailValid = await page.locator('#register-email').evaluate(
      (el) => (el as HTMLInputElement).validity.valid
    );
    const passwordValid = await page.locator('#register-password').evaluate(
      (el) => (el as HTMLInputElement).validity.valid
    );
    
    expect(nomeValid).toBe(true);
    expect(emailValid).toBe(true);
    expect(passwordValid).toBe(true);
  });

  test('deve interceptar submit do formulário', async ({ page }) => {
    // Preencher campos
    await page.fill('#register-nome', 'João Silva');
    await page.fill('#register-email', 'joao@exemplo.com');
    await page.fill('#register-password', 'senha123');
    
    // Submeter formulário
    await page.click('#registerForm button[type="submit"]');
    
    // Verificar que página não recarregou
    await page.waitForTimeout(500);
    const url = page.url();
    expect(url).not.toContain('?');
  });

  test('deve focar no nome ao abrir modal', async ({ page }) => {
    const focusedId = await page.evaluate(() => document.activeElement?.id);
    expect(focusedId).toBe('register-nome');
  });

  test('link "Já tem conta?" deve abrir modal de login', async ({ page }) => {
    // Clicar no link
    await page.click('a:has-text("Já tem conta?")');
    
    // Verificar que modal de registro foi fechado
    await expect(page.locator('#registerModal')).toHaveClass(/hidden/);
    
    // Verificar que modal de login foi aberto
    await expect(page.locator('#loginModal')).toBeVisible();
  });
});

test.describe('Validação e Feedback', () => {
  
  test('container de erro deve existir nos formulários', async ({ page }) => {
    await page.goto('/');
    
    // Abrir modal de login
    await page.evaluate(() => openLoginModal());
    
    // Verificar container de erro
    const errorContainer = page.locator('#loginModal .error-container');
    await expect(errorContainer).toBeAttached();
  });

  test('campos obrigatórios devem ter atributo required', async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => openLoginModal());
    
    // Verificar atributo required
    const emailRequired = await page.locator('#login-email').getAttribute('required');
    const passwordRequired = await page.locator('#login-password').getAttribute('required');
    
    expect(emailRequired).not.toBeNull();
    expect(passwordRequired).not.toBeNull();
  });

  test('campos de email devem ter type="email"', async ({ page }) => {
    await page.goto('/');
    await page.evaluate(() => openLoginModal());
    
    const emailType = await page.locator('#login-email').getAttribute('type');
    expect(emailType).toBe('email');
  });
});
