// @ts-check
const { test, expect } = require('@playwright/test');

/**
 * Testes E2E para Ícones Lucide e Navegação
 * Verifica carregamento de ícones e funcionalidade de links
 */

test.describe('Ícones Lucide', () => {
  
  test('script Lucide deve estar carregado', async ({ page }) => {
    await page.goto('/');
    
    // Verificar que Lucide está definido
    const lucideLoaded = await page.evaluate(() => typeof lucide !== 'undefined');
    expect(lucideLoaded).toBe(true);
  });

  test('ícones devem ser renderizados no carregamento da página', async ({ page }) => {
    await page.goto('/');
    
    // Aguardar renderização de ícones
    await page.waitForLoadState('networkidle');
    
    // Verificar que há ícones SVG na página
    const icons = page.locator('svg[class*="lucide"]');
    const iconCount = await icons.count();
    
    expect(iconCount).toBeGreaterThan(0);
  });

  test('ícones devem aparecer após abrir modal', async ({ page }) => {
    await page.goto('/');
    
    // Abrir modal de login
    await page.evaluate(() => openLoginModal());
    
    // Aguardar renderização
    await page.waitForTimeout(500);
    
    // Verificar ícones no modal
    const modalIcons = page.locator('#loginModal svg');
    const iconCount = await modalIcons.count();
    
    expect(iconCount).toBeGreaterThan(0);
  });

  test('função lucide.createIcons deve ser chamada no DOMContentLoaded', async ({ page }) => {
    await page.goto('/');
    
    // Verificar que createIcons foi chamado
    const createIconsCalled = await page.evaluate(() => {
      return typeof lucide !== 'undefined' && typeof lucide.createIcons === 'function';
    });
    
    expect(createIconsCalled).toBe(true);
  });

  test('ícones não devem estar quebrados', async ({ page }) => {
    await page.goto('/');
    
    // Verificar que não há elementos com data-lucide sem SVG renderizado
    const brokenIcons = await page.locator('[data-lucide]:not(:has(svg))').count();
    expect(brokenIcons).toBe(0);
  });
});

test.describe('Navegação e Links', () => {
  
  test('link para seção Benefícios deve funcionar', async ({ page }) => {
    await page.goto('/');
    
    // Clicar no link
    await page.click('a[href="#beneficios"]');
    
    // Verificar URL
    await expect(page).toHaveURL(/#beneficios/);
    
    // Verificar que seção existe
    const section = page.locator('#beneficios');
    await expect(section).toBeVisible();
  });

  test('link para seção Planos deve funcionar', async ({ page }) => {
    await page.goto('/');
    
    // Clicar no link
    await page.click('a[href="#planos"]');
    
    // Verificar URL
    await expect(page).toHaveURL(/#planos/);
    
    // Verificar que seção existe
    const section = page.locator('#planos');
    await expect(section).toBeVisible();
  });

  test('link para WhatsApp deve abrir em nova aba', async ({ page, context }) => {
    await page.goto('/');
    
    // Verificar que link tem target="_blank"
    const whatsappLink = page.locator('a[href*="wa.me"]').first();
    const target = await whatsappLink.getAttribute('target');
    expect(target).toBe('_blank');
  });

  test('todas as seções com IDs devem existir', async ({ page }) => {
    await page.goto('/');
    
    // Lista de seções esperadas
    const sections = ['beneficios', 'planos'];
    
    for (const sectionId of sections) {
      const section = page.locator(`#${sectionId}`);
      await expect(section).toBeAttached();
    }
  });

  test('navegação suave (smooth scroll) deve funcionar', async ({ page }) => {
    await page.goto('/');
    
    // Obter posição inicial
    const initialScroll = await page.evaluate(() => window.scrollY);
    
    // Clicar em link para seção
    await page.click('a[href="#beneficios"]');
    
    // Aguardar scroll
    await page.waitForTimeout(1000);
    
    // Verificar que houve scroll
    const finalScroll = await page.evaluate(() => window.scrollY);
    expect(finalScroll).toBeGreaterThan(initialScroll);
  });

  test('logo deve redirecionar para topo da página', async ({ page }) => {
    await page.goto('/#beneficios');
    
    // Verificar que não está no topo
    let scrollY = await page.evaluate(() => window.scrollY);
    expect(scrollY).toBeGreaterThan(0);
    
    // Clicar no logo
    await page.click('nav img[alt*="Logo"]');
    
    // Aguardar scroll
    await page.waitForTimeout(1000);
    
    // Verificar que voltou ao topo
    scrollY = await page.evaluate(() => window.scrollY);
    expect(scrollY).toBe(0);
  });

  test('não deve haver links quebrados (404)', async ({ page }) => {
    await page.goto('/');
    
    // Obter todos os links internos
    const links = await page.locator('a[href^="/"], a[href^="./"]').all();
    
    for (const link of links) {
      const href = await link.getAttribute('href');
      
      if (href && !href.startsWith('#')) {
        // Tentar acessar o link
        const response = await page.goto(href);
        expect(response?.status()).not.toBe(404);
        
        // Voltar para página inicial
        await page.goto('/');
      }
    }
  });

  test('página deve carregar sem erros de console', async ({ page }) => {
    const consoleErrors = [];
    
    page.on('console', msg => {
      if (msg.type() === 'error') {
        consoleErrors.push(msg.text());
      }
    });
    
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    
    // Verificar que não há erros críticos
    const criticalErrors = consoleErrors.filter(err => 
      !err.includes('favicon') && // Ignorar erros de favicon
      !err.includes('analytics') // Ignorar erros de analytics
    );
    
    expect(criticalErrors.length).toBe(0);
  });

  test('todos os assets (imagens) devem carregar', async ({ page }) => {
    const failedImages = [];
    
    page.on('response', response => {
      if (response.request().resourceType() === 'image' && response.status() !== 200) {
        failedImages.push(response.url());
      }
    });
    
    await page.goto('/');
    await page.waitForLoadState('networkidle');
    
    expect(failedImages.length).toBe(0);
  });
});
