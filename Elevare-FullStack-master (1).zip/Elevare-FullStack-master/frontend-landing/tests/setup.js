/**
 * Setup para Testes Jest
 * Configurações globais e mocks
 * 
 * Criado em: 28/11/2025
 */

// Mock do localStorage
const localStorageMock = {
    getItem: jest.fn(),
    setItem: jest.fn(),
    removeItem: jest.fn(),
    clear: jest.fn(),
};
global.localStorage = localStorageMock;

// Mock do sessionStorage
const sessionStorageMock = {
    getItem: jest.fn(),
    setItem: jest.fn(),
    removeItem: jest.fn(),
    clear: jest.fn(),
};
global.sessionStorage = sessionStorageMock;

// Mock do navigator
global.navigator = {
    userAgent: 'Mozilla/5.0 (Test Environment)',
    language: 'pt-BR',
};

// Mock do document
global.document = {
    referrer: '',
    title: 'Test Page',
    querySelector: jest.fn(),
    querySelectorAll: jest.fn(() => []),
    getElementById: jest.fn(),
    createElement: jest.fn(() => ({
        style: {},
        classList: {
            add: jest.fn(),
            remove: jest.fn(),
            toggle: jest.fn(),
        },
    })),
};

// Mock do window
global.window = {
    screen: {
        width: 1920,
        height: 1080,
    },
    location: {
        href: 'http://localhost:5173',
        pathname: '/',
    },
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
};

// Mock do Intl
global.Intl = {
    DateTimeFormat: jest.fn(() => ({
        resolvedOptions: () => ({ timeZone: 'America/Sao_Paulo' }),
    })),
};

// Limpar mocks antes de cada teste
beforeEach(() => {
    localStorageMock.getItem.mockClear();
    localStorageMock.setItem.mockClear();
    localStorageMock.removeItem.mockClear();
    localStorageMock.clear.mockClear();
    
    sessionStorageMock.getItem.mockClear();
    sessionStorageMock.setItem.mockClear();
    sessionStorageMock.removeItem.mockClear();
    sessionStorageMock.clear.mockClear();
});
