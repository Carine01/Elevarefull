// @ts-check
const { test, expect } = require('@playwright/test');

/**
 * Testes E2E para Menu Mobile
 * Verifica funcionalidade do menu mobile em diferentes dispositivos
 */

test.describe('Menu Mobile', () => {
  
  test('deve exibir botão de toggle do menu mobile em telas pequenas', async ({ page }) => {
    // Configurar viewport mobile
    await page.setViewportSize({ width: 375, height: 667 });
    await page.goto('/');
    
    // Verificar que botão de toggle está visível
    const toggleButton = page.locator('#mobile-menu-toggle');
    await expect(toggleButton).toBeVisible();
  });

  test('deve ocultar botão de toggle do menu mobile em telas grandes', async ({ page }) => {
    // Configurar viewport desktop
    await page.setViewportSize({ width: 1920, height: 1080 });
    await page.goto('/');
    
    // Verificar que botão de toggle está oculto
    const toggleButton = page.locator('#mobile-menu-toggle');
    await expect(toggleButton).toBeHidden();
  });

  test('deve abrir menu mobile ao clicar no botão toggle', async ({ page }) => {
    // Configurar viewport mobile
    await page.setViewportSize({ width: 375, height: 667 });
    await page.goto('/');
    
    // Verificar que menu está fechado inicialmente
    const mobileMenu = page.locator('#mobile-menu');
    await expect(mobileMenu).toHaveClass(/hidden/);
    
    // Clicar no botão toggle
    await page.click('#mobile-menu-toggle');
    
    // Verificar que menu foi aberto
    await expect(mobileMenu).not.toHaveClass(/hidden/);
    await expect(mobileMenu).toBeVisible();
  });

  test('deve fechar menu mobile ao clicar novamente no botão toggle', async ({ page }) => {
    // Configurar viewport mobile
    await page.setViewportSize({ width: 375, height: 667 });
    await page.goto('/');
    
    // Abrir menu
    await page.click('#mobile-menu-toggle');
    await expect(page.locator('#mobile-menu')).toBeVisible();
    
    // Fechar menu
    await page.click('#mobile-menu-toggle');
    await expect(page.locator('#mobile-menu')).toHaveClass(/hidden/);
  });

  test('deve exibir links de navegação no menu mobile', async ({ page }) => {
    // Configurar viewport mobile
    await page.setViewportSize({ width: 375, height: 667 });
    await page.goto('/');
    
    // Abrir menu
    await page.click('#mobile-menu-toggle');
    
    // Verificar links
    const mobileMenu = page.locator('#mobile-menu');
    await expect(mobileMenu.locator('a:has-text("Benefícios")')).toBeVisible();
    await expect(mobileMenu.locator('a:has-text("Planos")')).toBeVisible();
  });

  test('deve funcionar navegação no menu mobile', async ({ page }) => {
    // Configurar viewport mobile
    await page.setViewportSize({ width: 375, height: 667 });
    await page.goto('/');
    
    // Abrir menu
    await page.click('#mobile-menu-toggle');
    
    // Clicar em link de navegação
    await page.click('#mobile-menu a[href="#beneficios"]');
    
    // Verificar que navegou para seção
    await expect(page).toHaveURL(/#beneficios/);
  });

  test('deve funcionar em iPhone 12', async ({ page }) => {
    // Configurar viewport iPhone 12
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto('/');
    
    // Verificar que menu mobile funciona
    await page.click('#mobile-menu-toggle');
    await expect(page.locator('#mobile-menu')).toBeVisible();
  });

  test('deve funcionar em iPad Pro', async ({ page }) => {
    // Configurar viewport iPad Pro
    await page.setViewportSize({ width: 1024, height: 1366 });
    await page.goto('/');
    
    // Em tablets, pode ou não mostrar menu mobile dependendo do breakpoint
    // Verificar que a página carrega corretamente
    await expect(page.locator('nav')).toBeVisible();
  });

  test('deve alternar classe hidden corretamente', async ({ page }) => {
    // Configurar viewport mobile
    await page.setViewportSize({ width: 375, height: 667 });
    await page.goto('/');
    
    const mobileMenu = page.locator('#mobile-menu');
    
    // Estado inicial: hidden
    await expect(mobileMenu).toHaveClass(/hidden/);
    
    // Abrir: remover hidden
    await page.click('#mobile-menu-toggle');
    await expect(mobileMenu).not.toHaveClass(/hidden/);
    
    // Fechar: adicionar hidden
    await page.click('#mobile-menu-toggle');
    await expect(mobileMenu).toHaveClass(/hidden/);
  });

  test('deve manter funcionalidade após múltiplas aberturas/fechamentos', async ({ page }) => {
    // Configurar viewport mobile
    await page.setViewportSize({ width: 375, height: 667 });
    await page.goto('/');
    
    // Abrir e fechar 3 vezes
    for (let i = 0; i < 3; i++) {
      await page.click('#mobile-menu-toggle');
      await expect(page.locator('#mobile-menu')).toBeVisible();
      
      await page.click('#mobile-menu-toggle');
      await expect(page.locator('#mobile-menu')).toHaveClass(/hidden/);
    }
  });

  test('ícones devem aparecer no menu mobile', async ({ page }) => {
    // Configurar viewport mobile
    await page.setViewportSize({ width: 375, height: 667 });
    await page.goto('/');
    
    // Abrir menu
    await page.click('#mobile-menu-toggle');
    
    // Verificar que ícones Lucide foram renderizados
    const icons = page.locator('#mobile-menu svg');
    const iconCount = await icons.count();
    
    // Deve haver pelo menos 1 ícone
    expect(iconCount).toBeGreaterThan(0);
  });
});
