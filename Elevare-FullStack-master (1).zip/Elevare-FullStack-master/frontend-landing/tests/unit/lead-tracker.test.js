/**
 * Testes Unitários - Lead Tracker
 * Cobertura de funcionalidades principais
 *
 * Criado em: 28/11/2025
 */

describe("🎯 Lead Tracker - Unit Tests", () => {
  let LeadTracker;
  let tracker;

  beforeEach(() => {
    // Simula ambiente do navegador
    global.Date.now = jest.fn(() => 1732819200000);
    global.Math.random = jest.fn(() => 0.123456789);

    // Mock localStorage
    const store = {};
    global.localStorage = {
      getItem: jest.fn(key => store[key] || null),
      setItem: jest.fn((key, value) => {
        store[key] = value;
      }),
      removeItem: jest.fn(key => {
        delete store[key];
      }),
      clear: jest.fn(() => {
        for (let key in store) delete store[key];
      })
    };

    // Mock sessionStorage
    const sessionStore = {};
    global.sessionStorage = {
      getItem: jest.fn(key => sessionStore[key] || null),
      setItem: jest.fn((key, value) => {
        sessionStore[key] = value;
      }),
      removeItem: jest.fn(key => {
        delete sessionStore[key];
      }),
      clear: jest.fn(() => {
        for (let key in sessionStore) delete sessionStore[key];
      })
    };

    // Simula LeadTracker class
    LeadTracker = class {
      constructor() {
        this.leadId = this.getOrCreateLeadId();
        this.pageLoadTime = Date.now();
        this.milestones = {
          "scroll-50": false,
          "form-focus": false,
          "plan-open": false,
          "time-30s": false,
          "time-60s": false
        };
      }

      getOrCreateLeadId() {
        let leadId = localStorage.getItem("leadId");
        if (!leadId) {
          leadId = "lead_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9);
          localStorage.setItem("leadId", leadId);
          localStorage.setItem("leadCreatedAt", new Date().toISOString());
        }
        return leadId;
      }

      trackMilestone(milestone) {
        if (!this.milestones[milestone]) {
          this.milestones[milestone] = true;
          const milestones = JSON.parse(localStorage.getItem("milestones") || "{}");
          milestones[milestone] = {
            achieved: true,
            timestamp: new Date().toISOString()
          };
          localStorage.setItem("milestones", JSON.stringify(milestones));
        }
      }

      getLeadScore() {
        const pages = JSON.parse(localStorage.getItem("pageViews") || "[]");
        const visits = parseInt(sessionStorage.getItem("pageVisits") || "0");
        const milestonesCompleted = Object.values(this.milestones).filter(Boolean).length;
        const timeOnPage = Math.floor((Date.now() - this.pageLoadTime) / 1000);

        let score = 0;
        score += Math.min(20, pages.length * 5);
        score += Math.min(20, visits * 4);
        score += (milestonesCompleted / Object.keys(this.milestones).length) * 30;
        score += Math.min(30, (timeOnPage / 120) * 30);

        return Math.min(100, Math.round(score));
      }

      getLeadData() {
        return {
          leadId: this.leadId,
          score: this.getLeadScore(),
          milestones: this.milestones,
          pageViews: JSON.parse(localStorage.getItem("pageViews") || "[]"),
          visits: parseInt(sessionStorage.getItem("pageVisits") || "0"),
          timeOnPage: Math.floor((Date.now() - this.pageLoadTime) / 1000),
          userAgent: navigator.userAgent,
          referrer: document.referrer,
          screenResolution: `${window.screen.width}x${window.screen.height}`,
          language: navigator.language,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
          createdAt: localStorage.getItem("leadCreatedAt"),
          highIntent: localStorage.getItem("highIntentLead") === "true"
        };
      }
    };

    tracker = new LeadTracker();
  });

  afterEach(() => {
    localStorage.clear();
    sessionStorage.clear();
  });

  describe("Constructor e Inicialização", () => {
    test("deve criar ID único no primeiro acesso", () => {
      expect(tracker.leadId).toMatch(/^lead_\d+_[a-z0-9]+$/);
      expect(localStorage.getItem("leadId")).toBe(tracker.leadId);
    });

    test("deve reutilizar ID existente", () => {
      const id1 = tracker.leadId;
      const tracker2 = new LeadTracker();
      expect(tracker2.leadId).toBe(id1);
    });

    test("deve inicializar milestones como false", () => {
      expect(tracker.milestones["scroll-50"]).toBe(false);
      expect(tracker.milestones["form-focus"]).toBe(false);
      expect(tracker.milestones["plan-open"]).toBe(false);
      expect(tracker.milestones["time-30s"]).toBe(false);
      expect(tracker.milestones["time-60s"]).toBe(false);
    });

    test("deve salvar timestamp de criação", () => {
      expect(localStorage.getItem("leadCreatedAt")).toBeTruthy();
    });
  });

  describe("Milestone Tracking", () => {
    test("deve marcar milestone corretamente", () => {
      expect(tracker.milestones["scroll-50"]).toBe(false);
      tracker.trackMilestone("scroll-50");
      expect(tracker.milestones["scroll-50"]).toBe(true);
    });

    test("deve salvar milestone no localStorage", () => {
      tracker.trackMilestone("form-focus");
      const milestones = JSON.parse(localStorage.getItem("milestones"));
      expect(milestones["form-focus"]).toBeDefined();
      expect(milestones["form-focus"].achieved).toBe(true);
    });

    test("deve evitar duplicatas de milestones", () => {
      tracker.trackMilestone("plan-open");
      tracker.trackMilestone("plan-open");
      tracker.trackMilestone("plan-open");
      expect(tracker.milestones["plan-open"]).toBe(true);
    });

    test("deve rastrear múltiplos milestones", () => {
      tracker.trackMilestone("scroll-50");
      tracker.trackMilestone("form-focus");
      tracker.trackMilestone("plan-open");

      expect(tracker.milestones["scroll-50"]).toBe(true);
      expect(tracker.milestones["form-focus"]).toBe(true);
      expect(tracker.milestones["plan-open"]).toBe(true);
    });
  });

  describe("Lead Scoring", () => {
    test("deve calcular score 0 para visitante novo", () => {
      expect(tracker.getLeadScore()).toBe(0);
    });

    test("deve calcular score com milestones", () => {
      tracker.trackMilestone("scroll-50");
      const score = tracker.getLeadScore();
      expect(score).toBeGreaterThan(0);
      expect(score).toBeLessThanOrEqual(100);
    });

    test("deve calcular score com pageViews", () => {
      localStorage.setItem("pageViews", JSON.stringify(["/page1", "/page2", "/page3"]));
      const score = tracker.getLeadScore();
      expect(score).toBeGreaterThanOrEqual(15); // 3 pages * 5 = 15
    });

    test("deve calcular score com visits", () => {
      sessionStorage.setItem("pageVisits", "3");
      const score = tracker.getLeadScore();
      expect(score).toBeGreaterThanOrEqual(12); // 3 visits * 4 = 12
    });

    test("score máximo deve ser 100", () => {
      localStorage.setItem("pageViews", JSON.stringify(new Array(100).fill("/page")));
      sessionStorage.setItem("pageVisits", "100");
      tracker.trackMilestone("scroll-50");
      tracker.trackMilestone("form-focus");
      tracker.trackMilestone("plan-open");
      tracker.trackMilestone("time-30s");
      tracker.trackMilestone("time-60s");

      const score = tracker.getLeadScore();
      expect(score).toBeLessThanOrEqual(100);
    });
  });

  describe("Data Collection", () => {
    test("deve coletar leadId", () => {
      const data = tracker.getLeadData();
      expect(data.leadId).toBe(tracker.leadId);
    });

    test("deve coletar score", () => {
      const data = tracker.getLeadData();
      expect(data.score).toBeDefined();
      expect(typeof data.score).toBe("number");
    });

    test("deve coletar milestones", () => {
      tracker.trackMilestone("scroll-50");
      const data = tracker.getLeadData();
      expect(data.milestones["scroll-50"]).toBe(true);
    });

    test("deve coletar userAgent", () => {
      const data = tracker.getLeadData();
      expect(data.userAgent).toBe(navigator.userAgent);
    });

    test("deve coletar screenResolution", () => {
      const data = tracker.getLeadData();
      expect(data.screenResolution).toMatch(/^\d+x\d+$/);
    });

    test("deve coletar language", () => {
      const data = tracker.getLeadData();
      expect(data.language).toBe(navigator.language);
    });

    test("deve coletar timezone", () => {
      const data = tracker.getLeadData();
      expect(data.timezone).toBeDefined();
    });
  });

  describe("Edge Cases", () => {
    test("deve lidar com localStorage vazio", () => {
      localStorage.clear();
      const newTracker = new LeadTracker();
      expect(newTracker.leadId).toBeDefined();
    });

    test("deve lidar com pageViews inválido", () => {
      localStorage.setItem("pageViews", "invalid json");
      const score = tracker.getLeadScore();
      expect(score).toBeDefined();
    });

    test("deve lidar com visits não numérico", () => {
      sessionStorage.setItem("pageVisits", "abc");
      const score = tracker.getLeadScore();
      expect(score).toBeDefined();
    });
  });
});
