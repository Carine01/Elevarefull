# 🎨 Templates do Frontend Elevare

Coleção de templates prontos para uso no projeto Elevare.

---

## 📋 Templates Disponíveis

### 1. Landing Page Profissional (`landing-alt.html`)

**Características:**
- ✅ Design premium com gradientes lavanda
- ✅ Hero section impactante
- ✅ 7 cards de benefícios
- ✅ Seção de demonstração (antes/depois)
- ✅ 3 depoimentos de clientes
- ✅ Pricing (3 planos: mensal, trimestral, vitalício)
- ✅ FAQ com 6 perguntas collapsibles
- ✅ SEO otimizado
- ✅ Meta Pixel + Google Analytics prontos

**Personalização necessária:**
- [ ] Trocar imagens (placeholders atuais)
- [ ] Atualizar textos dos depoimentos
- [ ] Configurar Meta Pixel ID
- [ ] Ajustar preços dos planos

**Estimativa:** 4-6 horas

---

### 2. Dashboard SaaS (`dashboard.html`)

**Características:**
- ✅ Interface completa de gestão
- ✅ Sidebar com navegação
- ✅ Cards de métricas (leads, conversões, score médio)
- ✅ Gráficos Chart.js (leads por dia, conversões por fonte)
- ✅ Tabela de leads com ações (ver, editar, WhatsApp, deletar)
- ✅ Modal de detalhes do lead
- ✅ Integração WhatsApp (link direto)
- ✅ Sistema de gamificação (conquistas, pontos)
- ✅ Filtros e busca em tempo real

**Integração:**
```javascript
import { IARAApiClient, IARADashboard } from '../js/iara-integration.js';

const api = new IARAApiClient('/api/v1', authToken);
const dashboard = new IARADashboard(api);
dashboard.initializeDashboard();
```

---

### 3. Formulário de Teste (`form-test.html`)

**Características:**
- ✅ Formulário isolado para testes
- ✅ Validação em tempo real
- ✅ Feedback visual (success/error)
- ✅ Integração direta com API

**Uso:** Testar captura de leads sem landing completa

---

## 🚀 Como Usar

### Preview Local

```bash
# Servir arquivos estáticos
npx http-server frontend-landing/templates -p 8080

# Acessar templates:
# http://localhost:8080/landing-alt.html
# http://localhost:8080/dashboard.html
# http://localhost:8080/form-test.html
```

### Substituir Landing Atual

```bash
# Backup do atual
mv frontend-landing/index.html frontend-landing/index.backup.html

# Usar landing profissional
cp frontend-landing/templates/landing-alt.html frontend-landing/index.html
```

---

## 🎨 Personalização

### Landing Page

#### 1. Imagens

```html
<!-- Logo (linha 80) -->
<img src="../img/seu-logo.png" alt="Seu SaaS">

<!-- Hero (linha 150) -->
<img src="../img/hero-dashboard.jpg" alt="Dashboard">

<!-- Depoimentos (linha 300) -->
<img src="../img/cliente1.jpg" alt="Cliente 1">
<img src="../img/cliente2.jpg" alt="Cliente 2">
<img src="../img/cliente3.jpg" alt="Cliente 3">
```

**Tamanhos recomendados:**
- Logo: 200x60px PNG transparente
- Hero: 1200x800px WebP otimizado
- Depoimentos: 100x100px círculo

#### 2. Textos

```html
<!-- Meta tags (linha 15) -->
<title>Seu SaaS - Assistente Inteligente</title>
<meta name="description" content="Sua descrição aqui">

<!-- Hero (linha 100) -->
<h1>Seu Título Impactante</h1>
<p>Sua proposta de valor única</p>

<!-- Depoimentos (linha 350) -->
<p>"Seu depoimento real aqui"</p>
<h4>Nome do Cliente - Clínica X</h4>
```

#### 3. Analytics

```html
<!-- Meta Pixel (linha 600) -->
<script>
  fbq('init', 'SEU_PIXEL_ID');
</script>

<!-- Google Analytics (linha 620) -->
<script>
  gtag('config', 'G-SEU_TRACKING_ID');
</script>
```

### Dashboard

#### 1. Cores

```css
/* Linha 50 */
:root {
  --primary: #8B5CF6;      /* Roxo */
  --secondary: #EC4899;    /* Rosa */
  --success: #10B981;      /* Verde */
  --danger: #EF4444;       /* Vermelho */
}
```

#### 2. Gamificação

```javascript
// Linha 800
const achievements = [
  { id: 1, name: 'Primeira Conversão', icon: '🎯', points: 100 },
  { id: 2, name: '10 Leads Capturados', icon: '📊', points: 250 },
  // Adicione suas conquistas
];
```

---

## 📚 Guias Relacionados

- [Guia de Personalização](../../docs/guias/GUIA_PERSONALIZACAO_LANDING.md)
- [Integração com Backend](../js/iara-integration.js)
- [Checklist de Deploy](../../docs/guias/CHECKLIST_MIGRACAO_DEPLOY.md)

---

**Criado por:** Manus AI  
**Data:** 28/11/2025
