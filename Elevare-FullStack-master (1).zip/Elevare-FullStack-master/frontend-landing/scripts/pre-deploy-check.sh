#!/bin/bash

###############################################################################
# Script de Validação Pré-Deploy - Elevare Landing Page
# 
# Este script deve ser executado ANTES de qualquer deploy para garantir que
# todas as funcionalidades críticas estão implementadas e funcionando.
#
# Uso: ./scripts/pre-deploy-check.sh
###############################################################################

set -e  # Parar em caso de erro

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Contadores
PASSED=0
FAILED=0
WARNINGS=0

# Função para imprimir sucesso
success() {
    echo -e "${GREEN}✅ $1${NC}"
    ((PASSED++))
}

# Função para imprimir erro
error() {
    echo -e "${RED}❌ $1${NC}"
    ((FAILED++))
}

# Função para imprimir aviso
warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
    ((WARNINGS++))
}

echo "=================================================="
echo "🔍 VALIDAÇÃO PRÉ-DEPLOY - ELEVARE LANDING PAGE"
echo "=================================================="
echo ""

# 1. Verificar Arquivos JavaScript Obrigatórios
echo "📁 Verificando arquivos JavaScript..."

if [ -f "js/app.js" ]; then
    success "js/app.js existe"
else
    error "js/app.js NÃO ENCONTRADO!"
fi

if [ -f "js/api.js" ]; then
    success "js/api.js existe"
else
    error "js/api.js NÃO ENCONTRADO!"
fi

if [ -f "js/auth.js" ]; then
    success "js/auth.js existe"
else
    error "js/auth.js NÃO ENCONTRADO!"
fi

echo ""

# 2. Verificar Funções Críticas em app.js
echo "🔧 Verificando funções críticas em app.js..."

if [ -f "js/app.js" ]; then
    if grep -q "function updateAuthUI" js/app.js || grep -q "updateAuthUI.*=" js/app.js; then
        success "updateAuthUI() implementada"
    else
        error "updateAuthUI() NÃO ENCONTRADA!"
    fi

    if grep -q "function openLoginModal" js/app.js || grep -q "openLoginModal.*=" js/app.js; then
        success "openLoginModal() implementada"
    else
        error "openLoginModal() NÃO ENCONTRADA!"
    fi

    if grep -q "function closeLoginModal" js/app.js || grep -q "closeLoginModal.*=" js/app.js; then
        success "closeLoginModal() implementada"
    else
        error "closeLoginModal() NÃO ENCONTRADA!"
    fi

    if grep -q "function openRegisterModal" js/app.js || grep -q "openRegisterModal.*=" js/app.js; then
        success "openRegisterModal() implementada"
    else
        error "openRegisterModal() NÃO ENCONTRADA!"
    fi

    if grep -q "function closeRegisterModal" js/app.js || grep -q "closeRegisterModal.*=" js/app.js; then
        success "closeRegisterModal() implementada"
    else
        error "closeRegisterModal() NÃO ENCONTRADA!"
    fi

    if grep -q "function logout" js/app.js || grep -q "logout.*=" js/app.js; then
        success "logout() implementada"
    else
        error "logout() NÃO ENCONTRADA!"
    fi
fi

echo ""

# 3. Verificar Páginas HTML
echo "📄 Verificando páginas HTML..."

if [ -f "index.html" ]; then
    success "index.html existe"
else
    error "index.html NÃO ENCONTRADO!"
fi

if [ -f "dashboard.html" ]; then
    success "dashboard.html existe"
else
    warning "dashboard.html não encontrado (opcional)"
fi

echo ""

# 4. Verificar Modais no HTML
echo "🪟 Verificando modais no HTML..."

if [ -f "index.html" ]; then
    if grep -q 'id="loginModal"' index.html; then
        success "Modal de login presente"
    else
        error "Modal de login NÃO ENCONTRADO!"
    fi

    if grep -q 'id="registerModal"' index.html; then
        success "Modal de registro presente"
    else
        error "Modal de registro NÃO ENCONTRADO!"
    fi

    if grep -q 'id="loginForm"' index.html; then
        success "Formulário de login presente"
    else
        error "Formulário de login NÃO ENCONTRADO!"
    fi

    if grep -q 'id="registerForm"' index.html; then
        success "Formulário de registro presente"
    else
        error "Formulário de registro NÃO ENCONTRADO!"
    fi
fi

echo ""

# 5. Verificar Imagens
echo "🖼️  Verificando imagens..."

if [ -d "images" ]; then
    success "Pasta images/ existe"
    
    image_count=$(find images -type f \( -name "*.jpg" -o -name "*.png" -o -name "*.webp" \) | wc -l)
    
    if [ $image_count -gt 0 ]; then
        success "$image_count imagens encontradas"
    else
        error "Nenhuma imagem encontrada!"
    fi
else
    error "Pasta images/ NÃO ENCONTRADA!"
fi

echo ""

# 6. Verificar Scripts Externos
echo "📦 Verificando scripts externos..."

if [ -f "index.html" ]; then
    if grep -q "tailwindcss" index.html; then
        success "Tailwind CSS referenciado"
    else
        warning "Tailwind CSS não encontrado"
    fi

    if grep -q "lucide" index.html; then
        success "Lucide Icons referenciado"
    else
        warning "Lucide Icons não encontrado"
    fi
fi

echo ""

# 7. Verificar Menu Mobile
echo "📱 Verificando menu mobile..."

if [ -f "index.html" ]; then
    if grep -q 'id="mobile-menu-toggle"' index.html; then
        success "Botão toggle do menu mobile presente"
    else
        error "Botão toggle do menu mobile NÃO ENCONTRADO!"
    fi

    if grep -q 'id="mobile-menu"' index.html; then
        success "Menu mobile presente"
    else
        error "Menu mobile NÃO ENCONTRADO!"
    fi
fi

echo ""

# 8. Verificar Botões de Autenticação
echo "🔐 Verificando botões de autenticação..."

if [ -f "index.html" ]; then
    if grep -q 'class.*auth-button' index.html; then
        success "Botão 'Entrar' presente"
    else
        warning "Botão 'Entrar' não encontrado"
    fi

    if grep -q 'class.*dashboard-button' index.html; then
        success "Botão 'Dashboard' presente"
    else
        warning "Botão 'Dashboard' não encontrado"
    fi

    if grep -q 'class.*logout-button' index.html; then
        success "Botão 'Sair' presente"
    else
        warning "Botão 'Sair' não encontrado"
    fi
fi

echo ""

# 9. Verificar Testes
echo "🧪 Verificando testes..."

if [ -d "tests" ]; then
    success "Pasta tests/ existe"
    
    test_count=$(find tests -name "*.spec.js" | wc -l)
    
    if [ $test_count -gt 0 ]; then
        success "$test_count arquivos de teste encontrados"
    else
        warning "Nenhum arquivo de teste encontrado"
    fi
else
    warning "Pasta tests/ não encontrada"
fi

echo ""

# 10. Verificar package.json
echo "📦 Verificando package.json..."

if [ -f "package.json" ]; then
    success "package.json existe"
    
    if grep -q '"test"' package.json; then
        success "Script de teste configurado"
    else
        warning "Script de teste não configurado"
    fi
else
    error "package.json NÃO ENCONTRADO!"
fi

echo ""

# Resumo Final
echo "=================================================="
echo "📊 RESUMO DA VALIDAÇÃO"
echo "=================================================="
echo -e "${GREEN}✅ Passou: $PASSED${NC}"
echo -e "${YELLOW}⚠️  Avisos: $WARNINGS${NC}"
echo -e "${RED}❌ Falhou: $FAILED${NC}"
echo ""

if [ $FAILED -gt 0 ]; then
    echo -e "${RED}🚫 DEPLOY BLOQUEADO!${NC}"
    echo "Corrija os erros acima antes de fazer deploy."
    exit 1
else
    echo -e "${GREEN}✅ PRONTO PARA DEPLOY!${NC}"
    echo "Todos os requisitos críticos foram atendidos."
    exit 0
fi
