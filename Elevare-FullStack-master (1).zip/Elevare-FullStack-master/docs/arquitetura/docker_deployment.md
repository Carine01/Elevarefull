# Docker Deployment - IARA SaaS

## Visão Geral

Este documento descreve como containerizar e implantar o módulo IARA como parte do SaaS Elevare usando Docker e Kubernetes.

## 1. Estrutura de Diretórios

```
iara-saas/
├── backend/
│   ├── src/
│   ├── package.json
│   ├── Dockerfile
│   └── .dockerignore
├── frontend/
│   ├── src/
│   ├── package.json
│   ├── Dockerfile
│   └── .dockerignore
├── nginx/
│   ├── nginx.conf
│   └── Dockerfile
├── docker-compose.yml
├── docker-compose.prod.yml
└── k8s/
    ├── namespace.yaml
    ├── configmap.yaml
    ├── secret.yaml
    ├── deployment.yaml
    ├── service.yaml
    └── ingress.yaml
```

## 2. Backend Dockerfile

```dockerfile
# backend/Dockerfile
FROM node:18-alpine

# Instalar dependências do sistema necessárias
RUN apk add --no-cache \
    postgresql-client \
    python3 \
    make \
    g++

# Criar diretório da aplicação
WORKDIR /app

# Copiar arquivos de dependências
COPY package*.json ./

# Instalar dependências
RUN npm ci --only=production

# Copiar código da aplicação
COPY . .

# Criar usuário não-root para segurança
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nodejs -u 1001

# Mudar permissões
RUN chown -R nodejs:nodejs /app
USER nodejs

# Expor porta
EXPOSE 3000

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
    CMD node healthcheck.js

# Comando para iniciar a aplicação
CMD ["npm", "start"]
```

## 3. Frontend Dockerfile

```dockerfile
# frontend/Dockerfile
# Multi-stage build para otimização

# Stage 1: Build
FROM node:18-alpine as build

WORKDIR /app

# Copiar arquivos de dependências
COPY package*.json ./

# Instalar dependências
RUN npm ci

# Copiar código fonte
COPY . .

# Build da aplicação
RUN npm run build

# Stage 2: Runtime
FROM nginx:alpine

# Copiar configuração do nginx
COPY nginx.conf /etc/nginx/nginx.conf

# Copiar arquivos buildados
COPY --from=build /app/dist /usr/share/nginx/html

# Expor porta
EXPOSE 80

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
    CMD curl -f http://localhost:80/ || exit 1

# Comando para iniciar o nginx
CMD ["nginx", "-g", "daemon off;"]
```

## 4. Docker Compose para Desenvolvimento

```yaml
# docker-compose.yml
version: '3.8'

services:
  # Banco de dados PostgreSQL
  postgres:
    image: postgres:15-alpine
    container_name: iara_postgres
    restart: unless-stopped
    environment:
      POSTGRES_USER: iara_user
      POSTGRES_PASSWORD: iara_password
      POSTGRES_DB: iara_dev
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./init-db.sql:/docker-entrypoint-initdb.d/init-db.sql
    networks:
      - iara_network

  # Redis para cache e filas
  redis:
    image: redis:7-alpine
    container_name: iara_redis
    restart: unless-stopped
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    networks:
      - iara_network

  # Backend API
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    container_name: iara_backend
    restart: unless-stopped
    environment:
      NODE_ENV: development
      PORT: 3000
      DATABASE_URL: postgres://iara_user:iara_password@postgres:5432/iara_dev
      REDIS_URL: redis://redis:6379
      JWT_SECRET: your-jwt-secret-here
      WHATSAPP_API_KEY: your-whatsapp-api-key
    ports:
      - "3000:3000"
    depends_on:
      - postgres
      - redis
    volumes:
      - ./backend/src:/app/src
      - ./backend/logs:/app/logs
    networks:
      - iara_network

  # Frontend
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    container_name: iara_frontend
    restart: unless-stopped
    ports:
      - "8080:80"
    depends_on:
      - backend
    networks:
      - iara_network

  # Nginx como proxy reverso
  nginx:
    image: nginx:alpine
    container_name: iara_nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./nginx/ssl:/etc/nginx/ssl:ro
    depends_on:
      - backend
      - frontend
    networks:
      - iara_network

volumes:
  postgres_data:
  redis_data:

networks:
  iara_network:
    driver: bridge
```

## 5. Docker Compose para Produção

```yaml
# docker-compose.prod.yml
version: '3.8'

services:
  postgres:
    image: postgres:15-alpine
    restart: always
    environment:
      POSTGRES_USER: ${POSTGRES_USER}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      POSTGRES_DB: ${POSTGRES_DB}
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./backups:/backups
    networks:
      - iara_network
    deploy:
      resources:
        limits:
          memory: 1G
          cpus: '0.5'

  redis:
    image: redis:7-alpine
    restart: always
    command: redis-server --appendonly yes --maxmemory 256mb --maxmemory-policy allkeys-lru
    volumes:
      - redis_data:/data
    networks:
      - iara_network
    deploy:
      resources:
        limits:
          memory: 256M

  backend:
    image: your-registry/iara-backend:latest
    restart: always
    environment:
      NODE_ENV: production
      PORT: 3000
      DATABASE_URL: postgres://${POSTGRES_USER}:${POSTGRES_PASSWORD}@postgres:5432/${POSTGRES_DB}
      REDIS_URL: redis://redis:6379
      JWT_SECRET: ${JWT_SECRET}
      WHATSAPP_API_KEY: ${WHATSAPP_API_KEY}
    depends_on:
      - postgres
      - redis
    networks:
      - iara_network
    deploy:
      replicas: 3
      resources:
        limits:
          memory: 512M
          cpus: '0.5'
      update_config:
        parallelism: 1
        delay: 10s
      restart_policy:
        condition: on-failure
        delay: 5s
        max_attempts: 3

  frontend:
    image: your-registry/iara-frontend:latest
    restart: always
    depends_on:
      - backend
    networks:
      - iara_network
    deploy:
      replicas: 2
      resources:
        limits:
          memory: 128M

  nginx:
    image: nginx:alpine
    restart: always
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.prod.conf:/etc/nginx/nginx.conf:ro
      - ./nginx/ssl:/etc/nginx/ssl:ro
    depends_on:
      - backend
      - frontend
    networks:
      - iara_network
    deploy:
      resources:
        limits:
          memory: 128M

  # Monitoramento com Prometheus
  prometheus:
    image: prom/prometheus:latest
    restart: always
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - prometheus_data:/prometheus
    networks:
      - iara_network

  # Visualização com Grafana
  grafana:
    image: grafana/grafana:latest
    restart: always
    ports:
      - "3001:3000"
    environment:
      GF_SECURITY_ADMIN_PASSWORD: ${GRAFANA_PASSWORD}
    volumes:
      - grafana_data:/var/lib/grafana
    networks:
      - iara_network

volumes:
  postgres_data:
  redis_data:
  prometheus_data:
  grafana_data:

networks:
  iara_network:
    driver: overlay
    attachable: true
```

## 6. Configuração do Nginx

```nginx
# nginx/nginx.conf
upstream backend {
    server backend:3000;
}

upstream frontend {
    server frontend:80;
}

server {
    listen 80;
    server_name localhost;

    # Frontend
    location / {
        proxy_pass http://frontend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Backend API
    location /api/ {
        proxy_pass http://backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Configurações para WebSockets
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_cache_bypass $http_upgrade;
    }

    # Health checks
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied expired no-cache no-store private;
    gzip_types
        application/javascript
        application/json
        application/xml+rss
        application/atom+xml
        image/svg+xml;
}
```

## 7. Kubernetes Deployment

```yaml
# k8s/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: iara-backend
  namespace: iara
  labels:
    app: iara-backend
spec:
  replicas: 3
  selector:
    matchLabels:
      app: iara-backend
  template:
    metadata:
      labels:
        app: iara-backend
    spec:
      containers:
      - name: backend
        image: your-registry/iara-backend:latest
        ports:
        - containerPort: 3000
        env:
        - name: NODE_ENV
          value: "production"
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: iara-secrets
              key: database-url
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: iara-secrets
              key: jwt-secret
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 3000
          initialDelaySeconds: 5
          periodSeconds: 5
```

## 8. ConfigMap para Kubernetes

```yaml
# k8s/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: iara-config
  namespace: iara
data:
  NODE_ENV: "production"
  PORT: "3000"
  REDIS_URL: "redis://redis-service:6379"
  LOG_LEVEL: "info"
  MAX_REQUESTS_PER_MINUTE: "100"
  ENABLE_METRICS: "true"
```

## 9. Secrets para Kubernetes

```yaml
# k8s/secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: iara-secrets
  namespace: iara
type: Opaque
data:
  # Base64 encoded values
  database-url: <base64-encoded-database-url>
  jwt-secret: <base64-encoded-jwt-secret>
  whatsapp-api-key: <base64-encoded-whatsapp-api-key>
  redis-password: <base64-encoded-redis-password>
```

## 10. Comandos Úteis

### Desenvolvimento
```bash
# Construir e iniciar todos os serviços
docker-compose up --build

# Iniciar em modo detached
docker-compose up -d

# Ver logs
docker-compose logs -f backend

# Parar todos os serviços
docker-compose down

# Limpar volumes
docker-compose down -v
```

### Produção
```bash
# Deploy com Docker Swarm
docker stack deploy -c docker-compose.prod.yml iara

# Ver serviços rodando
docker service ls

# Escala horizontal
docker service scale iara_backend=5

# Rollback
docker service update --rollback iara_backend
```

### Kubernetes
```bash
# Aplicar configurações
kubectl apply -f k8s/

# Ver pods
kubectl get pods -n iara

# Ver logs
kubectl logs -f deployment/iara-backend -n iara

# Escalar deployment
kubectl scale deployment iara-backend --replicas=5 -n iara

# Rollout
kubectl rollout status deployment/iara-backend -n iara
```

## 11. Monitoramento

### Prometheus Metrics
```javascript
// backend/src/metrics.js
const client = require('prom-client');

// Criar registros de métricas
const register = new client.Registry();

// Métricas padrão
client.collectDefaultMetrics({ register });

// Métricas customizadas
const httpRequestDuration = new client.Histogram({
  name: 'http_request_duration_seconds',
  help: 'Duration of HTTP requests in seconds',
  labelNames: ['method', 'route', 'status_code'],
  buckets: [0.1, 0.5, 1, 2, 5]
});

const leadsTotal = new client.Counter({
  name: 'iara_leads_total',
  help: 'Total number of leads created',
  labelNames: ['tenant_id', 'source']
});

const messagesSent = new client.Counter({
  name: 'iara_messages_sent_total',
  help: 'Total number of messages sent',
  labelNames: ['tenant_id', 'channel', 'status']
});

register.registerMetric(httpRequestDuration);
register.registerMetric(leadsTotal);
register.registerMetric(messagesSent);

module.exports = { register, httpRequestDuration, leadsTotal, messagesSent };
```

## 12. Segurança

### Docker Security
```dockerfile
# Security best practices
FROM node:18-alpine

# Não rodar como root
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nodejs -u 1001

# Remover pacotes desnecessários
RUN apk del --purge -v vcs

# Atualizar pacotes de segurança
RUN apk update && apk upgrade

# Usar usuário não-root
USER nodejs

# Definir diretório de trabalho
WORKDIR /app

# Copiar apenas arquivos necessários
COPY package*.json ./
RUN npm ci --only=production

COPY --chown=nodejs:nodejs . .

EXPOSE 3000

CMD ["npm", "start"]
```

## 13. Backup e Recuperação

### Backup Script
```bash
#!/bin/bash
# backup.sh

BACKUP_DIR="/backups"
DATE=$(date +%Y%m%d_%H%M%S)
TENANT_ID=$1

if [ -z "$TENANT_ID" ]; then
    echo "Uso: $0 <tenant_id>"
    exit 1
fi

# Backup do banco de dados
echo "Fazendo backup do banco de dados..."
docker exec iara_postgres pg_dump -U iara_user iara_${TENANT_ID} > ${BACKUP_DIR}/iara_${TENANT_ID}_${DATE}.sql

# Backup dos uploads/arquivos
echo "Fazendo backup dos arquivos..."
docker exec iara_backend tar -czf /tmp/uploads_${DATE}.tar.gz /app/uploads
docker cp iara_backend:/tmp/uploads_${DATE}.tar.gz ${BACKUP_DIR}/

# Compactar tudo
echo "Compactando backup..."
tar -czf ${BACKUP_DIR}/iara_full_backup_${TENANT_ID}_${DATE}.tar.gz \
    ${BACKUP_DIR}/iara_${TENANT_ID}_${DATE}.sql \
    ${BACKUP_DIR}/uploads_${DATE}.tar.gz

# Limpar arquivos temporários
rm ${BACKUP_DIR}/iara_${TENANT_ID}_${DATE}.sql
rm ${BACKUP_DIR}/uploads_${DATE}.tar.gz

echo "Backup concluído: iara_full_backup_${TENANT_ID}_${DATE}.tar.gz"
```

## 14. CI/CD Pipeline

### GitHub Actions
```yaml
# .github/workflows/deploy.yml
name: Deploy IARA SaaS

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    
    services:
      postgres:
        image: postgres:15
        env:
          POSTGRES_PASSWORD: test
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
        cache-dependency-path: backend/package-lock.json
    
    - name: Install dependencies
      run: |
        cd backend
        npm ci
    
    - name: Run tests
      run: |
        cd backend
        npm test
      env:
        DATABASE_URL: postgres://postgres:test@localhost:5432/test
    
    - name: Run linting
      run: |
        cd backend
        npm run lint

  build-and-deploy:
    needs: test
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Login to Docker Hub
      uses: docker/login-action@v2
      with:
        username: ${{ secrets.DOCKER_USERNAME }}
        password: ${{ secrets.DOCKER_PASSWORD }}
    
    - name: Build and push backend
      uses: docker/build-push-action@v4
      with:
        context: ./backend
        push: true
        tags: your-registry/iara-backend:latest
    
    - name: Build and push frontend
      uses: docker/build-push-action@v4
      with:
        context: ./frontend
        push: true
        tags: your-registry/iara-frontend:latest
    
    - name: Deploy to Kubernetes
      uses: azure/k8s-deploy@v4
      with:
        manifests: |
          k8s/deployment.yaml
          k8s/service.yaml
        images: |
          your-registry/iara-backend:latest
          your-registry/iara-frontend:latest
```

## 15. Troubleshooting

### Comandos de Debug
```bash
# Ver logs de um container específico
docker logs -f iara_backend

# Executar comandos dentro do container
docker exec -it iara_backend sh

# Ver recursos utilizados
docker stats

# Ver redes
docker network ls
docker network inspect iara_network

# Ver volumes
docker volume ls
docker volume inspect iara_postgres_data
```

### Problemas Comuns

1. **Container não inicia**
   - Verificar logs: `docker logs container_name`
   - Verificar portas em uso: `netstat -tuln`
   - Verificar permissões de arquivos

2. **Banco de dados não conecta**
   - Verificar variáveis de ambiente
   - Testar conexão manual: `docker exec -it postgres psql -U user -d db`
   - Verificar firewall e redes

3. **Performance lenta**
   - Verificar recursos alocados
   - Otimizar queries do banco
   - Configurar cache Redis
   - Usar CDN para assets estáticos

4. **Problemas de segurança**
   - Atualizar imagens base regularmente
   - Usar secrets para dados sensíveis
   - Configurar network policies no Kubernetes
   - Implementar rate limiting

## Conclusão

Este guia fornece uma estrutura completa para deploy do IARA SaaS usando Docker e Kubernetes. A containerização permite:

- **Escalabilidade**: Fácil escalonamento horizontal
- **Portabilidade**: Funciona em qualquer ambiente que suporte Docker
- **Isolamento**: Cada serviço rodando em seu próprio container
- **Manutenção**: Updates e rollbacks simplificados
- **Monitoramento**: Integração com ferramentas de observabilidade

Ajuste as configurações conforme necessário para seu ambiente específico e requisitos de segurança.