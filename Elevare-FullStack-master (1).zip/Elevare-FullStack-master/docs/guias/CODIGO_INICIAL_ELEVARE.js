// ============================================================================
// ELEVARE SIMPLIFICADO - CÓDIGO INICIAL
// ============================================================================
// Este código vai no Google Apps Script (Extensões → Apps Script)
// 
// INSTRUÇÕES:
// 1. Crie uma planilha no Google Sheets
// 2. Nomeie as abas: "Leads", "Templates", "Analytics", "Config"
// 3. Cole este código no Apps Script
// 4. Salve e execute a função "setupInicial()" uma vez
// 5. Pronto! Seu sistema ELEVARE está funcionando!
// ============================================================================

/**
 * FUNÇÃO PRINCIPAL: Setup Inicial do Sistema
 * Execute esta função uma vez para preparar tudo
 */
function setupInicial() {
  try {
    Logger.log("🚀 Iniciando setup do ELEVARE Simplificado...");
    
    // Criar estrutura das abas
    criarEstruturaAbas();
    
    // Povoar com dados de exemplo
    criarDadosExemplo();
    
    // Criar templates iniciais
    criarTemplatesIniciais();
    
    Logger.log("✅ Setup concluído com sucesso!");
    Logger.log("📋 Próximo passo: Teste o sistema com a função 'testarSistema()'");
    
  } catch (error) {
    Logger.log("❌ Erro no setup: " + error);
  }
}

/**
 * Cria a estrutura básica das abas da planilha
 */
function criarEstruturaAbas() {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  
  // Criar aba Leads se não existir
  var abaLeads = planilha.getSheetByName("Leads");
  if (!abaLeads) {
    abaLeads = planilha.insertSheet("Leads");
    // Cabeçalho da aba Leads
    abaLeads.getRange("A1:I1").setValues([[
      "Data Cadastro", "Nome", "Telefone", "Serviço", "Status", 
      "Score", "Temperatura", "Próxima Ação", "Última Interação"
    ]]);
    abaLeads.setFrozenRows(1);
  }
  
  // Criar aba Templates se não existir
  var abaTemplates = planilha.getSheetByName("Templates");
  if (!abaTemplates) {
    abaTemplates = planilha.insertSheet("Templates");
    // Cabeçalho da aba Templates
    abaTemplates.getRange("A1:E1").setValues([[
      "ID", "Nome", "Categoria", "Conteúdo", "Ativo"
    ]]);
    abaTemplates.setFrozenRows(1);
  }
  
  // Criar aba Analytics se não existir
  var abaAnalytics = planilha.getSheetByName("Analytics");
  if (!abaAnalytics) {
    abaAnalytics = planilha.insertSheet("Analytics");
    // Cabeçalho da aba Analytics
    abaAnalytics.getRange("A1:D1").setValues([[
      "Data", "Leads Novos", "Conversões", "Taxa Conversão"
    ]]);
    abaAnalytics.setFrozenRows(1);
  }
  
  // Criar aba Config se não existir
  var abaConfig = planilha.getSheetByName("Config");
  if (!abaConfig) {
    abaConfig = planilha.insertSheet("Config");
    // Configurações básicas
    abaConfig.getRange("A1:B1").setValues([["Configuração", "Valor"]]);
    abaConfig.getRange("A2:B5").setValues([
      ["Nome Clinica", "Clínica ELEVARE"],
      ["Telefone", "(11) 9999-9999"],
      ["Mensagem Ausencia", "Olá! Estou em consulta no momento, respondo em breve! 💜"],
      ["Horario Funcionamento", "Seg-Sex: 9h-18h"],
      ["Delay Typing (ms)", "1000"]
    ]);
    abaConfig.setFrozenRows(1);
  }
}

/**
 * Cria dados de exemplo para teste
 */
function criarDadosExemplo() {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var abaLeads = planilha.getSheetByName("Leads");
  
  // Dados de exemplo
  var dadosExemplo = [
    [new Date(), "Maria Silva", "(11) 9999-1111", "Limpeza de Pele", "Respondido", 75, "Quente", "Aguardando confirmação", new Date()],
    [new Date(Date.now() - 86400000), "Ana Santos", "(11) 9999-2222", "Criolipólise", "Novo", 25, "Morno", "Enviar follow-up", new Date(Date.now() - 86400000)],
    [new Date(Date.now() - 172800000), "Julia Oliveira", "(11) 9999-3333", "Botox", "Respondido", 85, "Quente", "Agendar consulta", new Date(Date.now() - 172800000)],
    [new Date(Date.now() - 259200000), "Carla Souza", "(11) 9999-4444", "Limpeza de Pele", "Novo", 10, "Frio", "Enviar mensagem inicial", new Date(Date.now() - 259200000)]
  ];
  
  // Adicionar dados começando da linha 2
  for (var i = 0; i < dadosExemplo.length; i++) {
    abaLeads.appendRow(dadosExemplo[i]);
  }
}

/**
 * Cria templates iniciais
 */
function criarTemplatesIniciais() {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var abaTemplates = planilha.getSheetByName("Templates");
  
  var templates = [
    ["tpl_boasvindas", "Boas-vindas", "Inicial", "Olá {nome}! Bem-vinda! 💜 Vi seu interesse em {servico}. Quando seria melhor pra você?", "SIM"],
    ["tpl_confirmacao", "Confirmação", "Agendamento", "Oi {nome}! Confirmando seu horário {data} às {hora}. Tudo certo? 😊", "SIM"],
    ["tpl_lembrete", "Lembrete", "Lembrete", "Lembrete: sua consulta é amanhã às {hora}. Te esperamos! ✨", "SIM"],
    ["tpl_followup", "Follow-up", "Pós-consulta", "Oi {nome}! Como está se sentindo após o procedimento? 💕 Estou aqui se precisar!", "SIM"],
    ["tpl_indicacao", "Pedido Indicação", "Pós-serviço", "Oi {nome}! Você está adorando os resultados, né? 😍 Se alguma amiga quiser também, tem desconto pra indicadas!", "SIM"]
  ];
  
  for (var i = 0; i < templates.length; i++) {
    abaTemplates.appendRow(templates[i]);
  }
}

// ============================================================================
// FUNÇÕES PRINCIPAIS DO SISTEMA
// ============================================================================

/**
 * Captura um novo lead no sistema
 * @param {string} nome - Nome do lead
 * @param {string} telefone - Telefone/WhatsApp
 * @param {string} servico - Serviço de interesse
 * @return {object} Resultado da operação
 */
function capturarLead(nome, telefone, servico) {
  try {
    // Validar dados
    if (!nome || !telefone || !servico) {
      return { sucesso: false, erro: "Dados incompletos" };
    }
    
    var planilha = SpreadsheetApp.getActiveSpreadsheet();
    var abaLeads = planilha.getSheetByName("Leads");
    
    // Formatar telefone
    var telefoneFormatado = formatarTelefone(telefone);
    
    // Verificar se lead já existe
    var dados = abaLeads.getDataRange().getValues();
    for (var i = 1; i < dados.length; i++) {
      if (dados[i][2] === telefoneFormatado) {
        return { sucesso: false, erro: "Lead já cadastrado", leadExistente: true };
      }
    }
    
    // Adicionar novo lead
    var novaLinha = [
      new Date(),           // Data cadastro
      nome,                 // Nome
      telefoneFormatado,    // Telefone formatado
      servico,             // Serviço
      "Novo",              // Status
      0,                   // Score inicial
      "Frio",              // Temperatura inicial
      "Enviar saudação",   // Próxima ação
      new Date()           // Última interação
    ];
    
    abaLeads.appendRow(novaLinha);
    
    // Log de sucesso
    Logger.log("✅ Lead capturado: " + nome + " - " + servico);
    
    return { 
      sucesso: true, 
      mensagem: "Lead capturado com sucesso!",
      leadId: telefoneFormatado 
    };
    
  } catch (error) {
    Logger.log("❌ Erro ao capturar lead: " + error);
    return { sucesso: false, erro: error.toString() };
  }
}

/**
 * Gera saudação personalizada baseada no horário
 * @param {string} nome - Nome do destinatário
 * @param {string} servico - Serviço de interesse
 * @return {string} Mensagem personalizada
 */
function saudacaoPersonalizada(nome, servico) {
  var hora = new Date().getHours();
  var saudacao = hora < 12 ? "Bom dia" : hora < 18 ? "Boa tarde" : "Boa noite";
  
  var mensagem = saudacao + " " + nome + "! 💜\n\n" +
                "Bem-vinda à nossa clínica! Vi seu interesse em " + servico + ". " +
                "Quando seria melhor pra você? Tenho horários disponíveis! 😊";
  
  // Adicionar delay de typing
  var tempoTyping = simularDigitacao(mensagem);
  Logger.log("⏱️ Tempo de typing: " + tempoTyping + "ms");
  
  return mensagem;
}

/**
 * Simula tempo de digitação para humanização
 * @param {string} mensagem - Mensagem a ser enviada
 * @return {number} Tempo em milissegundos
 */
function simularDigitacao(mensagem) {
  var tempoBase = 1000; // 1 segundo base
  var tempoPorCaractere = 50; // 50ms por caractere
  var variacao = Math.random() * 500; // Variação natural
  
  return tempoBase + (mensagem.length * tempoPorCaractere) + variacao;
}

/**
 * Classifica lead baseado em resposta e comportamento
 * @param {string} resposta - Resposta do lead
 * @param {number} tempoResposta - Tempo para responder (minutos)
 * @param {string} origem - Origem do lead
 * @return {object} Classificação e score
 */
function classificarLead(resposta, tempoResposta, origem) {
  var score = 0;
  var analise = {};
  
  // Pontuação por origem
  if (origem === "indicacao") score += 25;
  if (origem === "google") score += 20;
  if (origem === "instagram") score += 15;
  
  // Pontuação por palavras-chave
  var respostaLower = resposta ? resposta.toLowerCase() : "";
  if (respostaLower.includes("quero")) score += 30;
  if (respostaLower.includes("quanto")) score += 25;
  if (respostaLower.includes("agenda")) score += 35;
  if (respostaLower.includes("quando")) score += 20;
  
  // Pontuação por tempo de resposta
  if (tempoResposta < 5) score += 25; // Respondeu rápido
  else if (tempoResposta < 30) score += 15;
  else if (tempoResposta < 120) score += 10;
  
  // Classificar temperatura
  if (score >= 60) {
    analise.temperatura = "Quente";
    analise.prioridade = "Alta";
    analise.proximaAcao = "Agendar consulta";
  } else if (score >= 30) {
    analise.temperatura = "Morno";
    analise.prioridade = "Media";
    analise.proximaAcao = "Enviar informações";
  } else {
    analise.temperatura = "Frio";
    analise.prioridade = "Baixa";
    analise.proximaAcao = "Nutrir com conteúdo";
  }
  
  analise.score = score;
  
  Logger.log("📊 Classificação: " + analise.temperatura + " (Score: " + score + ")");
  
  return analise;
}

/**
 * Busca template por ID ou categoria
 * @param {string} templateId - ID do template
 * @param {string} categoria - Categoria do template
 * @return {object} Template encontrado
 */
function buscarTemplate(templateId, categoria) {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var abaTemplates = planilha.getSheetByName("Templates");
  var dados = abaTemplates.getDataRange().getValues();
  
  for (var i = 1; i < dados.length; i++) {
    var template = {
      id: dados[i][0],
      nome: dados[i][1],
      categoria: dados[i][2],
      conteudo: dados[i][3],
      ativo: dados[i][4] === "SIM"
    };
    
    if (templateId && template.id === templateId) return template;
    if (categoria && template.categoria === categoria && template.ativo) return template;
  }
  
  return null;
}

/**
 * Personaliza template com dados do cliente
 * @param {string} template - Template base
 * @param {object} dados - Dados para substituição
 * @return {string} Template personalizado
 */
function personalizarTemplate(template, dados) {
  var mensagem = template;
  
  // Substituir variáveis
  if (dados.nome) mensagem = mensagem.replace(/{nome}/g, dados.nome);
  if (dados.servico) mensagem = mensagem.replace(/{servico}/g, dados.servico);
  if (dados.data) mensagem = mensagem.replace(/{data}/g, dados.data);
  if (dados.hora) mensagem = mensagem.replace(/{hora}/g, dados.hora);
  if (dados.saudacao) mensagem = mensagem.replace(/{saudacao}/g, dados.saudacao);
  
  return mensagem;
}

/**
 * Sistema de indicações simples
 */
var sistemaIndicacao = {
  
  /**
   * Gera código único de indicação
   */
  gerarCodigo: function(clienteId) {
    var timestamp = new Date().getTime();
    var random = Math.random().toString(36).substr(2, 4).toUpperCase();
    var codigo = "ELE" + random + timestamp.toString().substr(-3);
    
    return {
      codigo: codigo,
      link: "https://seusite.com?ref=" + codigo,
      clienteId: clienteId,
      criadoEm: new Date()
    };
  },
  
  /**
   * Calcula recompensa baseada em número de indicações
   */
  calcularRecompensa: function(totalIndicacoes) {
    if (totalIndicacoes >= 5) {
      return { 
        desconto: 20, 
        descricao: "20% desconto + procedimento bônus",
        nivel: "Diamante" 
      };
    } else if (totalIndicacoes >= 3) {
      return { 
        desconto: 15, 
        descricao: "15% desconto",
        nivel: "Ouro" 
      };
    } else if (totalIndicacoes >= 1) {
      return { 
        desconto: 10, 
        descricao: "10% desconto",
        nivel: "Prata" 
      };
    }
    return null;
  },
  
  /**
   * Registra indicação no sistema
   */
  registrarIndicacao: function(codigoIndicacao, novoLeadId) {
    var planilha = SpreadsheetApp.getActiveSpreadsheet();
    var abaIndicacoes = planilha.getSheetByName("Indicacoes") || 
                       planilha.insertSheet("Indicacoes");
    
    // Criar cabeçalho se não existir
    if (abaIndicacoes.getLastRow() === 0) {
      abaIndicacoes.getRange("A1:F1").setValues([[
        "Data", "Codigo Indicacao", "Indicador ID", "Lead Indicado", 
        "Status", "Recompensa"
      ]]);
    }
    
    abaIndicacoes.appendRow([
      new Date(),
      codigoIndicacao,
      "Cliente_001", // ID do indicador
      novoLeadId,
      "Pendente",
      ""
    ]);
    
    return true;
  }
};

/**
 * Funções de analytics simples
 */
var analytics = {
  
  /**
   * Registra evento para analytics
   */
  registrarEvento: function(evento, leadId, valor, metadata) {
    var planilha = SpreadsheetApp.getActiveSpreadsheet();
    var abaEvents = planilha.getSheetByName("Events") || 
                    planilha.insertSheet("Events");
    
    // Criar cabeçalho se não existir
    if (abaEvents.getLastRow() === 0) {
      abaEvents.getRange("A1:F1").setValues([[
        "Data", "Evento", "Lead ID", "Valor", "Metadata", "Timestamp"
      ]]);
    }
    
    abaEvents.appendRow([
      new Date(),
      evento,
      leadId,
      valor || 0,
      JSON.stringify(metadata || {}),
      new Date().toISOString()
    ]);
  },
  
  /**
   * Gera relatório simples
   */
  gerarRelatorio: function(dias = 7) {
    var planilha = SpreadsheetApp.getActiveSpreadsheet();
    var abaLeads = planilha.getSheetByName("Leads");
    var dados = abaLeads.getDataRange().getValues();
    
    var dataLimite = new Date();
    dataLimite.setDate(dataLimite.getDate() - dias);
    
    var leadsPeriodo = dados.filter(function(linha, index) {
      if (index === 0) return false; // Pular cabeçalho
      var dataLead = new Date(linha[0]);
      return dataLead >= dataLimite;
    });
    
    var relatorio = {
      periodo: dias + " dias",
      totalLeads: leadsPeriodo.length,
      leadsQuentes: leadsPeriodo.filter(l => l[6] === "Quente").length,
      leadsMornos: leadsPeriodo.filter(l => l[6] === "Morno").length,
      leadsFrios: leadsPeriodo.filter(l => l[6] === "Frio").length,
      conversoes: leadsPeriodo.filter(l => l[4] === "Convertido").length
    };
    
    relatorio.taxaConversao = relatorio.totalLeads > 0 ? 
      (relatorio.conversoes / relatorio.totalLeads * 100).toFixed(1) + "%" : "0%";
    
    return relatorio;
  }
};

/**
 * LGPD Compliance - Registro de consentimento
 */
var lgpd = {
  
  /**
   * Registra consentimento do lead
   */
  registrarConsentimento: function(leadId, canais, ip) {
    var planilha = SpreadsheetApp.getActiveSpreadsheet();
    var abaConsent = planilha.getSheetByName("Consentimentos") || 
                     planilha.insertSheet("Consentimentos");
    
    // Criar cabeçalho se não existir
    if (abaConsent.getLastRow() === 0) {
      abaConsent.getRange("A1:F1").setValues([[
        "Data", "Lead ID", "Canais", "IP", "Consentimento", "Revogado"
      ]]);
    }
    
    abaConsent.appendRow([
      new Date(),
      leadId,
      canais.join(","),
      ip || "N/A",
      true,
      false
    ]);
    
    return true;
  },
  
  /**
   * Remove dados do lead (direito ao esquecimento)
   */
  removerDadosLead: function(leadId) {
    var planilha = SpreadsheetApp.getActiveSpreadsheet();
    var abaLeads = planilha.getSheetByName("Leads");
    var dados = abaLeads.getDataRange().getValues();
    
    for (var i = 1; i < dados.length; i++) {
      if (dados[i][2] === leadId) { // Telefone como ID
        // Anonimizar dados
        abaLeads.getRange(i + 1, 1, 1, 9).setValues([[
          dados[i][0], // Data mantida para analytics
          "[REMOVIDO]", // Nome anonimizado
          "[REMOVIDO]", // Telefone removido
          dados[i][3], // Serviço mantido para analytics
          "Removido LGPD",
          0,
          "Removido",
          "Removido LGPD",
          dados[i][8]
        ]]);
        break;
      }
    }
    
    return true;
  }
};

// ============================================================================
// FUNÇÕES DE TESTE E DEBUG
// ============================================================================

/**
 * Testa o sistema completo
 */
function testarSistema() {
  Logger.log("🧪 Iniciando testes do sistema ELEVARE...");
  
  try {
    // Teste 1: Capturar lead
    Logger.log("\n📋 Teste 1: Capturar Lead");
    var resultado = capturarLead("Teste Silva", "(11) 9999-9999", "Limpeza de Pele");
    Logger.log("Resultado: " + JSON.stringify(resultado));
    
    // Teste 2: Saudação personalizada
    Logger.log("\n💬 Teste 2: Saudação Personalizada");
    var saudacao = saudacaoPersonalizada("Teste Silva", "Limpeza de Pele");
    Logger.log("Mensagem: " + saudacao);
    
    // Teste 3: Classificação de lead
    Logger.log("\n📊 Teste 3: Classificação de Lead");
    var classificacao = classificarLead("Quero marcar! Quanto custa?", 5, "google");
    Logger.log("Classificação: " + JSON.stringify(classificacao));
    
    // Teste 4: Buscar template
    Logger.log("\n📝 Teste 4: Buscar Template");
    var template = buscarTemplate(null, "Inicial");
    Logger.log("Template: " + JSON.stringify(template));
    
    // Teste 5: Sistema de indicação
    Logger.log("\n🎁 Teste 5: Sistema de Indicação");
    var indicacao = sistemaIndicacao.gerarCodigo("cliente_001");
    Logger.log("Indicação: " + JSON.stringify(indicacao));
    
    // Teste 6: Analytics
    Logger.log("\n📈 Teste 6: Analytics");
    var relatorio = analytics.gerarRelatorio(7);
    Logger.log("Relatório: " + JSON.stringify(relatorio));
    
    Logger.log("\n✅ Todos os testes concluídos com sucesso!");
    
  } catch (error) {
    Logger.log("❌ Erro nos testes: " + error);
  }
}

/**
 * Formata telefone para padrão consistente
 * @param {string} telefone - Telefone a formatar
 * @return {string} Telefone formatado
 */
function formatarTelefone(telefone) {
  if (!telefone) return "";
  
  // Remover tudo que não é número
  var numeros = telefone.toString().replace(/\D/g, '');
  
  // Adicionar DDD se não tiver
  if (numeros.length === 8) {
    numeros = "11" + numeros; // Assumir DDD 11
  }
  
  // Formatar
  if (numeros.length === 11) {
    return "(" + numeros.substr(0, 2) + ") " + 
           numeros.substr(2, 5) + "-" + 
           numeros.substr(7, 4);
  }
  
  return numeros;
}

/**
 * Função auxiliar para obter configurações
 * @param {string} chave - Chave da configuração
 * @return {string} Valor da configuração
 */
function getConfig(chave) {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var abaConfig = planilha.getSheetByName("Config");
  var dados = abaConfig.getDataRange().getValues();
  
  for (var i = 1; i < dados.length; i++) {
    if (dados[i][0] === chave) {
      return dados[i][1];
    }
  }
  
  return null;
}

/**
 * Função para testar conexão com WhatsApp
 */
function testarWhatsApp() {
  // Esta função simula o envio de mensagem
  // Na versão completa, integraremos com WhatsApp
  Logger.log("📱 Testando integração WhatsApp...");
  Logger.log("✅ Simulação de envio bem sucedida!");
  Logger.log("💡 Na versão completa, esta função enviará mensagens reais!");
}

// ============================================================================
// TRIGGERS E AUTOMATIZAÇÕES
// ============================================================================

/**
 * Função que roda periodicamente para verificar follow-ups
 */
function verificarFollowUps() {
  Logger.log("🔍 Verificando follow-ups pendentes...");
  
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var abaLeads = planilha.getSheetByName("Leads");
  var dados = abaLeads.getDataRange().getValues();
  
  var agora = new Date();
  
  for (var i = 1; i < dados.length; i++) {
    var status = dados[i][4];
    var ultimaInteracao = new Date(dados[i][8]);
    var temperatura = dados[i][6];
    
    // Verificar se precisa de follow-up
    var horasDesdeUltimaResposta = (agora - ultimaInteracao) / (1000 * 60 * 60);
    
    if (status === "Novo" && horasDesdeUltimaResposta > 2) {
      Logger.log("📞 Lead " + dados[i][1] + " precisa de follow-up!");
      // Aqui enviaremos mensagem de follow-up
    }
  }
  
  Logger.log("✅ Verificação de follow-ups concluída");
}

/**
 * Função para enviar lembretes de consultas
 */
function enviarLembretesConsultas() {
  Logger.log("📅 Verificando consultas para lembrete...");
  
  // Esta função será implementada na fase 2
  // Por agora, apenas logamos que identificamos necessidade
  
  Logger.log("✅ Verificação de lembretes concluída");
}

// ============================================================================
// MENU CUSTOMIZADO (OPCIONAL)
// ============================================================================

/**
 * Cria menu personalizado no Google Sheets
 */
function onOpen() {
  var ui = SpreadsheetApp.getUi();
  ui.createMenu('🚀 ELEVARE')
    .addItem('📋 Capturar Lead', 'mostrarFormLead')
    .addItem('📊 Gerar Relatório', 'mostrarRelatorio')
    .addItem('🧪 Testar Sistema', 'testarSistema')
    .addSeparator()
    .addItem('❓ Ajuda', 'mostrarAjuda')
    .addToUi();
}

/**
 * Mostra formulário para capturar lead
 */
function mostrarFormLead() {
  var html = HtmlService.createHtmlOutputFromFile('FormLead')
    .setWidth(400)
    .setHeight(300);
  SpreadsheetApp.getUi().showModalDialog(html, 'Capturar Novo Lead');
}

/**
 * Mostra relatório simples
 */
function mostrarRelatorio() {
  var relatorio = analytics.gerarRelatorio(7);
  var mensagem = "📊 Relatório dos últimos 7 dias:\n\n" +
                "Total de leads: " + relatorio.totalLeads + "\n" +
                "Leads quentes: " + relatorio.leadsQuentes + "\n" +
                "Taxa de conversão: " + relatorio.taxaConversao;
  
  SpreadsheetApp.getUi().alert(mensagem);
}

/**
 * Mostra ajuda
 */
function mostrarAjuda() {
  var ajuda = "🆘 AJUDA ELEVARE:\n\n" +
              "1. Use 'Capturar Lead' para adicionar novos leads\n" +
              "2. Os leads são classificados automaticamente\n" +
              "3. Use 'Testar Sistema' para verificar funcionamento\n" +
              "4. Templates estão na aba 'Templates'\n" +
              "5. Analytics na aba 'Analytics'\n\n" +
              "💡 Dúvidas? Me chame para ajuda!";
  
  SpreadsheetApp.getUi().alert(ajuda);
}

// ============================================================================
// FINAL DO CÓDIGO
// ============================================================================

Logger.log("🎉 Código ELEVARE Simplificado carregado com sucesso!");
Logger.log("📋 Próximos passos:");
Logger.log("   1. Execute 'setupInicial()' uma vez");
Logger.log("   2. Execute 'testarSistema()' para verificar");
Logger.log("   3. Comece a usar seu sistema ELEVARE!");