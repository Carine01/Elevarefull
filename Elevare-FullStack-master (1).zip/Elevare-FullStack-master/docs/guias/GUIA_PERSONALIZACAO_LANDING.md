# Guia de Personalização da Landing Page Elevare IARA

## Visão Geral
Este guia detalha como personalizar a landing page do IARA com suas próprias imagens, mantendo a identidade visual da Elevare e maximizando o impacto visual para clínicas de estética.

## Identidade Visual Elevare

### Paleta de Cores - Lavanda Fria
- **Primária**: `#E6E0F8` (lavanda claro)
- **Secundária**: `#B794F6` (lavanda médio)
- **Acento**: `#9F7AEA` (lavanda escuro)
- **Neutro**: `#F7FAFC` (cinza gelo)
- **Texto**: `#2D3748` (cinza escuro)

### Tipografia
- **Títulos**: Montserrat (sans-serif)
- **Corpo**: Inter (sans-serif)

## Imagens Recomendadas

### 1. Hero Section (1200x800px)
**O que buscar:**
- Imagem de uma clínica de estética moderna e elegante
- Ambiente clean com tons de lavanda ou cores neutras
- Profissionais em ação (procedimentos faciais, consultas)
- Iluminação suave e profissional

**Evitar:**
- Imagens genéricas de stock
- Cores vibrantes ou saturadas
- Ambientes bagunçados ou mal iluminados

**Sugestões de busca:**
- "aesthetic clinic interior modern"
- "beauty spa professional environment"
- "skincare treatment room elegant"

### 2. Seção de Serviços (800x600px cada)
**Três imagens necessárias:**
1. **Consulta Personalizada**: Médico esteticista conversando com paciente
2. **Tratamentos**: Procedimento de skincare ou estética em andamento
3. **Tecnologia**: Equipamentos modernos de estética

**Características ideais:**
- Profissionalismo e confiança
- Tecnologia de ponta
- Ambiente acolhedor

### 3. Depoimentos (400x400px)
**Para cada depoimento (mínimo 3):**
- Fotos profissionais dos clientes
- Fundo neutro ou clínica
- Expressão feliz e confiante
- Boa iluminação natural

### 4. Equipe (600x800px)
**Requisitos:**
- Fotos profissionais dos profissionais
- Fundo branco ou neutro
- Uniforme clínico ou roupa profissional
- Expressão acolhedora e confiante

## Otimização de Imagens

### Formatos Recomendados
- **WebP**: Para melhor performance
- **JPEG**: Compatibilidade universal
- **PNG**: Para imagens com transparência

### Tamanhos e Compressão
- Hero: Máximo 500KB
- Serviços: Máximo 300KB cada
- Depoimentos: Máximo 200KB cada
- Use ferramentas como TinyPNG ou Squoosh

### Dimensões Exatas
```
Hero: 1200x800px (landscape)
Serviços: 800x600px (landscape)
Depoimentos: 400x400px (square)
Equipe: 600x800px (portrait)
```

## Personalização do Conteúdo

### Textos Principais
1. **Headline Hero**: "Transforme sua clínica com a Inteligência Artificial que humaniza o atendimento"
2. **Subheadline**: "IARA - A assistente virtual que captura, qualifica e converte leads 24/7"
3. **CTA Principal**: "Começar Agora Grátis"

### Seção de Benefícios
**Títulos sugeridos:**
- "Captura Inteligente de Leads"
- "Qualificação Automática"
- "Aumento de 40% nas Conversões"
- "Atendimento 24/7 Humanizado"

### Depoimentos
**Estrutura ideal:**
- Nome e especialidade do profissional
- Nome da clínica
- Resultado específico alcançado
- Foto profissional

**Exemplo:**
> "Com a IARA, aumentamos nossas conversões em 45% nos primeiros 3 meses. A qualificação automática nos economiza 20 horas por semana."  
> *Dr. Carlos Silva - Clínica Silva Estética*

## Implementação Técnica

### Substituição de Imagens
1. Abra o arquivo `LANDING_PAGE_ELEVARE.html`
2. Localize as tags `<img>` correspondentes
3. Substitua os atributos `src` com suas URLs
4. Ajuste os atributos `alt` para SEO

### Exemplo de Substituição:
```html
<!-- Original -->
<img src="hero-clinic.jpg" alt="Clínica de Estética Moderna">

<!-- Personalizado -->
<img src="sua-clinica-hero.jpg" alt="[Nome da Sua Clínica] - Clínica de Estética Especializada">
```

### Cores Personalizadas
Se necessário ajustar a paleta para combinar com suas imagens:
```css
:root {
  --lavanda-claro: #E6E0F8;    /* Ajuste se necessário */
  --lavanda-medio: #B794F6;    /* Mantenho ou ajuste */
  --lavanda-escuro: #9F7AEA;   /* Cor de acento */
}
```

## Checklist de Qualidade

### Antes de Publicar
- [ ] Todas as imagens carregam corretamente
- [ ] Textos alternativos estão otimizados
- [ ] Cores mantêm consistência visual
- [ ] Layout responsivo funciona em todos os dispositivos
- [ ] Links e CTAs estão funcionando
- [ ] Página carrega em menos de 3 segundos

### Testes de Conversão
- [ ] Formulário de captura funciona
- [ ] WhatsApp link está correto
- [ ] Anúncios e rastreamento configurados
- [ ] Teste A/B de headlines preparado

## Recursos Adicionais

### Ferramentas Úteis
- **TinyPNG**: Compressão de imagens
- **Canva**: Criação de gráficos
- **Unsplash**: Imagens profissionais gratuitas
- **Pexels**: Banco de imagens diversificado

### Suporte Técnico
Para dúvidas sobre implementação:
1. Verifique a documentação do código
2. Teste em ambiente de desenvolvimento
3. Use ferramentas de debug do navegador
4. Monitore performance com Lighthouse

## Próximos Passos

1. **Coleta de Imagens**: Busque ou crie as imagens conforme especificações
2. **Personalização**: Substitua conteúdo e ajuste cores se necessário
3. **Testes**: Valide funcionamento e performance
4. **Lançamento**: Publique e monitore conversões
5. **Otimização**: Faça ajustes baseados em dados reais

---

**Lembre-se**: A consistência visual e a qualidade das imagens são cruciais para a credibilidade da sua clínica. Invista tempo na seleção e otimização das imagens para maximizar os resultados.