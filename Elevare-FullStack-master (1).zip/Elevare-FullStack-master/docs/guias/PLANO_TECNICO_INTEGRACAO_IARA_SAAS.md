# Plano Técnico de Integração IARA x SaaS Elevare

## Visão Executiva

Este documento apresenta a estratégia técnica completa para integrar o sistema IARA existente à plataforma SaaS Elevare, transformando-o em um módulo multi-tenant escalável com autenticação unificada, sistema de pagamentos integrado e arquitetura de microserviços.

## 1. Análise do Estado Atual

### Arquitetura Atual IARA
- **Frontend**: HTML5/CSS3/JavaScript vanilla com Tailwind CSS
- **Backend**: Google Apps Script (monolítico)
- **Banco de Dados**: Google Sheets
- **Integrações**: WhatsApp Business API, Meta CAPI, Google Enhanced Conversions
- **Sistema de Templates**: Biblioteca Mestra com variáveis dinâmicas

### Pontos Críticos para Integração
1. **Ausência de autenticação/SaaS**: Sistema atual não tem conceito de multi-tenant
2. **Banco de dados limitado**: Google Sheets não é adequado para SaaS
3. **Arquitetura monolítica**: Dificulta escalabilidade e manutenção
4. **Sistema de pagamentos**: Inexistente no IARA atual

## 2. Proposta de Arquitetura SaaS

### 2.1 Arquitetura Geral
```
┌─────────────────────────────────────────────────────────────┐
│                    SaaS Elevare Core                        │
├─────────────────────────────────────────────────────────────┤
│  • Autenticação Unificada (JWT/OAuth2)                      │
│  • Gestão de Clientes (Multi-tenant)                       │
│  • Sistema de Assinaturas/Pagamentos                      │
│  • Portal do Cliente                                        │
├─────────────────────────────────────────────────────────────┤
│                      Módulo IARA                           │
├─────────────────────────────────────────────────────────────┤
│  • API REST (Node.js/Python)                               │
│  • Banco de Dados Multi-tenant (PostgreSQL)               │
│  • Microserviços:                                          │
│    - Templates Service                                     │
│    - WhatsApp Service                                      │
│    - Analytics Service                                     │
│    - Lead Management Service                              │
└─────────────────────────────────────────────────────────────┘
```

### 2.2 Modelo de Multi-Tenancy
**Abordagem**: Database per Tenant com Schema compartilhado
- Cada cliente tem seu próprio banco de dados isolado
- Schema único para todos os tenants
- Vantagens: Segurança máxima, compliance GDPR, fácil backup/restore

### 2.3 Stack Tecnológica Proposta
- **Backend**: Node.js com Express/Fastify ou Python com FastAPI
- **Banco de Dados**: PostgreSQL com particionamento por tenant
- **Cache**: Redis para sessões e dados temporários
- **Filas**: Bull/Redis para processamento assíncrono
- **Autenticação**: JWT com refresh tokens
- **API Gateway**: Kong ou AWS API Gateway
- **Containerização**: Docker + Kubernetes

## 3. Estratégia de Migração

### Fase 1: Preparação e Fundação (2-3 semanas)
1. **Setup do Ambiente SaaS**
   - Configurar infraestrutura multi-tenant
   - Implementar sistema de autenticação
   - Criar sistema de gestão de clientes

2. **Migração do Banco de Dados**
   - Modelar schema PostgreSQL multi-tenant
   - Scripts de migração dos dados Google Sheets
   - Setup de particionamento e índices

### Fase 2: Backend API (3-4 semanas)
1. **Desenvolvimento da API REST**
   - Endpoints para templates (CRUD)
   - Sistema de filas de envio
   - Integração WhatsApp Business API
   - Analytics e relatórios

2. **Middleware de Tenant**
   - Extração de tenant ID dos tokens JWT
   - Conexão dinâmica ao banco correto
   - Validação de permissões por tenant

### Fase 3: Frontend Adaptado (2-3 semanas)
1. **Refatoração do Dashboard**
   - Integração com novo sistema de autenticação
   - Adaptação para multi-tenant
   - Melhorias de UX/UI

2. **Portal do Cliente**
   - Desenvolvimento da interface React
   - Integração com APIs do módulo IARA

### Fase 4: Integração e Testes (2 semanas)
1. **Integração com Elevare Core**
   - Webhooks para eventos de pagamento
   - Sincronização de dados entre sistemas
   - Testes de integração

2. **Testes e Otimização**
   - Testes de carga multi-tenant
   - Otimização de queries
   - Segurança e compliance

### Fase 5: Deploy e Lançamento (1 semana)
1. **Infraestrutura**
   - Setup Kubernetes
   - CI/CD pipelines
   - Monitoramento e logging

2. **Migração de Dados**
   - Migração gradual dos clientes existentes
   - Validação de dados migrados
   - Rollback procedures

## 4. Estrutura de Microserviços

### 4.1 Template Service
```javascript
// API de Templates
GET   /api/v1/templates          // Listar templates do tenant
POST  /api/v1/templates          // Criar novo template
PUT   /api/v1/templates/:id      // Atualizar template
DELETE /api/v1/templates/:id     // Remover template
POST  /api/v1/templates/:id/optimize // Otimizar com IA
```

### 4.2 WhatsApp Service
```javascript
// API de WhatsApp
POST  /api/v1/whatsapp/send      // Enviar mensagem
GET   /api/v1/whatsapp/status    // Status do serviço
POST  /api/v1/whatsapp/webhook   // Webhook de recebimento
```

### 4.3 Analytics Service
```javascript
// API de Analytics
GET   /api/v1/analytics/leads    // Métricas de leads
GET   /api/v1/analytics/campaigns // Performance de campanhas
GET   /api/v1/analytics/funnel   // Funil de conversão
```

## 5. Sistema de Autenticação

### 5.1 Fluxo de Autenticação
1. Usário faz login no SaaS Elevare
2. Recebe JWT token com claims do tenant
3. Token é validado em cada requisição ao módulo IARA
4. Middleware extrai tenant ID e conecta ao banco correto

### 5.2 Estrutura do JWT
```json
{
  "sub": "user_id",
  "tenant": "tenant_id",
  "plan": "premium",
  "permissions": ["templates:read", "whatsapp:send"],
  "exp": 1234567890
}
```

## 6. Integração de Pagamentos

### 6.1 Eventos de Assinatura
- **Upgrade**: Ativa recursos premium do IARA
- **Downgrade**: Limita recursos conforme novo plano
- **Cancelamento**: Desativa serviços gradualmente
- **Falha de Pagamento**: Suspensão temporária

### 6.2 Webhooks Necessários
```javascript
// Webhook de assinatura
POST /webhooks/subscription
{
  event: 'subscription.updated',
  tenant_id: 'tenant_123',
  plan: 'premium',
  status: 'active'
}
```

## 7. Infraestrutura e Deploy

### 7.1 Dockerização
```dockerfile
# Dockerfile para API IARA
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

### 7.2 Kubernetes Manifests
```yaml
# Deployment do serviço IARA
apiVersion: apps/v1
kind: Deployment
metadata:
  name: iara-service
spec:
  replicas: 3
  selector:
    matchLabels:
      app: iara-service
  template:
    metadata:
      labels:
        app: iara-service
    spec:
      containers:
      - name: iara-api
        image: elevare/iara-service:latest
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: iara-secrets
              key: database-url
```

## 8. Monitoramento e Observabilidade

### 8.1 Métricas Principais
- Tempo de resposta da API
- Taxa de erro por endpoint
- Quantidade de tenants ativos
- Uso de recursos por tenant
- Performance do banco de dados

### 8.2 Alertas Configurados
- Latência > 500ms
- Taxa de erro > 5%
- Uso de CPU > 80%
- Espaço em disco < 10%

## 9. Segurança e Compliance

### 9.1 Medidas de Segurança
- Criptografia de dados em repouso (AES-256)
- TLS 1.3 para dados em trânsito
- Rate limiting por tenant
- Validação de entrada rigorosa
- Logs de auditoria detalhados

### 9.2 Compliance GDPR/LGPD
- Consentimento explícito para dados
- Direito ao esquecimento implementado
- Portabilidade de dados
- Notificação de violações
- Dados residentes no Brasil/UE

## 10. Estimativa de Esforço

### Recursos Necessários
- **Backend Developer**: 2 desenvolvedores (3 meses)
- **Frontend Developer**: 1 desenvolvedor (2 meses)
- **DevOps Engineer**: 1 engenheiro (1 mês)
- **DBA**: 1 especialista (2 semanas)

### Timeline Total
- **MVP Funcional**: 8-10 semanas
- **Produção Completa**: 12-14 semanas
- **Otimizações**: Semanas adicionais

## 11. Próximos Passos

### Ações Imediatas
1. **Validar arquitetura** com stakeholders
2. **Setup do ambiente** de desenvolvimento
3. **Iniciar modelagem** do banco de dados
4. **Definir contratos** de API

### Documentação Necessária
- Especificação técnica detalhada
- Contratos de API (OpenAPI/Swagger)
- Guias de deployment
- Manual do desenvolvedor

---

**Contato**: Carine Marques - Idealizadora Plataforma Elevare  
**Data**: Novembro 2025  
**Versão**: 1.0