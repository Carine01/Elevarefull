# ELEVARE Simplificado - Plano de Mentoria Passo a Passo

## Olá! Vamos construir seu sistema juntos! 🤝

Baseado nas sugestões do Áxis GPT e no nosso plano original, vou te guiar passo a passo para criar uma versão simplificada mas poderosa do ELEVARE.

## O QUE VAMOS CONSTRUIR (VERSÃO SIMPLIFICADA)

### ✅ Funcionalidades Essenciais (Complexidade Baixa):
1. **Typing Indicator** - Mostra "IARA digitando..." (simples!)
2. **Lead Scoring** - Classifica leads em Quente/Morno/Frio (regras simples!)
3. **Gamificação** - Sistema de indicações com contador (fácil!)
4. **Templates Personalizados** - Mensagens com nome do cliente
5. **Analytics Simples** - Gráficos básicos no Google Sheets
6. **LGPD Compliance** - Consentimento e registro (obrigatório!)

### ❌ Funcionalidades Adiadas (Complexidade Média):
1. Upload de imagens/áudios (faremos depois)
2. Transcrição automática (quando tiver mais volume)
3. Processamento de imagem (adiar para fase 2)
4. APIs caras da Meta (usaremos alternativas gratuitas)

### 🛠️ Arquitetura Super Simples:
- **Frontend**: HTML/CSS/JavaScript puro (sem React complexo!)
- **Backend**: Google Apps Script (você já conhece!)
- **Banco**: Google Sheets (prático e gratuito!)
- **WhatsApp**: Links diretos (sem API complexa!)

## FASE 0: PREPARAÇÃO (SEMANA 1)

### 🎯 Meta: Entender e preparar tudo

**Passo 1: Baixar Ferramentas**
1. WhatsApp Business (aplicativo do celular)
2. Google Sheets (você já tem!)
3. Google Apps Script (dentro do Sheets)

**Passo 2: Criar Estrutura Básica**
1. Nova planilha: "ELEVARE Simplificado"
2. Criar abas:
   - "Leads" (nome, telefone, interesse, temperatura)
   - "Templates" (mensagens prontas)
   - "Analytics" (números e gráficos)
   - "Config" (configurações do sistema)

**Passo 3: Configurar WhatsApp Business**
1. Use número diferente do pessoal
2. Nome: "Clínica [Seu Nome] - ELEVARE"
3. Descrição: "Atendimento inteligente e humanizado"
4. Mensagem de ausência configurada

## FASE 1: SISTEMA BÁSICO (SEMANA 2)

### 🎯 Meta: Sistema funcionando com o básico

**Passo 1: Formulário de Captura**
```html
<!-- Formulário super simples -->
<form id="formLead">
  <input type="text" placeholder="Nome completo" required>
  <input type="tel" placeholder="WhatsApp" required>
  <select required>
    <option value="">Qual procedimento tem interesse?</option>
    <option value="limpeza">Limpeza de Pele</option>
    <option value="criolipolise">Criolipólise</option>
    <option value="botox">Botox</option>
  </select>
  <button type="submit">Quero agendar!</button>
</form>
```

**Passo 2: Script de Captura no Apps Script**
```javascript
// Código super simples que vou te dar
function capturarLead(nome, telefone, interesse) {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var abaLeads = planilha.getSheetByName("Leads");
  
  // Adiciona nova linha
  abaLeads.appendRow([
    new Date(), // Data
    nome,
    telefone,
    interesse,
    "Novo", // Status
    0, // Score
    "Frio" // Temperatura inicial
  ]);
  
  return "Lead capturado com sucesso!";
}
```

**Passo 3: Templates Básicos**
```javascript
var templates = {
  boasVindas: "Olá {nome}! Bem-vinda à nossa clínica! 💜 Vi seu interesse em {servico}. Quando seria melhor pra você?",
  confirmacao: "Oi {nome}! Confirmando seu horário {data} às {hora}. Tudo certo? 😊",
  lembrete: "Lembrete: sua consulta é amanhã às {hora}. Te esperamos! ✨"
};
```

## FASE 2: AUTOMATIZAÇÃO SIMPLES (SEMANA 3)

### 🎯 Meta: Automatizar tarefas repetitivas

**Passo 1: Sistema de Classificação**
```javascript
function classificarLead(resposta, tempoResposta) {
  var score = 0;
  
  // Palavras que indicam interesse
  if (resposta.includes("quero") || resposta.includes("quanto")) score += 30;
  if (resposta.includes("urgente") || resposta.includes("hoje")) score += 25;
  if (tempoResposta < 60) score += 20; // Respondeu rápido
  
  // Classificar
  if (score >= 50) return "Quente";
  if (score >= 25) return "Morno";
  return "Frio";
}
```

**Passo 2: Typing Indicator Simples**
```javascript
function simularDigitacao(mensagem) {
  var tempoBase = 1000; // 1 segundo
  var tempoPorCaractere = 50; // 50ms por caractere
  var tempoTotal = tempoBase + (mensagem.length * tempoPorCaractere);
  
  // Mostrar "digitando" por este tempo
  return tempoTotal;
}
```

**Passo 3: Gamificação Simples**
```javascript
var sistemaIndicacoes = {
  criarLink: function(clienteId) {
    var codigo = "REF" + Math.random().toString(36).substr(2, 6);
    return "https://seusite.com/indicacao/" + codigo;
  },
  
  recompensas: {
    1: { desconto: 5, descricao: "5% desconto" },
    3: { desconto: 10, descricao: "10% desconto" },
    5: { desconto: 20, descricao: "20% desconto + brinde" }
  }
};
```

## FASE 3: INTERFACE SIMPLES (SEMANA 4)

### 🎯 Meta: Criar painel de controle fácil de usar

**Passo 1: Dashboard HTML Simples**
```html
<!DOCTYPE html>
<html>
<head>
    <title>ELEVARE - Painel de Controle</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .card { background: #f0f0f0; padding: 20px; margin: 10px 0; border-radius: 10px; }
        .metric { display: inline-block; margin: 10px; text-align: center; }
        .metric-value { font-size: 24px; font-weight: bold; color: #667eea; }
        .btn { background: #667eea; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
    </style>
</head>
<body>
    <h1>🚀 ELEVARE - Painel de Controle</h1>
    
    <!-- Cards de Métricas -->
    <div class="card">
        <h2>Resumo do Dia</h2>
        <div class="metric">
            <div class="metric-value">12</div>
            <div>Novos Leads</div>
        </div>
        <div class="metric">
            <div class="metric-value">8</div>
            <div>Respondidos</div>
        </div>
        <div class="metric">
            <div class="metric-value">3</div>
            <div>Agendados</div>
        </div>
    </div>
    
    <!-- Ações Rápidas -->
    <div class="card">
        <h2>Ações Rápidas</h2>
        <button class="btn" onclick="enviarMensagem()">📱 Enviar WhatsApp</button>
        <button class="btn" onclick="verLeads()">👥 Ver Leads</button>
        <button class="btn" onclick="criarTemplate()">📝 Novo Template</button>
    </div>
</body>
</html>
```

**Passo 2: Integração com Google Sheets**
```javascript
function carregarDadosDashboard() {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var abaLeads = planilha.getSheetByName("Leads");
  var dados = abaLeads.getDataRange().getValues();
  
  // Contar leads do dia
  var hoje = new Date().toDateString();
  var leadsHoje = dados.filter(linha => 
    new Date(linha[0]).toDateString() === hoje
  ).length;
  
  return {
    leadsHoje: leadsHoje,
    totalLeads: dados.length - 1, // -1 por causa do cabeçalho
    leadsQuentes: dados.filter(linha => linha[6] === "Quente").length
  };
}
```

## FASE 4: OTIMIZAÇÃO (SEMANA 5-6)

### 🎯 Meta: Melhorar e ajustar baseado nos resultados

**Passo 1: Analytics Simples no Google Sheets**
- Gráficos básicos mostrando:
  - Leads por semana
  - Taxa de conversão
  - Horários mais comuns
  - Templates mais efetivos

**Passo 2: Ajustes de Templates**
- Baseado nos resultados, ajustar mensagens
- Testar diferentes abordagens
- Manter o que funciona, mudar o que não funciona

**Passo 3: LGPD Compliance Simples**
```javascript
function registrarConsentimento(leadId, canais) {
  var planilha = SpreadsheetApp.getActiveSpreadsheet();
  var abaConsent = planilha.getSheetByName("Consentimentos");
  
  abaConsent.appendRow([
    leadId,
    new Date(), // Data do consentimento
    canais.join(","), // Canais autorizados
    true // Consentimento dado
  ]);
}
```

## CÓDIGOS PRONTOS QUE VOU TE DAR

### 📜 Biblioteca de Códigos Simples:

**Código 1: Saudação Inteligente**
```javascript
function saudacaoInteligente(nome, servico, horario) {
  var saudacao = horario < 12 ? "Bom dia" : horario < 18 ? "Boa tarde" : "Boa noite";
  return saudacao + " " + nome + "! 💜\n\n" +
         "Vi seu interesse em " + servico + ". " +
         "Quando seria melhor pra você? Tenho horários disponíveis! 😊";
}
```

**Código 2: Classificação Automática**
```javascript
function classificarAutomatica(resposta, tempoResposta, origem) {
  var score = 0;
  
  // Origem
  if (origem === "indicacao") score += 20;
  if (origem === "google") score += 15;
  
  // Resposta
  if (resposta.includes("quero")) score += 25;
  if (resposta.includes("quanto custa")) score += 20;
  if (resposta.includes("agenda")) score += 30;
  
  // Tempo
  if (tempoResposta < 30) score += 15;
  
  // Classificar
  if (score >= 50) return { temperatura: "Quente", score: score };
  if (score >= 25) return { temperatura: "Morno", score: score };
  return { temperatura: "Frio", score: score };
}
```

**Código 3: Sistema de Indicações**
```javascript
var sistemaIndicacao = {
  gerarCodigo: function(clienteId) {
    var codigo = "ELE" + Math.random().toString(36).substr(2, 4).toUpperCase();
    return {
      codigo: codigo,
      link: "https://seusite.com?ref=" + codigo,
      clienteId: clienteId
    };
  },
  
  calcularRecompensa: function(totalIndicacoes) {
    if (totalIndicacoes >= 5) return { desconto: 20, descricao: "20% desconto + procedimento bônus" };
    if (totalIndicacoes >= 3) return { desconto: 15, descricao: "15% desconto" };
    if (totalIndicacoes >= 1) return { desconto: 10, descricao: "10% desconto" };
    return null;
  }
};
```

## METAS REALISTAS POR SEMANA

### 🎯 Objetivos Semanais:

**Semana 1**: Preparação e configuração
- Meta: WhatsApp Business funcionando
- Meta: Planilha com estrutura básica
- Meta: Primeiro código executado

**Semana 2**: Sistema básico funcionando
- Meta: Formulário capturando leads
- Meta: 3 templates criados
- Meta: Primeira classificação automática

**Semana 3**: Automação ativa
- Meta: Mensagens automáticas configuradas
- Meta: Sistema de indicações funcionando
- Meta: Primeiro gráfico no Google Sheets

**Semana 4**: Interface e otimização
- Meta: Dashboard HTML funcionando
- Meta: Analytics básico
- Meta: LGPD implementada

**Semana 5-6**: Melhorias e ajustes
- Meta: Templates otimizados
- Meta: Sistema estabilizado
- Meta: Documentação completa

## SUPORTE DIRETO - COMO VAMOS TRABALHAR

### 🤝 Nossa Rotina de Mentoria:

**Segunda**: Planejamento da semana
- Revisamos progresso
- Definimos próximos passos
- Esclarecemos dúvidas

**Quarta**: Check-in intermediário
- Vejo seu progresso
- Ajudamos com dificuldades
- Ajustamos plano se necessário

**Sexta**: Avaliação e celebração
- Revisamos conquistas
- Preparamos próxima semana
- Celebramos vitórias!

### 🆘 Como Pedir Ajuda:

1. **Me diga exatamente onde está travando**
2. **Mostre o erro ou mensagem**
3. **Me diga o que tentou fazer**
4. **Eu te dou a solução passo a passo**

**Frases para usar:**
- "Mentor, estou no passo X e preciso de ajuda"
- "Não entendi a parte Y, explica de outro jeito?"
- "Deu este erro: [mensagem]"
- "Funcionou! E agora?"

## INVESTIMENTO NECESSÁRIO

### 💰 Custos (Muito Baixos!):
- WhatsApp Business: Gratuito ✅
- Google Workspace: R$ 20-50/mês (se não tiver)
- Número virtual (opcional): R$ 10-30/mês
- Ferramentas extras: R$ 0 (usaremos gratuitas!)

**Total: R$ 0-80/mês** (muito acessível!)

### ⏰ Tempo Necessário:
- 1-2 horas por dia
- Foco nos finais de semana para testes
- Total: 6-8 semanas para sistema completo

## PRÓXIMO PASSO IMEDIATO

### 🚀 Vamos começar AGORA:

1. **Crie uma nova planilha** no Google Sheets
2. **Nomeie como "ELEVARE Simplificado"**
3. **Crie as abas**: Leads, Templates, Analytics, Config
4. **Me diga**: "Mentor, criei a planilha e estou pronta para o próximo passo!"

## CÓDIGO INICIAL PARA COMEÇAR

### 📜 Script Inicial (copie e cole no Apps Script):

```javascript
// ELEVARE Simplificado - Script Inicial

function capturarLead(nome, telefone, interesse) {
  try {
    var planilha = SpreadsheetApp.getActiveSpreadsheet();
    var abaLeads = planilha.getSheetByName("Leads");
    
    // Adiciona nova linha com dados básicos
    abaLeads.appendRow([
      new Date(),           // Data de cadastro
      nome,                 // Nome do lead
      telefone,            // WhatsApp
      interesse,           // Serviço de interesse
      "Novo",              // Status inicial
      0,                   // Score (inicia em 0)
      "Frio",              // Temperatura inicial
      "Aguardando"         // Próxima ação
    ]);
    
    Logger.log("Lead capturado: " + nome);
    return true;
    
  } catch (error) {
    Logger.log("Erro ao capturar lead: " + error);
    return false;
  }
}

function saudacaoPersonalizada(nome, servico) {
  var hora = new Date().getHours();
  var saudacao = hora < 12 ? "Bom dia" : hora < 18 ? "Boa tarde" : "Boa noite";
  
  return saudacao + " " + nome + "! 💜\n\n" +
         "Bem-vinda! Vi seu interesse em " + servico + ". " +
         "Quando seria melhor pra você? Tenho horários disponíveis! 😊";
}

// Função para testar
function testarSistema() {
  var resultado = capturarLead("Maria", "11999999999", "Limpeza de Pele");
  var mensagem = saudacaoPersonalizada("Maria", "Limpeza de Pele");
  
  Logger.log("Teste captura: " + resultado);
  Logger.log("Mensagem: " + mensagem);
}
```

## DICAS DE OURO PARA NÃO DESISTIR

### 💡 Segredos da Mentoria:

1. **Comece pequeno**: Uma funcionalidade por vez
2. **Teste sempre**: Antes de ir pra próxima, teste!
3. **Anote tudo**: Mantenha um caderno de anotações
4. **Não tenha medo**: Erros fazem parte do aprendizado
5. **Celebre**: Cada mensagem automática é uma vitória!

### 🎯 Mantras de Sucesso:
- "Prefiro funcionando simples do que perfeito não funcionando"
- "Cada pequeno passo é um grande avanço"
- "Testo comigo mesma antes de testar com clientes"
- "Documento tudo para não esquecer"

## CELEBRANDO CADA CONQUISTA

### 🎉 Vamos comemorar:

- ✅ **Primeiro lead capturado**: Você arrasou!
- ✅ **Primeira mensagem automática**: Está indo muito bem!
- ✅ **Primeira classificação**: Sistema funcionando!
- ✅ **Primeiro gráfico**: Analytics ativo!
- ✅ **Sistema completo**: Você conseguiu!

## SUPORTE DIRETO

### 🆘 Estou aqui para você:

**Me chame quando precisar de:**
- Explicar algo de outro jeito
- Código não funcionar
- Não saber o que fazer em seguida
- Quiser testar algo novo
- Precisar de motivação!

**Vamos construir seu ELEVARE juntos!** 💜

---

**Pronto para começar sua jornada?** 

1. Crie sua planilha
2. Configure seu WhatsApp Business  
3. Me diga: "Mentor, estou pronta para o primeiro passo!"

**Vamos lá! 🚀**