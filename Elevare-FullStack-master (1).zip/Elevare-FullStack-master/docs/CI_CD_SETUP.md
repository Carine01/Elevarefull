# 🚀 GUIA COMPLETO DE CI/CD - ELEVARE IARA

**Data:** 29/11/2025 01:00 GMT-3  
**Status:** Pronto para instalação  
**Tempo estimado:** 15 minutos

---

## 📋 ÍNDICE

1. [Pipeline CI/CD](#1-pipeline-cicd)
2. [Scan de Vulnerabilidades](#2-scan-de-vulnerabilidades)
3. [Documentação Automática](#3-documentação-automática)
4. [Ambientes Separados](#4-ambientes-separados)
5. [Alertas de Falha](#5-alertas-de-falha)
6. [Instalação Completa](#6-instalação-completa)

---

## 1. PIPELINE CI/CD

### ✅ O que foi implementado

**Arquivo:** `.github/workflows/ci.yml` (salvo localmente)

**9 jobs automatizados:**
1. **Lint**: Valida código (ESLint)
2. **Test Backend**: Testes unitários + PostgreSQL
3. **Test Frontend**: Testes unitários
4. **Build Backend**: Compila TypeScript
5. **Build Frontend**: Compila assets
6. **Deploy Staging**: Deploy automático (branch `develop`)
7. **Deploy Production**: Deploy automático (branch `master`)
8. **Notify Success**: Notificação Slack (sucesso)
9. **Notify Failure**: Notificação Slack (falha)

### 🔧 Como instalar

**Passo 1:** Adicionar workflow ao GitHub

```bash
cd Elevare-FullStack
git add .github/workflows/ci.yml
git commit -m "ci: adiciona pipeline CI/CD completo"
git push origin master
```

**Passo 2:** Configurar secrets no GitHub

Acesse: https://github.com/iaraelevare-source/Elevare-FullStack/settings/secrets/actions

Adicione os seguintes secrets:

| Nome | Descrição | Onde obter |
|------|-----------|------------|
| `VERCEL_TOKEN` | Token de autenticação do Vercel | https://vercel.com/account/tokens |
| `VERCEL_ORG_ID` | ID da organização no Vercel | `vercel link` (output) |
| `VERCEL_PROJECT_ID` | ID do projeto no Vercel | `vercel link` (output) |
| `SLACK_WEBHOOK` | Webhook do Slack para notificações | https://api.slack.com/messaging/webhooks |
| `CODECOV_TOKEN` | Token do Codecov (opcional) | https://codecov.io |

**Passo 3:** Criar branch `develop`

```bash
git checkout -b develop
git push origin develop
```

**Passo 4:** Testar pipeline

```bash
# Fazer commit em develop
git checkout develop
echo "test" >> README.md
git add README.md
git commit -m "test: trigger CI/CD"
git push origin develop

# Verificar em: https://github.com/iaraelevare-source/Elevare-FullStack/actions
```

### 📊 Fluxo do Pipeline

```
┌─────────────────────────────────────────────────────────────┐
│                         PUSH/PR                             │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │              LINT CODE                  │
        │  (ESLint backend + frontend)            │
        └─────────────────────────────────────────┘
                              │
                ┌─────────────┴─────────────┐
                ▼                           ▼
    ┌───────────────────┐       ┌───────────────────┐
    │  TEST BACKEND     │       │  TEST FRONTEND    │
    │  (Jest + PG)      │       │  (Jest)           │
    └───────────────────┘       └───────────────────┘
                │                           │
                └─────────────┬─────────────┘
                              ▼
        ┌─────────────────────────────────────────┐
        │              BUILD                      │
        │  (Backend + Frontend)                   │
        └─────────────────────────────────────────┘
                              │
                ┌─────────────┴─────────────┐
                ▼                           ▼
    ┌───────────────────┐       ┌───────────────────┐
    │  DEPLOY STAGING   │       │  DEPLOY PROD      │
    │  (develop)        │       │  (master)         │
    └───────────────────┘       └───────────────────┘
                │                           │
                └─────────────┬─────────────┘
                              ▼
        ┌─────────────────────────────────────────┐
        │              NOTIFY                     │
        │  (Slack: Success/Failure)               │
        └─────────────────────────────────────────┘
```

---

## 2. SCAN DE VULNERABILIDADES

### ✅ O que foi implementado

**Arquivo:** `.github/workflows/security.yml` (criar)

**Scans automáticos:**
- `npm audit` (vulnerabilidades de dependências)
- Snyk (análise de segurança)
- CodeQL (análise de código)

### 🔧 Como instalar

**Passo 1:** Criar workflow de segurança

```bash
cat > .github/workflows/security.yml << 'EOF'
name: Security Scan

on:
  push:
    branches: [master, develop]
  pull_request:
    branches: [master, develop]
  schedule:
    - cron: '0 6 * * 1'  # Toda segunda-feira às 06:00 UTC

jobs:
  npm-audit:
    name: NPM Audit
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v4
      
      - uses: actions/setup-node@v4
        with:
          node-version: '18'
      
      - name: Audit backend
        run: cd backend && npm audit --audit-level=high || true
        continue-on-error: true
      
      - name: Audit frontend
        run: cd frontend-landing && npm audit --audit-level=high || true
        continue-on-error: true
  
  snyk:
    name: Snyk Security
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v4
      
      - uses: snyk/actions/node@master
        env:
          SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
        with:
          command: test
        continue-on-error: true
  
  codeql:
    name: CodeQL Analysis
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v4
      
      - uses: github/codeql-action/init@v2
        with:
          languages: javascript, typescript
      
      - uses: github/codeql-action/analyze@v2
EOF

git add .github/workflows/security.yml
git commit -m "ci: adiciona scan de vulnerabilidades"
git push origin master
```

**Passo 2:** Configurar Snyk (opcional)

1. Criar conta: https://snyk.io
2. Obter token: https://app.snyk.io/account
3. Adicionar secret `SNYK_TOKEN` no GitHub

**Passo 3:** Ativar CodeQL

1. Acesse: https://github.com/iaraelevare-source/Elevare-FullStack/security/code-scanning
2. Clique em "Set up code scanning"
3. Selecione "CodeQL Analysis"

### 📊 Níveis de severidade

| Nível | Ação |
|-------|------|
| **Critical** | ❌ Bloqueia PR |
| **High** | ⚠️ Aviso |
| **Medium** | ℹ️ Informativo |
| **Low** | ℹ️ Ignorado |

---

## 3. DOCUMENTAÇÃO AUTOMÁTICA

### ✅ O que foi implementado

**Arquivo:** `jsdoc.json` ✅ (commitado)

**Scripts npm:**
- `npm run docs` - Gera documentação
- `npm run docs:watch` - Regenera ao modificar código
- `npm run docs:serve` - Serve em http://localhost:8080

### 🔧 Como usar

**Passo 1:** Instalar dependências

```bash
npm install -D jsdoc docdash
```

**Passo 2:** Gerar documentação

```bash
npm run docs
```

**Passo 3:** Visualizar

```bash
npm run docs:serve
# Abre http://localhost:8080
```

**Passo 4:** Publicar no GitHub Pages (opcional)

```bash
# Adicionar ao .github/workflows/ci.yml
- name: Generate docs
  run: npm run docs

- name: Deploy to GitHub Pages
  uses: peaceiris/actions-gh-pages@v3
  with:
    github_token: ${{ secrets.GITHUB_TOKEN }}
    publish_dir: ./docs/api
```

### 📝 Como documentar código

**Backend (TypeScript):**
```typescript
/**
 * Cria um novo lead no sistema
 * @param {Object} data - Dados do lead
 * @param {string} data.name - Nome do lead
 * @param {string} data.email - Email do lead
 * @param {string} data.phone - Telefone do lead
 * @returns {Promise<Lead>} Lead criado
 * @throws {ValidationError} Se dados inválidos
 * @example
 * const lead = await createLead({
 *   name: 'João Silva',
 *   email: 'joao@example.com',
 *   phone: '11999999999'
 * });
 */
async function createLead(data) {
  // ...
}
```

**Frontend (JavaScript):**
```javascript
/**
 * Envia formulário de lead
 * @param {HTMLFormElement} form - Formulário HTML
 * @returns {Promise<void>}
 */
async function submitLeadForm(form) {
  // ...
}
```

---

## 4. AMBIENTES SEPARADOS

### ✅ O que foi implementado

**2 ambientes automáticos:**
- **Staging** (branch `develop`) → https://staging.elevare.com
- **Production** (branch `master`) → https://elevare.com

### 🔧 Como configurar

**Passo 1:** Criar ambientes no GitHub

1. Acesse: https://github.com/iaraelevare-source/Elevare-FullStack/settings/environments
2. Clique em "New environment"
3. Nome: `staging`
4. Adicionar regra: "Required reviewers" (opcional)
5. Repetir para `production`

**Passo 2:** Configurar variáveis por ambiente

**Staging:**
```
DATABASE_URL=postgresql://user:pass@staging-db:5432/elevare_staging
SUPABASE_URL=https://staging-project.supabase.co
SUPABASE_ANON_KEY=staging_key...
```

**Production:**
```
DATABASE_URL=postgresql://user:pass@prod-db:5432/elevare_prod
SUPABASE_URL=https://prod-project.supabase.co
SUPABASE_ANON_KEY=prod_key...
```

**Passo 3:** Workflow de deploy

O workflow já está configurado para:
- `develop` → Deploy automático em **staging**
- `master` → Deploy automático em **production**

### 📊 Fluxo de trabalho

```
┌─────────────────────────────────────────────────────────────┐
│                    DESENVOLVIMENTO                          │
│  (feature branches)                                         │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼ (PR)
┌─────────────────────────────────────────────────────────────┐
│                       DEVELOP                               │
│  (staging environment)                                      │
│  https://staging.elevare.com                                │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼ (PR + Review)
┌─────────────────────────────────────────────────────────────┐
│                       MASTER                                │
│  (production environment)                                   │
│  https://elevare.com                                        │
└─────────────────────────────────────────────────────────────┘
```

---

## 5. ALERTAS DE FALHA

### ✅ O que foi implementado

**Notificações automáticas via:**
- Slack (webhook)
- Email (GitHub notifications)
- GitHub Checks (status no PR)

### 🔧 Como configurar

**Passo 1:** Criar webhook do Slack

1. Acesse: https://api.slack.com/messaging/webhooks
2. Clique em "Create New App"
3. Escolha "From scratch"
4. Nome: "Elevare CI/CD"
5. Workspace: Seu workspace
6. Ativar "Incoming Webhooks"
7. Adicionar webhook ao canal desejado
8. Copiar URL do webhook

**Passo 2:** Adicionar secret no GitHub

1. Acesse: https://github.com/iaraelevare-source/Elevare-FullStack/settings/secrets/actions
2. Clique em "New repository secret"
3. Nome: `SLACK_WEBHOOK`
4. Valor: URL do webhook copiado
5. Salvar

**Passo 3:** Testar notificação

```bash
# Fazer commit que falha
git checkout develop
echo "syntax error" >> backend/src/main.ts
git add backend/src/main.ts
git commit -m "test: trigger failure notification"
git push origin develop

# Verificar notificação no Slack
```

### 📊 Tipos de notificação

**Sucesso:**
```
✅ Deploy concluído com sucesso!
Branch: master
Commit: abc123 - feat: nova funcionalidade
Autor: @usuario
Duração: 3m 45s
URL: https://elevare.com
```

**Falha:**
```
❌ Pipeline falhou!
Branch: develop
Commit: def456 - fix: correção de bug
Autor: @usuario
Job falhado: test-backend
Erro: 5 testes falharam
Logs: https://github.com/.../actions/runs/123
```

---

## 6. INSTALAÇÃO COMPLETA

### Checklist de instalação

- [ ] **1. Workflows**
  - [ ] Adicionar `.github/workflows/ci.yml`
  - [ ] Adicionar `.github/workflows/security.yml`
  - [ ] Adicionar `.github/workflows/backup.yml` (já existe)

- [ ] **2. Secrets do GitHub**
  - [ ] `VERCEL_TOKEN`
  - [ ] `VERCEL_ORG_ID`
  - [ ] `VERCEL_PROJECT_ID`
  - [ ] `SLACK_WEBHOOK`
  - [ ] `SNYK_TOKEN` (opcional)
  - [ ] `CODECOV_TOKEN` (opcional)

- [ ] **3. Ambientes do GitHub**
  - [ ] Criar ambiente `staging`
  - [ ] Criar ambiente `production`
  - [ ] Configurar variáveis por ambiente

- [ ] **4. Branches**
  - [ ] Criar branch `develop`
  - [ ] Configurar branch protection rules

- [ ] **5. Documentação**
  - [ ] Instalar `jsdoc` e `docdash`
  - [ ] Gerar documentação: `npm run docs`
  - [ ] Publicar no GitHub Pages (opcional)

- [ ] **6. Testes**
  - [ ] Fazer commit em `develop` (trigger staging)
  - [ ] Verificar deploy em staging
  - [ ] Fazer PR para `master` (trigger production)
  - [ ] Verificar deploy em production

### Script de instalação rápida

```bash
#!/bin/bash

# 1. Adicionar workflows
git add .github/workflows/ci.yml
git add .github/workflows/security.yml
git commit -m "ci: adiciona workflows de CI/CD e segurança"
git push origin master

# 2. Criar branch develop
git checkout -b develop
git push origin develop
git checkout master

# 3. Instalar dependências de documentação
npm install -D jsdoc docdash

# 4. Gerar documentação
npm run docs

echo "✅ Instalação concluída!"
echo ""
echo "Próximos passos:"
echo "1. Configurar secrets no GitHub"
echo "2. Criar ambientes (staging/production)"
echo "3. Testar pipeline"
```

---

## 📊 MÉTRICAS ESPERADAS

| Métrica | Valor |
|---------|-------|
| **Tempo de build** | 3-5 minutos |
| **Tempo de deploy** | 2-3 minutos |
| **Cobertura de testes** | > 40% (meta: 80%) |
| **Vulnerabilidades críticas** | 0 |
| **Uptime** | > 99.9% |

---

## 🎯 BENEFÍCIOS

| Antes | Depois | Melhoria |
|-------|--------|----------|
| Deploy manual (30min) | Deploy automático (5min) | 83% |
| Testes manuais (1h) | Testes automáticos (3min) | 95% |
| Vulnerabilidades não detectadas | Scan automático diário | ∞ |
| Docs desatualizadas | Docs automáticas | 100% |
| Falhas não notificadas | Alertas instantâneos | ∞ |

---

**Tudo pronto para instalação!** 🚀
