import React, { useState, useEffect } from "react";
import { Layout, Button, CheckCircle2, Calendar, ArrowRight } from "../components/BaseComponents";
import AppointmentsService, { Appointment, SmartSlot } from "../services/appointments.service";

const Appointments: React.FC = () => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [todayCount, setTodayCount] = useState(0);
  const [smartSlot, setSmartSlot] = useState<SmartSlot | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [appts, count, slot] = await Promise.all([
          AppointmentsService.getAllAppointments(),
          AppointmentsService.getTodayAppointmentsCount(),
          AppointmentsService.getSmartSlotSuggestion(),
        ]);
        setAppointments(appts);
        setTodayCount(count);
        setSmartSlot(slot);
      } catch (err) {
        setError("Falha ao carregar dados de agendamento. Verifique a conexão com o backend.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const getStatusColor = (status: Appointment['status']) => {
    switch (status) {
      case 'Confirmado':
        return 'text-green-500';
      case 'Pendente':
        return 'text-yellow-500';
      case 'Cancelado':
      case 'No-Show':
        return 'text-red-500';
      default:
        return 'text-gray-500';
    }
  };

  if (loading) {
    return (
      <Layout>
        <section className="pt-20 pb-32 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-6">Carregando Agendamentos...</h1>
        </section>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <section className="pt-20 pb-32 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-6 text-red-600">Erro ao Carregar</h1>
          <p className="text-lg text-red-500">{error}</p>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      <section className="pt-20 pb-32 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold mb-6 text-center">Agendamentos</h1>
        <p className="text-center text-gray-600 mb-10">
          Visualize sua agenda completa. Confirme, reagende ou cancele atendimentos sem sair do app.
        </p>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {/* Card de Agendamento */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-lg transition">
            <Calendar className="w-8 h-8 text-[#667eea] mb-3" />
            <h3 className="font-bold text-xl mb-1">Agendamentos de Hoje</h3>
            <p className="text-gray-600 text-sm">Total de atendimentos marcados para o dia.</p>
            <div className="text-5xl font-extrabold text-brand-dark mt-4">{todayCount}</div>
          </div>
          {/* Card de Sugestão Inteligente */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-brand-lavender hover:shadow-lg transition">
            <ArrowRight className="w-8 h-8 text-brand-primary mb-3" />
            <h3 className="font-bold text-xl mb-1 text-brand-primary">Sugestão Inteligente</h3>
            <p className="text-gray-600 text-sm">{smartSlot?.reason || 'Carregando...'}</p>
            <div className="text-3xl font-extrabold text-brand-dark mt-4">{smartSlot?.time || 'N/A'}</div>
          </div>
          {/* Card de No-Show */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-lg transition">
            <CheckCircle2 className="w-8 h-8 text-red-500 mb-3" />
            <h3 className="font-bold text-xl mb-1">Taxa de No-Show</h3>
            <p className="text-gray-600 text-sm">Leads que não compareceram no último mês.</p>
            <div className="text-5xl font-extrabold text-brand-dark mt-4">8%</div>
          </div>
        </div>

        <h2 className="text-2xl font-bold mb-4 mt-10">Próximos Agendamentos</h2>
        <div className="space-y-4">
          {appointments.map((appt) => (
            <div key={appt.id} className="flex items-center justify-between bg-white p-4 rounded-xl shadow-sm hover:shadow-lg transition">
              <div className="flex items-center gap-4">
                <span className="text-xl font-bold text-brand-dark">{appt.time}</span>
                <span className="font-medium text-gray-800">{appt.leadName}</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className={`w-5 h-5 ${getStatusColor(appt.status)}`} />
                <span className="text-gray-600">{appt.status}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button size="lg">Ver Agenda Completa</Button>
        </div>
      </section>
    </Layout>
  );
};

export default Appointments;
