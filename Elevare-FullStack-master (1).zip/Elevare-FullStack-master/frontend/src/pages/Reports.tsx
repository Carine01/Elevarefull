import React, { useState, useEffect } from "react";
import { Layout, Button, BarChart3 } from "../components/BaseComponents";
import ReportsService, { Metric, FunnelStep } from "../services/reports.service";

const Reports: React.FC = () => {
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [funnel, setFunnel] = useState<FunnelStep[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await ReportsService.getDashboardReports();
        setMetrics(data.metrics);
        setFunnel(data.funnel);
      } catch (err) {
        setError("Falha ao carregar relatórios. Verifique a conexão com o backend.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) {
    return (
      <Layout>
        <section className="pt-20 pb-32 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-6">Carregando Relatórios...</h1>
        </section>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <section className="pt-20 pb-32 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-6 text-red-600">Erro ao Carregar</h1>
          <p className="text-lg text-red-500">{error}</p>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      <section className="pt-20 pb-32 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold mb-6 text-center">Relatórios e Métricas</h1>
        <p className="text-center text-gray-600 mb-10">
          Tome decisões estratégicas com dados em tempo real. Saiba onde investir seu tempo e dinheiro.
        </p>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {metrics.map((metric, index) => (
            <div key={index} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 text-center hover:shadow-lg transition">
              <BarChart3 className={`w-8 h-8 ${metric.color} mx-auto mb-3`} />
              <h3 className="font-bold text-xl mb-1">{metric.title}</h3>
              <div className={`text-5xl font-extrabold ${metric.color} mt-4`}>{metric.value}</div>
            </div>
          ))}
        </div>

        <h2 className="text-2xl font-bold mb-4 mt-10">Funil de Vendas</h2>
        <div className="bg-white p-6 rounded-2xl shadow-xl border border-gray-100">
          {/* Gráfico Dinâmico do Funil */}
          <div className="h-64 flex items-end justify-around">
            {funnel.map((step, index) => (
              <div
                key={index}
                style={{ height: `${step.percentage}%`, backgroundColor: step.color }}
                className="w-1/5 rounded-t-lg flex flex-col justify-end items-center p-2 transition-all duration-500"
              >
                <span className="font-bold text-white">{step.percentage}%</span>
                <span className="text-sm text-white">{step.name}</span>
              </div>
            ))}
          </div>
          <p className="text-center text-sm text-gray-600 mt-4">
            Acompanhe a jornada do seu cliente e identifique gargalos.
          </p>
        </div>

        <div className="mt-12 text-center">
          <Button size="lg">Exportar Relatório Completo</Button>
        </div>
      </section>
    </Layout>
  );
};

export default Reports;
