import React from 'react';
import Layout from '../components/Layout';

// Componentes de Seção (Serão criados a seguir)
const HeroSection: React.FC = () => {
  // Conteúdo da Seção Hero do index.html
  return (
    <section className="relative overflow-hidden pt-32 pb-40 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-white via-brand-lavender/5 to-white">
      {/* Decorative Background Blur */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-brand-lavender/15 rounded-full blur-[80px] -z-10 pointer-events-none"></div>

      <div className="max-w-4xl mx-auto text-center">
        {/* Headline Principal */}
        <h1 className="text-5xl sm:text-6xl md:text-7xl font-bold text-brand-dark mb-6 leading-[1.1] tracking-tight">
          Entre tecnologia e toque humano, <br />
          <span className="text-gradient">existe a Elevare</span>.
        </h1>

        {/* Subheadline */}
        <p className="text-xl sm:text-2xl text-gray-700 mb-10 max-w-3xl mx-auto leading-relaxed">
          O ponto de equilíbrio onde sua rotina descomplica — e sua clínica cresce com propósito.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <a href="https://wa.me/5527999217624?text=Olá!%20Quero%20ativar%20meus%2015%20dias%20grátis%20da%20IARA" target="_blank" className="bg-brand-gradient text-white px-8 py-4 rounded-full font-medium shadow-2xl shadow-brand-primary/30 hover:-translate-y-1 transition-all duration-300 text-lg inline-flex items-center justify-center">
            Ative seus 15 dias grátis
            {/* Ícone Arrow Right */}
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right ml-2 w-5 h-5 inline"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
          </a>
          <a href="#beneficios" className="border border-brand-lavender text-brand-primary px-8 py-4 rounded-full font-medium hover:bg-gray-50 transition-all duration-300 text-lg bg-white inline-flex items-center justify-center">
            Conhecer IARA
          </a>
        </div>

        {/* Estatísticas com Carrossel Infinito (Migrar o HTML completo) */}
        <div className="max-w-7xl mx-auto mt-20 relative">
          <div className="stats-carousel-mask overflow-hidden">
            <div className="stats-carousel-track flex gap-8">
              {/* Estatística 1 */}
              <div className="stats-card group relative bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100 hover:border-brand-lavender flex-shrink-0 w-80">
                <div className="relative h-48 mb-6 rounded-2xl overflow-hidden">
                  <img src="/images/iara_whatsapp_opt.jpg" alt="IARA WhatsApp - Mais Agendamentos" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                </div>
                <div className="text-center">
                  <div className="text-5xl font-bold text-brand-primary mb-2">94%</div>
                  <p className="text-base text-gray-700 font-semibold">Mais agendamentos</p>
                  <p className="text-sm text-gray-500 mt-2">IARA converte leads 24/7</p>
                </div>
              </div>

              {/* Estatística 2 */}
              <div className="stats-card group relative bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100 hover:border-brand-lavender flex-shrink-0 w-80">
                <div className="relative h-48 mb-6 rounded-2xl overflow-hidden">
                  <img src="/images/elevare_dashboard_opt.jpg" alt="Dashboard Elevare - Mais Controle" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                </div>
                <div className="text-center">
                  <div className="text-5xl font-bold text-brand-primary mb-2">3x</div>
                  <p className="text-base text-gray-700 font-semibold">Mais controle</p>
                  <p className="text-sm text-gray-500 mt-2">Dados em tempo real</p>
                </div>
              </div>

              {/* Estatística 3 */}
              <div className="stats-card group relative bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100 hover:border-brand-lavender flex-shrink-0 w-80">
                <div className="relative h-48 mb-6 rounded-2xl overflow-hidden">
                  <img src="/images/iara_analytics_opt.jpg" alt="IARA Analytics - Mais Faturamento" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                </div>
                <div className="text-center">
                  <div className="text-5xl font-bold text-brand-primary mb-2">R$ 10k+</div>
                  <p className="text-base text-gray-700 font-semibold">Faturamento extra</p>
                  <p className="text-sm text-gray-500 mt-2">Com a inteligência da IARA</p>
                </div>
              </div>
              
              {/* Repetição para o carrossel infinito */}
              <div className="stats-card group relative bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100 hover:border-brand-lavender flex-shrink-0 w-80">
                <div className="relative h-48 mb-6 rounded-2xl overflow-hidden">
                  <img src="/images/iara_whatsapp_opt.jpg" alt="IARA WhatsApp - Mais Agendamentos" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                </div>
                <div className="text-center">
                  <div className="text-5xl font-bold text-brand-primary mb-2">94%</div>
                  <p className="text-base text-gray-700 font-semibold">Mais agendamentos</p>
                  <p className="text-sm text-gray-500 mt-2">IARA converte leads 24/7</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const FeaturesSection: React.FC = () => {
  // Conteúdo da Seção Benefícios do index.html
  return (
    <section id="beneficios" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-brand-dark mb-4 tracking-tight">
            Seu tempo é precioso. Deixe a IARA cuidar do resto.
          </h2>
          <p className="text-lg text-gray-600">
            A IARA é a assistente inteligente que faz o trabalho operacional para você focar no atendimento.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-10">
          {/* Feature 1 */}
          <div className="bg-white p-8 rounded-3xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300">
            <div className="w-12 h-12 bg-brand-lavender text-brand-primary rounded-xl flex items-center justify-center mb-4">
              {/* Ícone Message Square */}
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-message-square w-6 h-6"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            </div>
            <h3 className="text-xl font-bold text-brand-dark mb-3">Atendimento 24/7</h3>
            <p className="text-gray-600 leading-relaxed">
              A IARA responde seus leads no WhatsApp a qualquer hora, sem falhas. Não perca mais clientes por demora no atendimento.
            </p>
          </div>

          {/* Feature 2 */}
          <div className="bg-white p-8 rounded-3xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300">
            <div className="w-12 h-12 bg-brand-lavender text-brand-primary rounded-xl flex items-center justify-center mb-4">
              {/* Ícone Calendar Check */}
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-calendar-check w-6 h-6"><path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="m9 16 2 2 4-4"/></svg>
            </div>
            <h3 className="text-xl font-bold text-brand-dark mb-3">Agendamento Inteligente</h3>
            <p className="text-gray-600 leading-relaxed">
              A IARA agenda automaticamente, verificando a disponibilidade e priorizando leads quentes (graças à nossa Análise Preditiva).
            </p>
          </div>

          {/* Feature 3 */}
          <div className="bg-white p-8 rounded-3xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300">
            <div className="w-12 h-12 bg-brand-lavender text-brand-primary rounded-xl flex items-center justify-center mb-4">
              {/* Ícone Zap */}
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-6 h-6"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
            </div>
            <h3 className="text-xl font-bold text-brand-dark mb-3">Automação de Campanhas</h3>
            <p className="text-gray-600 leading-relaxed">
              Dispare campanhas de recuperação para leads mornos ou clientes "no-show" automaticamente, usando a linguagem exata que converte.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

const PricingSection: React.FC = () => {
  // Conteúdo da Seção Planos do index.html
  return (
    <section id="planos" className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-brand-dark mb-4 tracking-tight">Escolha seu plano Elevare. Sua Tranquilidade é Nossa Prioridade</h2>
          <p className="text-lg text-gray-600">Tudo que você precisa para vender mais com menos esforço</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto items-start">
          {/* Plano Mensal */}
          <div className="bg-white rounded-3xl p-8 border border-gray-200 shadow-sm hover:border-brand-primary/30 transition-all duration-300">
            <h3 className="text-2xl font-bold text-brand-dark mb-4">Mensal</h3>
            <div className="flex items-baseline mb-2">
              <span className="text-sm font-medium text-gray-600 mr-1">R$</span>
              <span className="text-5xl font-extrabold text-brand-dark tracking-tight">157</span>
              <span className="text-gray-600 ml-2 font-medium">/mês</span>
            </div>
            <p className="text-sm text-gray-600 mb-8 font-medium">cancele quando quiser</p>

            <a href="https://wa.me/5527999217624?text=Olá!%20Quero%20começar%20meus%2015%20dias%20grátis" target="_blank" className="w-full mb-8 rounded-xl h-12 text-base border border-brand-lavender text-brand-primary hover:bg-gray-50 transition-all duration-300 font-medium inline-flex items-center justify-center">
              Começar 15 dias grátis
            </a>

            <div className="space-y-4">
              <p className="font-semibold text-brand-dark text-sm mb-4">O que está incluído:</p>
              <div className="space-y-3">
                {/* Item 1 */}
                <div className="flex items-start gap-3 text-sm">
                  {/* Ícone Check Circle 2 */}
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 w-5 h-5 text-brand-primary flex-shrink-0 mt-0.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                  <span className="text-gray-600">IARA responde seus clientes 24h</span>
                </div>
                {/* Item 2 */}
                <div className="flex items-start gap-3 text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 w-5 h-5 text-brand-primary flex-shrink-0 mt-0.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                  <span className="text-gray-600">Agenda automaticamente pelo WhatsApp</span>
                </div>
                {/* Item 3 */}
                <div className="flex items-start gap-3 text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 w-5 h-5 text-brand-primary flex-shrink-0 mt-0.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                  <span className="text-gray-600">Funis prontos de vendas para estética</span>
                </div>
                {/* Item 4 */}
                <div className="flex items-start gap-3 text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 w-5 h-5 text-brand-primary flex-shrink-0 mt-0.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                  <span className="text-gray-600">Disparo em massa inteligente</span>
                </div>
                {/* Item 5 */}
                <div className="flex items-start gap-3 text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 w-5 h-5 text-brand-primary flex-shrink-0 mt-0.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                  <span className="text-gray-600">Lembretes automáticos (reduz faltas)</span>
                </div>
                {/* Item 6 */}
                <div className="flex items-start gap-3 text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 w-5 h-5 text-brand-primary flex-shrink-0 mt-0.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                  <span className="text-gray-600">Relatórios e métricas da clínica</span>
                </div>
                {/* Item 7 */}
                <div className="flex items-start gap-3 text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 w-5 h-5 text-brand-primary flex-shrink-0 mt-0.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                  <span className="text-gray-600">Onboarding personalizado</span>
                </div>
                {/* Item 8 */}
                <div className="flex items-start gap-3 text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 w-5 h-5 text-brand-primary flex-shrink-0 mt-0.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                  <span className="text-gray-600">Suporte humanizado por email</span>
                </div>
              </div>
            </div>
          </div>

          {/* Plano Anual */}
          <div className="relative bg-white rounded-3xl p-8 border-2 border-brand-primary shadow-2xl shadow-brand-primary/10 transform md:-translate-y-4">
            <div className="absolute top-0 right-0 bg-brand-gradient text-white text-[10px] font-bold px-3 py-1.5 rounded-bl-xl rounded-tr-lg uppercase tracking-wider">
              Mais escolhido
            </div>

            <h3 className="text-2xl font-bold text-brand-primary mb-4">Anual</h3>
            <div className="flex items-baseline mb-2">
              <span className="text-sm font-medium text-gray-600 mr-1">R$</span>
              <span className="text-5xl font-extrabold text-brand-dark tracking-tight">130</span>
              <span className="text-gray-600 ml-2 font-medium">/mês</span>
            </div>
            <p className="text-sm text-green-600 font-bold mb-1">Economize R$ 314 no ano</p>
            <p className="text-xs text-gray-600 mb-8">cobrado anualmente</p>

            <button className="w-full mb-8 bg-brand-gradient text-white shadow-lg shadow-brand-primary/20 rounded-xl h-12 text-base font-medium hover:-translate-y-0.5 transition-all duration-300">
              Começar 15 dias grátis
            </button>

            <div className="space-y-4">
              <div className="p-3 bg-gray-100 rounded-lg text-sm text-brand-primary font-bold mb-4 flex items-center gap-2">
                {/* Ícone Zap */}
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-zap w-4 h-4 fill-current"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                TUDO do plano Mensal incluído
              </div>

              <div className="space-y-3">
                {/* Item 1 */}
                <div className="flex items-start gap-3 text-sm">
                  {/* Ícone Check Circle 2 */}
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 w-5 h-5 text-green-500 flex-shrink-0 mt-0.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                  <span className="text-brand-dark font-medium">2 meses grátis no ano (Economia de R$ 314)</span>
                </div>
                {/* Item 2 */}
                <div className="flex items-start gap-3 text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 w-5 h-5 text-green-500 flex-shrink-0 mt-0.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                  <span className="text-brand-dark font-medium">Suporte prioritário (até 4 horas úteis)</span>
                </div>
                {/* Item 3 */}
                <div className="flex items-start gap-3 text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 w-5 h-5 text-green-500 flex-shrink-0 mt-0.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                  <span className="text-brand-dark font-medium">Consultoria de estratégia de conversão</span>
                </div>
                {/* Item 4 */}
                <div className="flex items-start gap-3 text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 w-5 h-5 text-green-500 flex-shrink-0 mt-0.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                  <span className="text-brand-dark font-medium">Acesso antecipado a novos recursos</span>
                </div>
                {/* Item 5 */}
                <div className="flex items-start gap-3 text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 w-5 h-5 text-green-500 flex-shrink-0 mt-0.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                  <span className="text-brand-dark font-medium">Templates exclusivos de campanhas sazonais</span>
                </div>
                {/* Item 6 */}
                <div className="flex items-start gap-3 text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 w-5 h-5 text-green-500 flex-shrink-0 mt-0.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                  <span className="text-brand-dark font-medium">Comunidade exclusiva de esteticistas</span>
                </div>
                {/* Item 7 */}
                <div className="flex items-start gap-3 text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-check-circle-2 w-5 h-5 text-green-500 flex-shrink-0 mt-0.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="m9 12 2 2 4-4"/></svg>
                  <span className="text-brand-dark font-medium">Preço garantido por 1 ano</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const TestimonialsSection: React.FC = () => {
  // Conteúdo da Seção Depoimentos e Quem Somos Final do index.html
  return (
    <>
      {/* Depoimentos */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-brand-dark mb-4 tracking-tight">O que nossas clientes dizem: Histórias reais de transformação</h2>

            {/* Badge Nota 5/5 */}
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-yellow-50 to-yellow-100 border-2 border-yellow-300 rounded-full px-6 py-3 shadow-lg">
              <div className="flex gap-1">
                {/* Ícones Star */}
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-500 fill-yellow-500"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-500 fill-yellow-500"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-500 fill-yellow-500"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-500 fill-yellow-500"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-500 fill-yellow-500"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
              </div>
              <span className="font-bold text-lg text-gray-800">Nota 5/5</span>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Depoimento 1 */}
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-lg hover:border-brand-lavender transition-all duration-300">
              <div className="flex justify-center mb-6">
                <img src="/images/julianapegas_opt.jpg" alt="Juliana Pegas - Depoimento Elevare" className="w-24 h-24 rounded-full object-cover border-4 border-brand-lavender shadow-lg" width="96" height="96" loading="lazy" />
              </div>
              <div className="mb-6">
                <div className="flex gap-1 mb-4 justify-center">
                  {/* Ícones Star */}
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-400 fill-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-400 fill-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-400 fill-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-400 fill-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-400 fill-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                </div>
                <p className="text-gray-700 leading-relaxed mb-6 italic">
                  “Eu estava cansada de tentar sozinha. A rotina, a correria, a falta de orientação… tudo pesava. Quando conheci a Elevare, foi como respirar de novo. Meu atendimento mudou, minha agenda mudou e, principalmente, eu mudei. A Elevare não só organizou minha clínica… ela organizou minha cabeça.”
                </p>
              </div>
              <div className="border-t border-gray-100 pt-4">
                <p className="font-bold text-brand-dark">Juliana Pegas</p>
                <p className="text-sm text-gray-500">Governador Valadares - MG</p>
              </div>
            </div>

            {/* Depoimento 2 */}
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-lg hover:border-brand-lavender transition-all duration-300">
              <div className="flex justify-center mb-6">
                <img src="/images/grazielatoledo_opt.jpg" alt="Graziela Toledo - Depoimento Elevare" className="w-24 h-24 rounded-full object-cover border-4 border-brand-lavender shadow-lg" width="96" height="96" loading="lazy" />
              </div>
              <div className="mb-6">
                <div className="flex gap-1 mb-4 justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-400 fill-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-400 fill-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-400 fill-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-400 fill-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-400 fill-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                </div>
                <p className="text-gray-700 leading-relaxed mb-6 italic">
                  “Eu achava que já estava no meu limite profissional, até perceber que o que faltava não era capacidade — era direção. A Elevare fez meu faturamento e minha confiança subirem juntos. Simplismente parei de sobreviver e comecei a prosperar.”
                </p>
              </div>
              <div className="border-t border-gray-100 pt-4">
                <p className="font-bold text-brand-dark">Graziela Toledo</p>
                <p className="text-sm text-gray-500">Boston, EUA</p>
              </div>
            </div>

            {/* Depoimento 3 */}
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-lg hover:border-brand-lavender transition-all duration-300">
              <div className="flex justify-center mb-6">
                <img src="/images/tayanabasiley_opt.jpg" alt="Tayana Basiley - Depoimento Elevare" className="w-24 h-24 rounded-full object-cover border-4 border-brand-lavender shadow-lg" width="96" height="96" loading="lazy" />
              </div>
              <div className="mb-6">
                <div className="flex gap-1 mb-4 justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-400 fill-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-400 fill-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-400 fill-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-400 fill-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-star w-5 h-5 text-yellow-400 fill-yellow-400"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                </div>
                <p className="text-gray-700 leading-relaxed mb-6 italic">
                  “Meu maior medo era não dar conta da parte tecnológica. Sempre me senti travada com sistemas, planilhas e automações. Mas a forma como a Elevare conduz é prática, foi feito para mulheres como eu.”
                </p>
              </div>
              <div className="border-t border-gray-100 pt-4">
                <p className="font-bold text-brand-dark">Tayana Basiley</p>
                <p className="text-sm text-gray-500">Vila Velha - ES</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quem Somos Final */}
      <section className="relative py-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-brand-primary/5 via-white to-brand-secondary/5">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold text-brand-dark mb-8 tracking-tight text-center">
            Quem Somos
          </h2>

          {/* Layout Lado a Lado */}
          <div className="flex flex-col md:flex-row items-center gap-8">
            {/* Foto Carine Marques */}
            <div className="flex-shrink-0">
              <img src="/images/carine_marques_opt.jpg" alt="Carine Marques - Fundadora da Elevare" className="w-64 h-64 md:w-80 md:h-80 rounded-2xl object-cover shadow-2xl" width="320" height="320" loading="lazy" />
            </div>

            {/* Caixa de Texto Destacada */}
            <div className="flex-1 bg-white/80 backdrop-blur-sm p-6 md:p-8 rounded-3xl shadow-xl border border-brand-lavender/30">
              <div className="space-y-4 text-lg text-gray-700 leading-relaxed">
                <p>
                  A Elevare é uma plataforma de automação inteligente criada para esteticistas que precisam de eficiência real — não promessas vazias.
                </p>

                <p>
                  Fundada por <span className="font-bold text-brand-primary">Carine Marques</span>, profissional com mais de 20 anos de experiência em estética avançada, a Elevare nasceu onde a tecnologia quase nunca nasce: na rotina.
                </p>

                <p className="font-semibold text-brand-dark">
                  Não foi criada em um escritório de desenvolvedores.
                </p>

                <p>
                  Ganhou forma entre atendimentos, retornos de clientes, atrasos, sobrecarga, cansaço e a necessidade urgente de uma operação que funcionasse sem depender da sua presença o tempo todo.
                </p>

                <p className="font-bold text-brand-dark text-xl mt-4">
                  Foi construída da vida real para a vida real.
                </p>

                <p className="text-lg text-brand-primary font-semibold">
                  E por isso funciona.
                </p>
              </div>
            </div>
          </div>

          <div className="text-center mt-8">

            <a href="https://wa.me/5527999217624?text=Olá!%20Quero%20a%20IARA%20no%20meu%20WhatsApp" target="_blank" className="bg-brand-gradient text-white px-10 py-4 text-lg rounded-full shadow-2xl shadow-brand-primary/30 hover:-translate-y-1 transition-all font-bold inline-flex items-center">
              Quero a IARA no meu WhatsApp
              {/* Ícone Arrow Right */}
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right ml-2 w-5 h-5 inline"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

const Home: React.FC = () => {
  return (
    <Layout>
      <HeroSection />
      <FeaturesSection />
      {/* Seção de Benefícios Detalhados (Migrar do index.html) */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-brand-dark">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h2 className="text-3xl sm:text-4xl font-bold mb-4 tracking-tight">
                O que a IARA faz por você:
              </h2>
              <p className="text-lg text-gray-300 mb-8">
                A IARA não é só uma secretária. É uma estrategista que trabalha 24h para o seu negócio.
              </p>
              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <div className="bg-white/10 p-2 rounded-lg backdrop-blur-sm border border-white/10">
                    {/* Ícone Check */}
                    <span className="text-xl font-bold text-white">✓</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-lg mb-1 text-white">Atendimento Imediato</h4>
                    <p className="text-purple-100 leading-relaxed text-sm opacity-90">Você deixa de perder cliente por falta de resposta. Cada lead é atendido na hora.</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-white/10 p-2 rounded-lg backdrop-blur-sm border border-white/10">
                    <span className="text-xl font-bold text-white">✓</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-lg mb-1 text-white">Eficiência Total</h4>
                    <p className="text-purple-100 leading-relaxed text-sm opacity-90">Você para de repetir as mesmas informações de preço e local mil vezes por dia.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="bg-white/10 p-2 rounded-lg backdrop-blur-sm border border-white/10">
                  <span className="text-xl font-bold text-white">✓</span>
                </div>
                <div>
                  <h4 className="font-bold text-lg mb-1 text-white">Pausas Reais</h4>
                  <p className="text-purple-100 leading-relaxed text-sm opacity-90">Você volta a respirar entre um atendimento e outro, sem correr para o celular.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="bg-white/10 p-2 rounded-lg backdrop-blur-sm border border-white/10">
                  <span className="text-xl font-bold text-white">✓</span>
                </div>
                <div>
                  <h4 className="font-bold text-lg mb-1 text-white">Equilíbrio</h4>
                  <p className="text-purple-100 leading-relaxed text-sm opacity-90">A vida volta ao seu eixo. Sua clínica funciona, você descansa.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <PricingSection />
      <TestimonialsSection />
    </Layout>
  );
};

export default Home;
