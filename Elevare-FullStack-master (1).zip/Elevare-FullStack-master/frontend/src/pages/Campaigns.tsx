import React, { useState, useEffect } from "react";
import { Layout, Button, Zap, ArrowRight } from "../components/BaseComponents";
import CampaignsService, { Campaign } from "../services/campaigns.service";

const Campaigns: React.FC = () => {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [activeCount, setActiveCount] = useState(0);
  const [avgConversion, setAvgConversion] = useState('0%');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [camps, count, avg] = await Promise.all([
          CampaignsService.getAllCampaigns(),
          CampaignsService.getActiveCampaignsCount(),
          CampaignsService.getAverageConversion(),
        ]);
        setCampaigns(camps);
        setActiveCount(count);
        setAvgConversion(avg);
      } catch (err) {
        setError("Falha ao carregar dados de campanhas. Verifique a conexão com o backend.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const getStatusColor = (status: Campaign['status']) => {
    switch (status) {
      case 'Ativa':
        return 'bg-green-100 text-green-800';
      case 'Pausada':
        return 'bg-yellow-100 text-yellow-800';
      case 'Finalizada':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <Layout>
        <section className="pt-20 pb-32 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-6">Carregando Campanhas...</h1>
        </section>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <section className="pt-20 pb-32 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-6 text-red-600">Erro ao Carregar</h1>
          <p className="text-lg text-red-500">{error}</p>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      <section className="pt-20 pb-32 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold mb-6 text-center">Automação de Campanhas</h1>
        <p className="text-center text-gray-600 mb-10">
          Dispare sequências de mensagens inteligentes para reativar leads mornos, recuperar no-shows e nutrir clientes.
        </p>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {/* Card de Campanhas Ativas */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-lg transition">
            <Zap className="w-8 h-8 text-green-500 mb-3" />
            <h3 className="font-bold text-xl mb-1">Campanhas Ativas</h3>
            <p className="text-gray-600 text-sm">Sequências rodando no momento.</p>
            <div className="text-5xl font-extrabold text-brand-dark mt-4">{activeCount}</div>
          </div>
          {/* Card de Conversão Média */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-lg transition">
            <ArrowRight className="w-8 h-8 text-brand-primary mb-3" />
            <h3 className="font-bold text-xl mb-1">Conversão Média</h3>
            <p className="text-gray-600 text-sm">Taxa de leads que agendaram após a campanha.</p>
            <div className="text-5xl font-extrabold text-brand-dark mt-4">{avgConversion}</div>
          </div>
          {/* Card de Variáveis Dinâmicas */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-brand-lavender hover:shadow-lg transition">
            <Zap className="w-8 h-8 text-brand-primary mb-3" />
            <h3 className="font-bold text-xl mb-1 text-brand-primary">Variáveis Dinâmicas</h3>
            <p className="text-gray-600 text-sm">Personalização total com {'{lead.nome}'} e {'{agendamento.data}'}.</p>
            <div className="text-sm font-extrabold text-brand-dark mt-4">Pronto para uso</div>
          </div>
        </div>

        <h2 className="text-2xl font-bold mb-4 mt-10">Lista de Campanhas</h2>
        <div className="space-y-4">
          {campaigns.map((campaign) => (
            <div key={campaign.id} className="flex items-center justify-between bg-white p-4 rounded-xl shadow-sm hover:shadow-lg transition">
              <div className="flex items-center gap-4">
                <span className="font-medium text-gray-800">{campaign.name}</span>
              </div>
              <div className="flex items-center gap-4">
                <span className={`px-3 py-1 text-xs font-semibold rounded-full ${getStatusColor(campaign.status)}`}>{campaign.status}</span>
                <span className="text-sm text-gray-600">Leads: {campaign.leadsCount}</span>
                <span className="text-sm text-gray-600">Conv.: {campaign.conversionRate}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button size="lg">Criar Nova Campanha</Button>
        </div>
      </section>
    </Layout>
  );
};

export default Campaigns;
