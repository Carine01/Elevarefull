import React, { useState, useEffect } from "react";
import { Layout, Button, Users, BarChart3, Smartphone } from "../components/BaseComponents";
import ReportsService, { Metric } from "../services/reports.service";
import LeadsService from "../services/leads.service";
import AppointmentsService from "../services/appointments.service";

const Dashboard: React.FC = () => {
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Busca os relatórios do dashboard
        const reportData = await ReportsService.getDashboardReports();
        
        // Busca métricas específicas para o dashboard
        const [leadsCount, appointmentsCount] = await Promise.all([
          LeadsService.getAllLeads().then(leads => leads.length),
          AppointmentsService.getTodayAppointmentsCount(),
        ]);

        // Mapeia as métricas para o formato do dashboard
        const dashboardMetrics: Metric[] = [
          { title: "Clientes Ativos", value: leadsCount.toString(), color: "text-[#667eea]" },
          { title: "Conversões", value: reportData.metrics.find(m => m.title === "Taxa de Conversão Geral")?.value || "N/A", color: "text-[#667eea]" },
          { title: "Atendimentos (Hoje)", value: appointmentsCount.toString(), color: "text-[#667eea]" },
        ];

        setMetrics(dashboardMetrics);
      } catch (err) {
        setError("Falha ao carregar dados do Dashboard. Verifique a conexão com o backend.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) {
    return (
      <Layout>
        <section className="pt-20 pb-32 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-6">Carregando Dashboard...</h1>
        </section>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <section className="pt-20 pb-32 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-6 text-red-600">Erro ao Carregar</h1>
          <p className="text-lg text-red-500">{error}</p>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      <section className="pt-20 pb-32 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold mb-6 text-center">Painel de Controle Elevare</h1>
        <p className="text-center text-gray-600 mb-10">Visão completa da sua clínica: clientes, agendamentos e métricas em tempo real.</p>
        
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {metrics.map((metric, index) => (
            <div key={index} className="bg-white p-6 rounded-2xl shadow-sm text-center hover:shadow-lg transition">
              {metric.title === "Clientes Ativos" && <Users className="w-10 h-10 text-[#667eea] mx-auto mb-4"/>}
              {metric.title === "Conversões" && <BarChart3 className="w-10 h-10 text-[#667eea] mx-auto mb-4"/>}
              {metric.title === "Atendimentos (Hoje)" && <Smartphone className="w-10 h-10 text-[#667eea] mx-auto mb-4"/>}
              <h3 className="font-bold text-lg mb-2">{metric.title}</h3>
              <p className="text-gray-600">
                {metric.title === "Clientes Ativos" && "Número de clientes cadastrados e engajados."}
                {metric.title === "Conversões" && "Taxa de conversão geral."}
                {metric.title === "Atendimentos (Hoje)" && "Total de atendimentos marcados para hoje."}
              </p>
              <div className="text-4xl font-extrabold text-brand-dark mt-4">{metric.value}</div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Button size="lg">Ver Relatórios Detalhados</Button>
        </div>
      </section>
    </Layout>
  );
};

export default Dashboard;

