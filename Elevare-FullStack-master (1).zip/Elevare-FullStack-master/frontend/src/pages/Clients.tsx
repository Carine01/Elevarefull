import React, { useState, useEffect } from "react";
import { Layout, Button, CheckCircle2 } from "../components/BaseComponents";
import LeadsService, { Lead } from "../services/leads.service";

const Clients: React.FC = () => {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchLeads = async () => {
      try {
        const data = await LeadsService.getAllLeads();
        setLeads(data);
      } catch (err) {
        setError("Falha ao carregar leads. Verifique a conexão com o backend.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchLeads();
  }, []);

  const getStatusColor = (category: Lead['category']) => {
    switch (category) {
      case 'quente':
        return 'text-red-500';
      case 'morno':
        return 'text-yellow-500';
      case 'frio':
        return 'text-blue-500';
      default:
        return 'text-gray-500';
    }
  };

  if (loading) {
    return (
      <Layout>
        <section className="pt-20 pb-32 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-6">Carregando Leads...</h1>
        </section>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <section className="pt-20 pb-32 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-6 text-red-600">Erro ao Carregar</h1>
          <p className="text-lg text-red-500">{error}</p>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      <section className="pt-20 pb-32 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold mb-6 text-center">Leads & Clientes</h1>
        <p className="text-lg text-gray-600 mb-10 text-center">
          Organize e acompanhe todos os contatos em um único lugar. Saiba quem está pronto para fechar, quem está apenas pesquisando e quem precisa de um lembrete.
        </p>

        <div className="space-y-6">
          {leads.map((lead) => (
            <div key={lead.id} className="flex items-center justify-between bg-white p-4 rounded-xl shadow-sm hover:shadow-lg transition">
              <div className="flex flex-col">
                <span className="font-medium text-gray-800">{lead.name}</span>
                <span className="text-sm text-gray-500">{lead.phone}</span>
              </div>
              <div className="flex items-center gap-4">
                <span className={`px-3 py-1 text-xs font-semibold rounded-full capitalize ${lead.category === 'quente' ? 'bg-red-100 text-red-800' : lead.category === 'morno' ? 'bg-yellow-100 text-yellow-800' : 'bg-blue-100 text-blue-800'}`}>
                  {lead.category}
                </span>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className={`w-5 h-5 ${getStatusColor(lead.category)}`} />
                  <span className="text-gray-600">Score: {lead.score}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button size="lg">Cadastrar Novo Cliente</Button>
        </div>
      </section>
    </Layout>
  );
};

export default Clients;
