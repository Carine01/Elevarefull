import AppRoutes from './Routes'


import './index.css'

function App() {


  return <AppRoutes />
}

export default App
