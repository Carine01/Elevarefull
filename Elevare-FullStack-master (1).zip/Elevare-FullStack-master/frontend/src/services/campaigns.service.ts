import api from './api';

export interface Campaign {
  id: number;
  name: string;
  status: 'Ativa' | 'Pausada' | 'Finalizada';
  leadsCount: number;
  conversionRate: string;
}

const CampaignsService = {
  getAllCampaigns: async (): Promise<Campaign[]> => {
    // O endpoint para listar campanhas é /campaigns
    const response = await api.get<Campaign[]>('/campaigns');
    return response.data;
  },

  getActiveCampaignsCount: async (): Promise<number> => {
    // O endpoint para contar campanhas ativas é /campaigns/active/count
    const response = await api.get<{ count: number }>('/campaigns/active/count');
    return response.data.count;
  },

  getAverageConversion: async (): Promise<string> => {
    // O endpoint para conversão média é /campaigns/conversion/average
    const response = await api.get<{ average: string }>('/campaigns/conversion/average');
    return response.data.average;
  },

  // Adicionar lógica para criar, atualizar e deletar campanhas conforme necessário
};

export default CampaignsService;
