import api from './api';

export interface Metric {
  title: string;
  value: string;
  color: string;
}

export interface FunnelStep {
  name: string;
  percentage: number;
  color: string;
}

export interface ReportData {
  metrics: Metric[];
  funnel: FunnelStep[];
}

const ReportsService = {
  getDashboardReports: async (): Promise<ReportData> => {
    // O endpoint para relatórios do dashboard é /reports/dashboard
    const response = await api.get<ReportData>('/reports/dashboard');
    return response.data;
  },

  // Adicionar lógica para relatórios detalhados conforme necessário
};

export default ReportsService;
