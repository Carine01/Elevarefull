import api from './api';

interface LoginPayload {
  email: string;
  password: string;
}

interface AuthResponse {
  accessToken: string;
  user: {
    id: number;
    email: string;
    name: string;
    clinicName: string;
  };
}

const AuthService = {
  login: async (payload: LoginPayload): Promise<AuthResponse> => {
    // O endpoint de login no backend é /auth/login
    const response = await api.post<AuthResponse>('/auth/login', payload);
    return response.data;
  },

  // Simulação de verificação de token (será usado no AuthContext)
  getProfile: async (): Promise<AuthResponse['user']> => {
    // O endpoint de perfil no backend é /auth/profile
    const response = await api.get<AuthResponse['user']>('/auth/profile');
    return response.data;
  },

  logout: () => {
    localStorage.removeItem('elevare_token');
    // Em um cenário real, pode haver uma chamada para invalidar o token no servidor
  },
};

export default AuthService;
