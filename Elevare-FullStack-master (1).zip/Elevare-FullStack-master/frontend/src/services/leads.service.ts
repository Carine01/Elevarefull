import api from './api';

export interface Lead {
  id: number;
  name: string;
  email: string;
  phone: string;
  score: number;
  category: 'quente' | 'morno' | 'frio';
  tags: string[];
  createdAt: string;
}

const LeadsService = {
  getAllLeads: async (): Promise<Lead[]> => {
    // O endpoint para listar leads é /leads
    const response = await api.get<Lead[]>('/leads');
    return response.data;
  },

  getLeadById: async (id: number): Promise<Lead> => {
    // O endpoint para buscar um lead é /leads/:id
    const response = await api.get<Lead>(`/leads/${id}`);
    return response.data;
  },

  // Adicionar lógica para criar, atualizar e deletar leads conforme necessário
};

export default LeadsService;
