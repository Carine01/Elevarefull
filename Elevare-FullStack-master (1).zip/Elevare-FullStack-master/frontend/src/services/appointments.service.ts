import api from './api';

export interface Appointment {
  id: number;
  leadName: string;
  date: string;
  time: string;
  status: 'Confirmado' | 'Pendente' | 'Cancelado' | 'No-Show';
  isSmartSlot: boolean;
}

export interface SmartSlot {
  time: string;
  reason: string;
}

const AppointmentsService = {
  getAllAppointments: async (): Promise<Appointment[]> => {
    // O endpoint para listar agendamentos é /appointments
    const response = await api.get<Appointment[]>('/appointments');
    return response.data;
  },

  getTodayAppointmentsCount: async (): Promise<number> => {
    // O endpoint para contar agendamentos de hoje é /appointments/today/count
    const response = await api.get<{ count: number }>('/appointments/today/count');
    return response.data.count;
  },

  getSmartSlotSuggestion: async (): Promise<SmartSlot> => {
    // O endpoint para sugestão de horário inteligente é /appointments/smart-slot
    const response = await api.get<SmartSlot>('/appointments/smart-slot');
    return response.data;
  },

  // Adicionar lógica para criar, atualizar e deletar agendamentos conforme necessário
};

export default AppointmentsService;
