import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "./context/AuthContext";

// Páginas
import Home from "./pages/Home";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Clients from "./pages/Clients";
import Appointments from "./pages/Appointments";
import Campaigns from "./pages/Campaigns";
import Reports from "./pages/Reports";
// Outras páginas serão adicionadas aqui: Leads, Agendamentos, Campanhas, etc.

const AppRoutes: React.FC = () => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    // Tela de carregamento enquanto verifica o token
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-xl font-bold text-brand-primary">Carregando Elevare...</div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        {/* Rota Pública (Landing Page) */}
        <Route path="/" element={<Home />} />
        


        {/* Rotas Protegidas (CRM) */}
        <Route
          path="/dashboard"
          element={isAuthenticated ? <Dashboard /> : <Navigate to="/login" replace />}
        />
        <Route
          path="/leads"
          element={isAuthenticated ? <Clients /> : <Navigate to="/login" replace />}
        />
        <Route
          path="/agendamentos"
          element={isAuthenticated ? <Appointments /> : <Navigate to="/login" replace />}
        />
        <Route
          path="/campanhas"
          element={isAuthenticated ? <Campaigns /> : <Navigate to="/login" replace />}
        />
        <Route
          path="/relatorios"
          element={isAuthenticated ? <Reports /> : <Navigate to="/login" replace />}
        />
        {/* Adicionar outras rotas protegidas aqui */}
        
        {/* Redirecionar usuário logado para o dashboard se tentar acessar o login */}
        <Route
          path="/login"
          element={isAuthenticated ? <Navigate to="/dashboard" replace /> : <Login />}
        />

        {/* Redirecionar qualquer rota desconhecida para a Landing Page */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
};

export default AppRoutes;
