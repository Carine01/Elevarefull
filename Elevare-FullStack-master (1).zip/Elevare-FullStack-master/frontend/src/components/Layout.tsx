import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  // O HTML da navegação e do footer será migrado para cá
  return (
    <div className="font-main bg-gray-50 text-gray-900 antialiased">
      {/* Navigation (Migrar do index.html) */}
      <nav className="fixed top-0 w-full z-50 glass-effect border-b border-gray-100 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <div className="flex items-center gap-3 group cursor-pointer">
              <img src="/images/elevare_logo_opt.png" alt="Elevare Logo" className="w-12 h-12 transition-transform group-hover:scale-110" width="48" height="48" />
              <div className="flex flex-col">
                <span className="font-extrabold text-2xl tracking-tight text-brand-dark leading-none">Elevare</span>
                <span className="text-xs font-bold text-brand-primary tracking-wider uppercase mt-1">Estética Estratégica</span>
              </div>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-8">
              <a href="#beneficios" className="text-sm font-medium text-gray-500 hover:text-brand-primary transition-colors">
                Benefícios
              </a>
              <a href="#planos" className="text-sm font-medium text-gray-500 hover:text-brand-primary transition-colors">
                Planos
              </a>
              <button className="bg-brand-gradient text-white px-6 py-2.5 rounded-full font-medium shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all duration-300">
                Começar Grátis
              </button>
            </div>

            {/* Mobile Toggle */}
            <div className="md:hidden">
              <button id="mobile-menu-toggle" className="p-2 text-gray-600">
                {/* Ícone Lucide Menu */}
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-menu w-6 h-6"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu (Lógica de estado será adicionada depois) */}
        <div id="mobile-menu" className="hidden md:hidden bg-white border-b border-gray-100 p-4 space-y-4 shadow-lg">
          <a href="#beneficios" className="block text-base font-medium text-gray-600 py-2">Benefícios</a>
          <a href="#planos" className="block text-base font-medium text-gray-600 py-2">Planos</a>
          <button className="w-full bg-brand-gradient text-white py-2.5 rounded-full font-medium">
            Começar Grátis
          </button>
        </div>
      </nav>

      <main>{children}</main>

      {/* Footer (Migrar do index.html) */}
      <footer className="bg-brand-dark text-white py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-1">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-8 h-8 rounded-lg bg-brand-gradient flex items-center justify-center font-bold text-lg">E</div>
                <span className="font-bold text-xl tracking-tight">Elevare</span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                Automação inteligente para esteticistas que querem crescer sem perder a essência.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-6 text-white text-sm uppercase tracking-wider">Produto</h4>
              <ul className="space-y-3 text-sm text-gray-400">
                <li><a href="#" className="hover:text-brand-lavender transition">Recursos</a></li>
                <li><a href="#" className="hover:text-brand-lavender transition">Preços</a></li>
                <li><a href="#" className="hover:text-brand-lavender transition">Segurança</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-6 text-white text-sm uppercase tracking-wider">Empresa</h4>
              <ul className="space-y-3 text-sm text-gray-400">
                <li><a href="#" className="hover:text-brand-lavender transition">Sobre</a></li>
                <li><a href="#" className="hover:text-brand-lavender transition">Blog</a></li>
                <li><a href="#" className="hover:text-brand-lavender transition">Contato</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-6 text-white text-sm uppercase tracking-wider">Legal</h4>
              <ul className="space-y-3 text-sm text-gray-400">
                <li><a href="#" className="hover:text-brand-lavender transition">Privacidade</a></li>
                <li><a href="#" className="hover:text-brand-lavender transition">Termos</a></li>
                <li><a href="#" className="hover:text-brand-lavender transition">LGPD</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-500 text-sm">
            <p>© 2024 Elevare. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
