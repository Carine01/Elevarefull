import React, { HTMLAttributes } from "react";
import { ArrowRight, CheckCircle2, Zap, BarChart3, Users, Shield, Smartphone, Menu, Calendar } from "lucide-react";

// --- Estilos Globais e Fontes ---
// No projeto Vite/Tailwind, isso é gerenciado pelo index.css e tailwind.config.js
// Mantemos as definições de cores no tailwind.config.js e index.css

// --- Botão Padronizado ---
interface ButtonProps extends HTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "outline" | "ghost";
  size?: "default" | "sm" | "lg";
  children: React.ReactNode;
  className?: string;
  type?: "button" | "submit" | "reset";
  disabled?: boolean;
}

const Button: React.FC<ButtonProps> = ({ className, variant = "default", size = "default", children, ...props }) => {
  const baseStyles = "inline-flex items-center justify-center rounded-lg font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#667eea] disabled:pointer-events-none disabled:opacity-50";
  const variants = {
    default: "bg-brand-gradient text-white shadow-md hover:shadow-lg hover:opacity-90 transform active:scale-[0.98]",
    outline: "border-2 border-[#C7D2FF] bg-transparent text-[#667eea] hover:bg-[#f9fafb] hover:border-[#667eea]",
    ghost: "hover:bg-[#dff7ef] hover:text-[#667eea]"
  };
  const sizes = {
    default: "h-10 px-6 py-2 text-sm",
    sm: "h-9 rounded-md px-3 text-xs",
    lg: "h-14 rounded-xl px-8 text-lg"
  };
  return (
    <button className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className || ""}`} {...props}>
      {children}
    </button>
  );
};

// --- Layout Base (Header + Footer) ---
interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => (
  <div className="min-h-screen bg-[#f9fafb] text-[#1f2937]">
    {/* Header */}
    <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur-lg border-b border-gray-200 px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg brand-gradient flex items-center justify-center text-white font-bold text-lg shadow-sm">E</div>
        <span className="font-bold text-lg text-[#1f2937]">Elevare</span>
      </div>
      {/* Menu de navegação para o CRM (será substituído pelo React Router) */}
      <Menu className="w-6 h-6 text-gray-600 cursor-pointer" />
    </nav>
    {/* Conteúdo Principal */}
    <main>{children}</main>
    {/* Footer */}
    <footer className="bg-[#1f2937] text-white py-16 px-4 sm:px-6 lg:px-8 text-center text-gray-400">
      <p>© 2024 Elevare. Todos os direitos reservados.</p>
    </footer>
  </div>
);

export { Button, Layout, ArrowRight, CheckCircle2, Zap, BarChart3, Users, Shield, Smartphone, Calendar };
