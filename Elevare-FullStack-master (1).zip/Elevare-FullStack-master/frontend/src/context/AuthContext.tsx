import React, { createContext, useState, useEffect, useContext, ReactNode } from 'react';
import AuthService from '../services/auth.service';
import api from '../services/api';

interface User {
  id: number;
  email: string;
  name: string;
  clinicName: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  login: (token: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const loadUser = async () => {
    const token = localStorage.getItem('elevare_token');
    if (token) {
      try {
        // Tenta buscar o perfil para validar o token
        const profile = await AuthService.getProfile();
        setUser(profile);
      } catch (error) {
        console.error("Token inválido ou expirado:", error);
        localStorage.removeItem('elevare_token');
        setUser(null);
      }
    }
    setLoading(false);
  };

  useEffect(() => {
    loadUser();
  }, []);

  const login = (token: string) => {
    localStorage.setItem('elevare_token', token);
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    loadUser();
  };

  const logout = () => {
    AuthService.logout();
    setUser(null);
    delete api.defaults.headers.common['Authorization'];
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
