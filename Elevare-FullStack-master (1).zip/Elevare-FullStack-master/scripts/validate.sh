#!/bin/bash

# ✅ ELEVARE - SCRIPT DE VALIDAÇÃO PÓS-DEPLOY
# Versão: 1.0
# Data: 28/11/2025

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Funções
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Solicitar URL
read -p "URL para validar (ex: https://elevare-landing.vercel.app): " URL

if [ -z "$URL" ]; then
    print_error "URL não fornecida"
    exit 1
fi

print_header "VALIDAÇÃO PÓS-DEPLOY"
print_info "URL: $URL"

# Contador de testes
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0

# 1. Verificar se site está online
print_info "1. Verificando se site está online..."
TOTAL_TESTS=$((TOTAL_TESTS + 1))
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$URL")
if [ "$HTTP_CODE" = "200" ]; then
    print_success "Site online (HTTP $HTTP_CODE)"
    PASSED_TESTS=$((PASSED_TESTS + 1))
else
    print_error "Site offline ou erro (HTTP $HTTP_CODE)"
    FAILED_TESTS=$((FAILED_TESTS + 1))
fi

# 2. Verificar HTTPS
print_info "2. Verificando HTTPS..."
TOTAL_TESTS=$((TOTAL_TESTS + 1))
if [[ $URL == https://* ]]; then
    print_success "HTTPS habilitado"
    PASSED_TESTS=$((PASSED_TESTS + 1))
else
    print_warning "HTTPS não habilitado"
    FAILED_TESTS=$((FAILED_TESTS + 1))
fi

# 3. Verificar tempo de resposta
print_info "3. Verificando tempo de resposta..."
TOTAL_TESTS=$((TOTAL_TESTS + 1))
RESPONSE_TIME=$(curl -s -o /dev/null -w "%{time_total}" "$URL")
RESPONSE_TIME_MS=$(echo "$RESPONSE_TIME * 1000" | bc)
if (( $(echo "$RESPONSE_TIME < 3" | bc -l) )); then
    print_success "Tempo de resposta: ${RESPONSE_TIME_MS}ms (< 3s)"
    PASSED_TESTS=$((PASSED_TESTS + 1))
else
    print_warning "Tempo de resposta lento: ${RESPONSE_TIME_MS}ms (> 3s)"
    FAILED_TESTS=$((FAILED_TESTS + 1))
fi

# 4. Verificar Content-Type
print_info "4. Verificando Content-Type..."
TOTAL_TESTS=$((TOTAL_TESTS + 1))
CONTENT_TYPE=$(curl -s -I "$URL" | grep -i "content-type" | cut -d' ' -f2)
if [[ $CONTENT_TYPE == *"text/html"* ]]; then
    print_success "Content-Type correto: $CONTENT_TYPE"
    PASSED_TESTS=$((PASSED_TESTS + 1))
else
    print_error "Content-Type incorreto: $CONTENT_TYPE"
    FAILED_TESTS=$((FAILED_TESTS + 1))
fi

# 5. Verificar headers de segurança
print_info "5. Verificando headers de segurança..."

# X-Content-Type-Options
TOTAL_TESTS=$((TOTAL_TESTS + 1))
if curl -s -I "$URL" | grep -i "x-content-type-options" > /dev/null; then
    print_success "X-Content-Type-Options presente"
    PASSED_TESTS=$((PASSED_TESTS + 1))
else
    print_warning "X-Content-Type-Options ausente"
    FAILED_TESTS=$((FAILED_TESTS + 1))
fi

# X-Frame-Options
TOTAL_TESTS=$((TOTAL_TESTS + 1))
if curl -s -I "$URL" | grep -i "x-frame-options" > /dev/null; then
    print_success "X-Frame-Options presente"
    PASSED_TESTS=$((PASSED_TESTS + 1))
else
    print_warning "X-Frame-Options ausente"
    FAILED_TESTS=$((FAILED_TESTS + 1))
fi

# 6. Verificar tamanho da página
print_info "6. Verificando tamanho da página..."
TOTAL_TESTS=$((TOTAL_TESTS + 1))
PAGE_SIZE=$(curl -s "$URL" | wc -c)
PAGE_SIZE_KB=$((PAGE_SIZE / 1024))
if [ $PAGE_SIZE_KB -lt 500 ]; then
    print_success "Tamanho da página: ${PAGE_SIZE_KB}KB (< 500KB)"
    PASSED_TESTS=$((PASSED_TESTS + 1))
else
    print_warning "Página grande: ${PAGE_SIZE_KB}KB (> 500KB)"
    FAILED_TESTS=$((FAILED_TESTS + 1))
fi

# 7. Verificar se JavaScript está carregando
print_info "7. Verificando se JavaScript está presente..."
TOTAL_TESTS=$((TOTAL_TESTS + 1))
if curl -s "$URL" | grep -q "<script"; then
    print_success "Tags <script> encontradas"
    PASSED_TESTS=$((PASSED_TESTS + 1))
else
    print_error "Nenhuma tag <script> encontrada"
    FAILED_TESTS=$((FAILED_TESTS + 1))
fi

# 8. Verificar se CSS está carregando
print_info "8. Verificando se CSS está presente..."
TOTAL_TESTS=$((TOTAL_TESTS + 1))
if curl -s "$URL" | grep -q -E "<link.*stylesheet|<style"; then
    print_success "CSS encontrado"
    PASSED_TESTS=$((PASSED_TESTS + 1))
else
    print_error "CSS não encontrado"
    FAILED_TESTS=$((FAILED_TESTS + 1))
fi

# 9. Verificar meta tags
print_info "9. Verificando meta tags..."

# Viewport
TOTAL_TESTS=$((TOTAL_TESTS + 1))
if curl -s "$URL" | grep -q "viewport"; then
    print_success "Meta viewport presente"
    PASSED_TESTS=$((PASSED_TESTS + 1))
else
    print_warning "Meta viewport ausente"
    FAILED_TESTS=$((FAILED_TESTS + 1))
fi

# Description
TOTAL_TESTS=$((TOTAL_TESTS + 1))
if curl -s "$URL" | grep -q "description"; then
    print_success "Meta description presente"
    PASSED_TESTS=$((PASSED_TESTS + 1))
else
    print_warning "Meta description ausente"
    FAILED_TESTS=$((FAILED_TESTS + 1))
fi

# 10. Verificar API Supabase (se configurada)
print_info "10. Verificando integração Supabase..."
TOTAL_TESTS=$((TOTAL_TESTS + 1))
if curl -s "$URL" | grep -q "supabase"; then
    print_success "Referência ao Supabase encontrada"
    PASSED_TESTS=$((PASSED_TESTS + 1))
else
    print_warning "Referência ao Supabase não encontrada"
    FAILED_TESTS=$((FAILED_TESTS + 1))
fi

# Resumo final
print_header "RESUMO DA VALIDAÇÃO"
echo -e "${BLUE}Total de testes:${NC} $TOTAL_TESTS"
echo -e "${GREEN}Testes passados:${NC} $PASSED_TESTS"
echo -e "${RED}Testes falhados:${NC} $FAILED_TESTS"

# Calcular porcentagem
PASS_RATE=$((PASSED_TESTS * 100 / TOTAL_TESTS))
echo -e "${BLUE}Taxa de sucesso:${NC} ${PASS_RATE}%"

# Resultado final
if [ $PASS_RATE -ge 90 ]; then
    print_success "VALIDAÇÃO APROVADA (≥ 90%)"
    exit 0
elif [ $PASS_RATE -ge 70 ]; then
    print_warning "VALIDAÇÃO PARCIAL (70-89%)"
    exit 0
else
    print_error "VALIDAÇÃO REPROVADA (< 70%)"
    exit 1
fi
