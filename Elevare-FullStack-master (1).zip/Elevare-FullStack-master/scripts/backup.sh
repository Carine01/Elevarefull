#!/bin/bash

###############################################################################
# Script de Backup Automático - PostgreSQL
#
# Realiza backup completo do banco de dados PostgreSQL e envia para S3/GCS.
#
# Uso:
#   ./scripts/backup.sh
#
# Agendamento (cron):
#   0 3 * * * /path/to/scripts/backup.sh >> /var/log/backup.log 2>&1
#
# Variáveis de ambiente necessárias:
#   DATABASE_URL - URL de conexão do PostgreSQL
#   BACKUP_S3_BUCKET - Bucket S3 para armazenar backups (opcional)
#   BACKUP_RETENTION_DAYS - Dias para manter backups (padrão: 30)
###############################################################################

set -e  # Parar em caso de erro
set -u  # Parar se variável não definida

# Configurações
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="${BACKUP_DIR:-/tmp/backups}"
BACKUP_FILE="elevare_backup_${TIMESTAMP}.sql"
BACKUP_PATH="${BACKUP_DIR}/${BACKUP_FILE}"
RETENTION_DAYS="${BACKUP_RETENTION_DAYS:-30}"

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Funções auxiliares
log_info() {
    echo -e "${GREEN}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1" >&2
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

# Verificar se DATABASE_URL está definida
if [ -z "${DATABASE_URL:-}" ]; then
    log_error "DATABASE_URL não está definida"
    exit 1
fi

# Criar diretório de backup se não existir
mkdir -p "${BACKUP_DIR}"

log_info "Iniciando backup do banco de dados..."
log_info "Arquivo: ${BACKUP_FILE}"

# Realizar backup
if pg_dump "${DATABASE_URL}" > "${BACKUP_PATH}"; then
    log_info "Backup criado com sucesso: ${BACKUP_PATH}"
    
    # Comprimir backup
    log_info "Comprimindo backup..."
    gzip "${BACKUP_PATH}"
    BACKUP_PATH="${BACKUP_PATH}.gz"
    
    # Tamanho do backup
    BACKUP_SIZE=$(du -h "${BACKUP_PATH}" | cut -f1)
    log_info "Tamanho do backup: ${BACKUP_SIZE}"
    
else
    log_error "Falha ao criar backup"
    exit 1
fi

# Enviar para S3 (se configurado)
if [ -n "${BACKUP_S3_BUCKET:-}" ]; then
    log_info "Enviando backup para S3: ${BACKUP_S3_BUCKET}"
    
    if command -v aws &> /dev/null; then
        if aws s3 cp "${BACKUP_PATH}" "s3://${BACKUP_S3_BUCKET}/backups/$(basename ${BACKUP_PATH})"; then
            log_info "Backup enviado para S3 com sucesso"
        else
            log_error "Falha ao enviar backup para S3"
        fi
    else
        log_warn "AWS CLI não instalado. Pulando upload para S3."
    fi
fi

# Enviar para Google Cloud Storage (se configurado)
if [ -n "${BACKUP_GCS_BUCKET:-}" ]; then
    log_info "Enviando backup para GCS: ${BACKUP_GCS_BUCKET}"
    
    if command -v gsutil &> /dev/null; then
        if gsutil cp "${BACKUP_PATH}" "gs://${BACKUP_GCS_BUCKET}/backups/$(basename ${BACKUP_PATH})"; then
            log_info "Backup enviado para GCS com sucesso"
        else
            log_error "Falha ao enviar backup para GCS"
        fi
    else
        log_warn "gsutil não instalado. Pulando upload para GCS."
    fi
fi

# Limpar backups antigos locais
log_info "Limpando backups antigos (>${RETENTION_DAYS} dias)..."
find "${BACKUP_DIR}" -name "elevare_backup_*.sql.gz" -type f -mtime +${RETENTION_DAYS} -delete
log_info "Backups antigos removidos"

# Limpar backups antigos no S3 (se configurado)
if [ -n "${BACKUP_S3_BUCKET:-}" ] && command -v aws &> /dev/null; then
    log_info "Limpando backups antigos no S3..."
    
    # Listar e deletar backups antigos
    CUTOFF_DATE=$(date -d "${RETENTION_DAYS} days ago" +%Y%m%d)
    
    aws s3 ls "s3://${BACKUP_S3_BUCKET}/backups/" | while read -r line; do
        FILE_DATE=$(echo $line | awk '{print $4}' | grep -oP 'elevare_backup_\K[0-9]{8}' || true)
        
        if [ -n "$FILE_DATE" ] && [ "$FILE_DATE" -lt "$CUTOFF_DATE" ]; then
            FILE_NAME=$(echo $line | awk '{print $4}')
            log_info "Removendo backup antigo do S3: ${FILE_NAME}"
            aws s3 rm "s3://${BACKUP_S3_BUCKET}/backups/${FILE_NAME}"
        fi
    done
fi

# Verificar integridade do backup
log_info "Verificando integridade do backup..."
if gunzip -t "${BACKUP_PATH}"; then
    log_info "Backup íntegro e válido"
else
    log_error "Backup corrompido!"
    exit 1
fi

# Notificação (webhook)
if [ -n "${BACKUP_WEBHOOK_URL:-}" ]; then
    log_info "Enviando notificação..."
    
    curl -X POST "${BACKUP_WEBHOOK_URL}" \
        -H "Content-Type: application/json" \
        -d "{
            \"text\": \"✅ Backup concluído com sucesso\",
            \"backup_file\": \"${BACKUP_FILE}\",
            \"backup_size\": \"${BACKUP_SIZE}\",
            \"timestamp\": \"${TIMESTAMP}\"
        }" || log_warn "Falha ao enviar notificação"
fi

log_info "Backup concluído com sucesso!"
log_info "Arquivo: ${BACKUP_PATH}"
log_info "Tamanho: ${BACKUP_SIZE}"

exit 0
