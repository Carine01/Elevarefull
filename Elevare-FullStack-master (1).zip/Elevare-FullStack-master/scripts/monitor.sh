#!/bin/bash

###############################################################################
# Script de Monitoring Básico
#
# Monitora health check da aplicação e envia alertas em caso de falha.
#
# Uso:
#   ./scripts/monitor.sh https://api.elevare.com
#
# Agendamento (cron - a cada 5 minutos):
#   */5 * * * * /path/to/scripts/monitor.sh https://api.elevare.com >> /var/log/monitor.log 2>&1
#
# Variáveis de ambiente opcionais:
#   MONITOR_WEBHOOK_URL - URL para enviar alertas (Slack, Discord, etc.)
#   MONITOR_EMAIL - Email para enviar alertas
#   MONITOR_TIMEOUT - Timeout em segundos (padrão: 10)
###############################################################################

set -e
set -u

# Configurações
API_URL="${1:-http://localhost:3000}"
HEALTH_ENDPOINT="${API_URL}/health"
TIMEOUT="${MONITOR_TIMEOUT:-10}"
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Funções auxiliares
log_info() {
    echo -e "${GREEN}[INFO]${NC} ${TIMESTAMP} - $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} ${TIMESTAMP} - $1" >&2
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} ${TIMESTAMP} - $1"
}

send_alert() {
    local title="$1"
    local message="$2"
    local severity="${3:-error}"  # info, warning, error
    
    # Webhook (Slack, Discord, etc.)
    if [ -n "${MONITOR_WEBHOOK_URL:-}" ]; then
        local emoji="⚠️"
        [ "$severity" = "error" ] && emoji="🔴"
        [ "$severity" = "info" ] && emoji="✅"
        
        curl -X POST "${MONITOR_WEBHOOK_URL}" \
            -H "Content-Type: application/json" \
            -d "{
                \"text\": \"${emoji} ${title}\",
                \"attachments\": [{
                    \"color\": \"$([ "$severity" = "error" ] && echo "danger" || echo "warning")\",
                    \"text\": \"${message}\",
                    \"footer\": \"Elevare Monitor\",
                    \"ts\": $(date +%s)
                }]
            }" \
            --silent --output /dev/null || log_warn "Falha ao enviar webhook"
    fi
    
    # Email (se configurado)
    if [ -n "${MONITOR_EMAIL:-}" ] && command -v mail &> /dev/null; then
        echo "${message}" | mail -s "[Elevare] ${title}" "${MONITOR_EMAIL}" || log_warn "Falha ao enviar email"
    fi
}

# Verificar se curl está instalado
if ! command -v curl &> /dev/null; then
    log_error "curl não está instalado"
    exit 1
fi

log_info "Verificando health check: ${HEALTH_ENDPOINT}"

# Fazer requisição HTTP
HTTP_CODE=$(curl -s -o /tmp/health_response.json -w "%{http_code}" --max-time ${TIMEOUT} "${HEALTH_ENDPOINT}" || echo "000")

if [ "$HTTP_CODE" = "200" ]; then
    # Parsear resposta JSON
    if command -v jq &> /dev/null; then
        STATUS=$(jq -r '.status' /tmp/health_response.json 2>/dev/null || echo "unknown")
        UPTIME=$(jq -r '.uptime' /tmp/health_response.json 2>/dev/null || echo "unknown")
        RESPONSE_TIME=$(jq -r '.responseTime' /tmp/health_response.json 2>/dev/null || echo "unknown")
        
        log_info "✅ Aplicação saudável"
        log_info "Status: ${STATUS}"
        log_info "Uptime: ${UPTIME}s"
        log_info "Response Time: ${RESPONSE_TIME}"
        
        # Verificar se há warnings
        DATABASE_STATUS=$(jq -r '.checks.database.status' /tmp/health_response.json 2>/dev/null || echo "unknown")
        MEMORY_STATUS=$(jq -r '.checks.memory.status' /tmp/health_response.json 2>/dev/null || echo "unknown")
        
        if [ "$DATABASE_STATUS" = "error" ]; then
            log_warn "⚠️ Banco de dados com problemas"
            send_alert "Database Warning" "Banco de dados reportou erro no health check" "warning"
        fi
        
        if [ "$MEMORY_STATUS" = "warning" ]; then
            MEMORY_PERCENT=$(jq -r '.checks.memory.percentUsed' /tmp/health_response.json 2>/dev/null || echo "unknown")
            log_warn "⚠️ Uso de memória elevado: ${MEMORY_PERCENT}"
            send_alert "Memory Warning" "Uso de memória elevado: ${MEMORY_PERCENT}" "warning"
        fi
    else
        log_info "✅ Aplicação respondeu com HTTP 200"
        log_warn "jq não instalado - resposta JSON não parseada"
    fi
    
    exit 0
    
elif [ "$HTTP_CODE" = "503" ]; then
    log_error "❌ Aplicação não saudável (HTTP 503)"
    
    if command -v jq &> /dev/null; then
        ERROR_MSG=$(jq -r '.error // .message // "Unknown error"' /tmp/health_response.json 2>/dev/null || echo "Unknown error")
        log_error "Erro: ${ERROR_MSG}"
        send_alert "Application Unhealthy" "Aplicação retornou HTTP 503. Erro: ${ERROR_MSG}" "error"
    else
        send_alert "Application Unhealthy" "Aplicação retornou HTTP 503" "error"
    fi
    
    exit 1
    
elif [ "$HTTP_CODE" = "000" ]; then
    log_error "❌ Timeout ou falha de conexão"
    send_alert "Connection Failed" "Não foi possível conectar à aplicação (timeout ${TIMEOUT}s)" "error"
    exit 1
    
else
    log_error "❌ HTTP ${HTTP_CODE} - Código inesperado"
    send_alert "Unexpected HTTP Code" "Aplicação retornou HTTP ${HTTP_CODE}" "error"
    exit 1
fi

# Limpar arquivo temporário
rm -f /tmp/health_response.json
