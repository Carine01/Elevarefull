#!/bin/bash

# 🧪 ELEVARE - SCRIPT DE TESTES AUTOMATIZADOS
# Versão: 1.0
# Data: 28/11/2025

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Funções
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Verificar se está no diretório correto
if [ ! -f "package.json" ]; then
    print_error "package.json não encontrado. Execute este script de dentro de frontend-landing/"
    exit 1
fi

print_header "ELEVARE - TESTES AUTOMATIZADOS"

# Contador de resultados
TOTAL_SUITES=0
PASSED_SUITES=0
FAILED_SUITES=0

# 1. Testes Unitários (Jest)
print_info "1. Executando testes unitários (Jest)..."
TOTAL_SUITES=$((TOTAL_SUITES + 1))

if npm run test --if-present 2>&1 | tee /tmp/jest-output.log; then
    print_success "Testes unitários passaram"
    PASSED_SUITES=$((PASSED_SUITES + 1))
    
    # Extrair estatísticas
    if grep -q "Tests:" /tmp/jest-output.log; then
        grep "Tests:" /tmp/jest-output.log
    fi
else
    print_error "Testes unitários falharam"
    FAILED_SUITES=$((FAILED_SUITES + 1))
fi

# 2. Testes E2E (Playwright)
print_info "2. Executando testes E2E (Playwright)..."
TOTAL_SUITES=$((TOTAL_SUITES + 1))

if npm run test:e2e --if-present 2>&1 | tee /tmp/playwright-output.log; then
    print_success "Testes E2E passaram"
    PASSED_SUITES=$((PASSED_SUITES + 1))
    
    # Extrair estatísticas
    if grep -q "passed" /tmp/playwright-output.log; then
        grep "passed" /tmp/playwright-output.log | tail -1
    fi
else
    print_error "Testes E2E falharam"
    FAILED_SUITES=$((FAILED_SUITES + 1))
fi

# 3. Lint (ESLint)
print_info "3. Executando lint (ESLint)..."
TOTAL_SUITES=$((TOTAL_SUITES + 1))

if npm run lint --if-present 2>&1; then
    print_success "Lint passou"
    PASSED_SUITES=$((PASSED_SUITES + 1))
else
    print_warning "Lint falhou ou não configurado"
    FAILED_SUITES=$((FAILED_SUITES + 1))
fi

# 4. Type Check (TypeScript)
print_info "4. Executando type check (TypeScript)..."
TOTAL_SUITES=$((TOTAL_SUITES + 1))

if npm run type-check --if-present 2>&1; then
    print_success "Type check passou"
    PASSED_SUITES=$((PASSED_SUITES + 1))
else
    print_warning "Type check falhou ou não configurado"
    FAILED_SUITES=$((FAILED_SUITES + 1))
fi

# 5. Build Test
print_info "5. Testando build..."
TOTAL_SUITES=$((TOTAL_SUITES + 1))

if npm run build 2>&1 | tee /tmp/build-output.log; then
    print_success "Build passou"
    PASSED_SUITES=$((PASSED_SUITES + 1))
    
    # Verificar tamanho do build
    if [ -d "dist" ]; then
        BUILD_SIZE=$(du -sh dist/ | cut -f1)
        print_info "Tamanho do build: $BUILD_SIZE"
    fi
else
    print_error "Build falhou"
    FAILED_SUITES=$((FAILED_SUITES + 1))
fi

# Resumo final
print_header "RESUMO DOS TESTES"
echo -e "${BLUE}Total de suites:${NC} $TOTAL_SUITES"
echo -e "${GREEN}Suites passadas:${NC} $PASSED_SUITES"
echo -e "${RED}Suites falhadas:${NC} $FAILED_SUITES"

# Calcular porcentagem
PASS_RATE=$((PASSED_SUITES * 100 / TOTAL_SUITES))
echo -e "${BLUE}Taxa de sucesso:${NC} ${PASS_RATE}%"

# Resultado final
if [ $PASS_RATE -eq 100 ]; then
    print_success "TODOS OS TESTES PASSARAM! 🎉"
    exit 0
elif [ $PASS_RATE -ge 80 ]; then
    print_warning "TESTES PARCIALMENTE APROVADOS (≥ 80%)"
    exit 0
else
    print_error "TESTES REPROVADOS (< 80%)"
    exit 1
fi
