#!/bin/bash

# 🚀 ELEVARE - SCRIPT DE DEPLOY AUTOMATIZADO
# Versão: 1.0
# Data: 28/11/2025

set -e  # Exit on error

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funções auxiliares
print_header() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Verificar se está no diretório correto
if [ ! -f "package.json" ]; then
    print_error "package.json não encontrado. Execute este script de dentro de frontend-landing/"
    exit 1
fi

print_header "ELEVARE - DEPLOY AUTOMATIZADO"

# 1. Verificar dependências
print_info "Verificando dependências..."
if ! command -v node &> /dev/null; then
    print_error "Node.js não instalado"
    exit 1
fi
if ! command -v npm &> /dev/null; then
    print_error "npm não instalado"
    exit 1
fi
print_success "Node.js $(node --version) e npm $(npm --version) instalados"

# 2. Verificar variáveis de ambiente
print_info "Verificando variáveis de ambiente..."
if [ ! -f ".env" ]; then
    print_warning ".env não encontrado. Criando a partir de .env.example..."
    if [ -f ".env.example" ]; then
        cp .env.example .env
        print_warning "IMPORTANTE: Edite .env com suas credenciais antes de continuar!"
        read -p "Pressione Enter após editar .env..."
    else
        print_error ".env.example não encontrado"
        exit 1
    fi
fi
print_success "Arquivo .env encontrado"

# 3. Instalar dependências
print_info "Instalando dependências..."
npm install
print_success "Dependências instaladas"

# 4. Executar testes (opcional)
read -p "Executar testes antes do deploy? (s/N): " run_tests
if [[ $run_tests =~ ^[Ss]$ ]]; then
    print_info "Executando testes..."
    
    # Testes unitários (Jest)
    if npm run test --if-present 2>/dev/null; then
        print_success "Testes unitários passaram"
    else
        print_warning "Testes unitários falharam ou não configurados"
    fi
    
    # Testes E2E (Playwright)
    if npm run test:e2e --if-present 2>/dev/null; then
        print_success "Testes E2E passaram"
    else
        print_warning "Testes E2E falharam ou não configurados"
    fi
fi

# 5. Build
print_info "Executando build..."
npm run build
if [ ! -d "dist" ]; then
    print_error "Pasta dist/ não foi criada. Build falhou."
    exit 1
fi
print_success "Build concluído com sucesso"

# 6. Verificar tamanho do build
print_info "Tamanho do build:"
du -sh dist/
print_success "Build verificado"

# 7. Deploy para Vercel
read -p "Fazer deploy para Vercel? (s/N): " deploy_vercel
if [[ $deploy_vercel =~ ^[Ss]$ ]]; then
    print_info "Fazendo deploy para Vercel..."
    
    # Verificar se Vercel CLI está instalado
    if ! command -v vercel &> /dev/null; then
        print_warning "Vercel CLI não instalado. Instalando..."
        npm install -g vercel
    fi
    
    # Deploy
    read -p "Deploy para produção? (s/N): " deploy_prod
    if [[ $deploy_prod =~ ^[Ss]$ ]]; then
        vercel --prod
        print_success "Deploy para PRODUÇÃO concluído"
    else
        vercel
        print_success "Deploy para PREVIEW concluído"
    fi
else
    print_info "Deploy para Vercel pulado"
fi

# 8. Resumo final
print_header "DEPLOY CONCLUÍDO"
print_success "Build: dist/"
print_success "Tamanho: $(du -sh dist/ | cut -f1)"
if [[ $deploy_vercel =~ ^[Ss]$ ]]; then
    print_success "Deploy: Vercel"
fi

print_info "Próximos passos:"
echo "  1. Verificar URL de produção"
echo "  2. Testar funcionalidades críticas"
echo "  3. Monitorar logs por 24h"
echo "  4. Coletar feedbacks"

exit 0
