// Scripts de Migração - Google Sheets para PostgreSQL
// Ferramentas para migrar dados existentes do IARA

const { GoogleSpreadsheet } = require('google-spreadsheet');
const { Pool } = require('pg');
const fs = require('fs');

class IARAMigration {
  constructor(googleCredentials, dbConfig) {
    this.googleCredentials = googleCredentials;
    this.dbConfig = dbConfig;
    this.migrationLog = [];
  }
  
  async connectToDatabase(tenantId) {
    const pool = new Pool({
      ...this.dbConfig,
      database: `iara_${tenantId}`
    });
    return pool;
  }
  
  async connectToGoogleSheet(sheetId) {
    const doc = new GoogleSpreadsheet(sheetId);
    await doc.useServiceAccountAuth(this.googleCredentials);
    await doc.loadInfo();
    return doc;
  }
  
  async migrateTenant(tenantId, sheetId) {
    console.log(`Iniciando migração para tenant: ${tenantId}`);
    
    try {
      // Conectar ao banco do tenant
      const db = await this.connectToDatabase(tenantId);
      
      // Conectar à planilha Google
      const sheet = await this.connectToGoogleSheet(sheetId);
      
      // Migrar cada tipo de dado
      await this.migrateTemplates(sheet, db);
      await this.migrateLeads(sheet, db);
      await this.migrateEvents(sheet, db);
      await this.migrateMessages(sheet, db);
      
      // Gerar relatório de migração
      await this.generateMigrationReport(tenantId);
      
      console.log(`Migração concluída para tenant: ${tenantId}`);
      
    } catch (error) {
      console.error(`Erro na migração do tenant ${tenantId}:`, error);
      throw error;
    }
  }
  
  async migrateTemplates(sheet, db) {
    console.log('Migrando templates...');
    
    try {
      const templateSheet = sheet.sheetsByTitle['Templates'] || sheet.sheetsByTitle['Biblioteca Mestra'];
      if (!templateSheet) {
        console.log('Planilha de templates não encontrada');
        return;
      }
      
      const rows = await templateSheet.getRows();
      let migratedCount = 0;
      
      for (const row of rows) {
        try {
          // Mapear dados da planilha para o schema do banco
          const templateData = {
            id: this.generateUUID(),
            name: row['Nome'] || row['name'] || row['Nome do Template'],
            content: row['Conteúdo'] || row['content'] || row['Texto'],
            category: row['Categoria'] || row['category'] || 'Geral',
            variables: this.extractVariables(row['Conteúdo'] || row['content'] || row['Texto']),
            is_active: true,
            created_by: 'migration_user',
            created_at: new Date(),
            updated_at: new Date()
          };
          
          // Inserir no banco
          await db.query(
            `INSERT INTO iara.templates (id, name, content, category, variables, is_active, created_by, created_at, updated_at) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
            [
              templateData.id,
              templateData.name,
              templateData.content,
              templateData.category,
              JSON.stringify(templateData.variables),
              templateData.is_active,
              templateData.created_by,
              templateData.created_at,
              templateData.updated_at
            ]
          );
          
          migratedCount++;
          
        } catch (error) {
          console.error(`Erro ao migrar template ${row['Nome']}:`, error);
          this.migrationLog.push({
            type: 'template',
            id: row['Nome'],
            status: 'error',
            error: error.message
          });
        }
      }
      
      console.log(`${migratedCount} templates migrados`);
      this.migrationLog.push({
        type: 'templates',
        count: migratedCount,
        status: 'success'
      });
      
    } catch (error) {
      console.error('Erro ao migrar templates:', error);
      throw error;
    }
  }
  
  async migrateLeads(sheet, db) {
    console.log('Migrando leads...');
    
    try {
      const leadsSheet = sheet.sheetsByTitle['Leads'] || sheet.sheetsByTitle['Contatos'];
      if (!leadsSheet) {
        console.log('Planilha de leads não encontrada');
        return;
      }
      
      const rows = await leadsSheet.getRows();
      let migratedCount = 0;
      
      for (const row of rows) {
        try {
          const leadData = {
            id: this.generateUUID(),
            name: row['Nome'] || row['name'] || 'Lead sem nome',
            email: row['Email'] || row['email'],
            phone: this.normalizePhone(row['Telefone'] || row['phone'] || row['phone_number']),
            source: row['Origem'] || row['source'] || 'migration',
            utm_source: row['utm_source'],
            utm_medium: row['utm_medium'],
            utm_campaign: row['utm_campaign'],
            gclid: row['gclid'],
            fbclid: row['fbclid'],
            time_on_page: parseInt(row['time_on_page']) || 0,
            scroll_depth: parseInt(row['scroll_depth']) || 0,
            video_percent: parseInt(row['video_percent']) || 0,
            clicked_whatsapp: this.parseBoolean(row['clicked_whatsapp']),
            score: parseInt(row['score']) || 0,
            status: this.mapLeadStatus(row['status'] || row['Status']),
            stage: this.mapLeadStage(row['stage'] || row['Stage'], parseInt(row['score']) || 0),
            last_event: row['last_event'],
            created_at: this.parseDate(row['created_at']) || new Date(),
            updated_at: this.parseDate(row['updated_at']) || new Date()
          };
          
          await db.query(
            `INSERT INTO iara.leads (id, name, email, phone, source, utm_source, utm_medium, 
             utm_campaign, gclid, fbclid, time_on_page, scroll_depth, video_percent, 
             clicked_whatsapp, score, status, stage, last_event, created_at, updated_at) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20)`,
            [
              leadData.id,
              leadData.name,
              leadData.email,
              leadData.phone,
              leadData.source,
              leadData.utm_source,
              leadData.utm_medium,
              leadData.utm_campaign,
              leadData.gclid,
              leadData.fbclid,
              leadData.time_on_page,
              leadData.scroll_depth,
              leadData.video_percent,
              leadData.clicked_whatsapp,
              leadData.score,
              leadData.status,
              leadData.stage,
              leadData.last_event,
              leadData.created_at,
              leadData.updated_at
            ]
          );
          
          migratedCount++;
          
        } catch (error) {
          console.error(`Erro ao migrar lead ${row['Nome']}:`, error);
          this.migrationLog.push({
            type: 'lead',
            id: row['Nome'] || row['Email'],
            status: 'error',
            error: error.message
          });
        }
      }
      
      console.log(`${migratedCount} leads migrados`);
      this.migrationLog.push({
        type: 'leads',
        count: migratedCount,
        status: 'success'
      });
      
    } catch (error) {
      console.error('Erro ao migrar leads:', error);
      throw error;
    }
  }
  
  async migrateEvents(sheet, db) {
    console.log('Migrando eventos...');
    
    try {
      const eventsSheet = sheet.sheetsByTitle['Events'] || sheet.sheetsByTitle['Eventos'];
      if (!eventsSheet) {
        console.log('Planilha de eventos não encontrada');
        return;
      }
      
      const rows = await eventsSheet.getRows();
      let migratedCount = 0;
      
      for (const row of rows) {
        try {
          const eventData = {
            id: this.generateUUID(),
            lead_id: row['lead_id'] || row['Lead ID'],
            event_type: row['event_type'] || row['Tipo'] || row['type'],
            points: parseInt(row['points']) || 0,
            source: row['source'] || row['Origem'],
            metadata: this.parseMetadata(row['metadata'] || row['meta'] || '{}'),
            created_at: this.parseDate(row['ts'] || row['timestamp'] || row['created_at']) || new Date()
          };
          
          await db.query(
            `INSERT INTO iara.events (id, lead_id, event_type, points, source, metadata, created_at) 
             VALUES ($1, $2, $3, $4, $5, $6, $7)`,
            [
              eventData.id,
              eventData.lead_id,
              eventData.event_type,
              eventData.points,
              eventData.source,
              JSON.stringify(eventData.metadata),
              eventData.created_at
            ]
          );
          
          migratedCount++;
          
        } catch (error) {
          console.error(`Erro ao migrar evento:`, error);
          this.migrationLog.push({
            type: 'event',
            id: row['event_type'] || 'unknown',
            status: 'error',
            error: error.message
          });
        }
      }
      
      console.log(`${migratedCount} eventos migrados`);
      this.migrationLog.push({
        type: 'events',
        count: migratedCount,
        status: 'success'
      });
      
    } catch (error) {
      console.error('Erro ao migrar eventos:', error);
      throw error;
    }
  }
  
  async migrateMessages(sheet, db) {
    console.log('Migrando mensagens...');
    
    try {
      const messagesSheet = sheet.sheetsByTitle['Mensagens'] || sheet.sheetsByTitle['Messages'] || sheet.sheetsByTitle['Sent Messages'];
      if (!messagesSheet) {
        console.log('Planilha de mensagens não encontrada');
        return;
      }
      
      const rows = await messagesSheet.getRows();
      let migratedCount = 0;
      
      for (const row of rows) {
        try {
          const messageData = {
            id: this.generateUUID(),
            lead_id: row['lead_id'] || row['Lead ID'],
            template_id: row['template_id'] || row['Template ID'],
            message_content: row['message_content'] || row['content'] || row['Conteúdo'],
            channel: row['channel'] || row['Canal'] || 'whatsapp',
            status: this.mapMessageStatus(row['status'] || row['Status']),
            external_message_id: row['external_message_id'],
            error_message: row['error_message'],
            sent_at: this.parseDate(row['sent_at'] || row['sent_at']) || new Date(),
            delivered_at: this.parseDate(row['delivered_at'])
          };
          
          await db.query(
            `INSERT INTO iara.sent_messages (id, lead_id, template_id, message_content, channel, status, 
             external_message_id, error_message, sent_at, delivered_at) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
            [
              messageData.id,
              messageData.lead_id,
              messageData.template_id,
              messageData.message_content,
              messageData.channel,
              messageData.status,
              messageData.external_message_id,
              messageData.error_message,
              messageData.sent_at,
              messageData.delivered_at
            ]
          );
          
          migratedCount++;
          
        } catch (error) {
          console.error(`Erro ao migrar mensagem:`, error);
          this.migrationLog.push({
            type: 'message',
            id: row['id'] || 'unknown',
            status: 'error',
            error: error.message
          });
        }
      }
      
      console.log(`${migratedCount} mensagens migradas`);
      this.migrationLog.push({
        type: 'messages',
        count: migratedCount,
        status: 'success'
      });
      
    } catch (error) {
      console.error('Erro ao migrar mensagens:', error);
      throw error;
    }
  }
  
  // Funções auxiliares
  generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
  
  extractVariables(content) {
    if (!content) return [];
    
    const variableRegex = /\{\{(.*?)\}\}/g;
    const variables = [];
    let match;
    
    while ((match = variableRegex.exec(content)) !== null) {
      variables.push(match[1].trim());
    }
    
    return [...new Set(variables)]; // Remove duplicatas
  }
  
  normalizePhone(phone) {
    if (!phone) return null;
    
    // Remover todos os caracteres não numéricos
    return phone.replace(/\D/g, '');
  }
  
  parseBoolean(value) {
    if (typeof value === 'boolean') return value;
    if (typeof value === 'string') {
      return value.toLowerCase() === 'true' || value === '1';
    }
    return false;
  }
  
  parseDate(dateString) {
    if (!dateString) return null;
    
    const date = new Date(dateString);
    return isNaN(date.getTime()) ? null : date;
  }
  
  parseMetadata(metadataString) {
    try {
      return JSON.parse(metadataString);
    } catch {
      return {};
    }
  }
  
  mapLeadStatus(status) {
    const statusMap = {
      'novo': 'new',
      'novo': 'new',
      'contatado': 'contacted',
      'convertido': 'converted',
      'perdido': 'lost',
      'em_andamento': 'in_progress'
    };
    
    return statusMap[status?.toLowerCase()] || 'new';
  }
  
  mapLeadStage(stage, score) {
    if (stage) {
      const stageMap = {
        'frio': 'frio',
        'morno': 'morno',
        'quente': 'quente',
        'cold': 'frio',
        'warm': 'morno',
        'hot': 'quente'
      };
      
      const mappedStage = stageMap[stage.toLowerCase()];
      if (mappedStage) return mappedStage;
    }
    
    // Calcular stage baseado no score
    if (score <= 30) return 'frio';
    if (score <= 60) return 'morno';
    return 'quente';
  }
  
  mapMessageStatus(status) {
    const statusMap = {
      'enviado': 'sent',
      'entregue': 'delivered',
      'falhou': 'failed',
      'sent': 'sent',
      'delivered': 'delivered',
      'failed': 'failed'
    };
    
    return statusMap[status?.toLowerCase()] || 'sent';
  }
  
  async generateMigrationReport(tenantId) {
    const report = {
      tenantId,
      timestamp: new Date().toISOString(),
      log: this.migrationLog,
      summary: this.generateSummary()
    };
    
    const filename = `migration_report_${tenantId}_${Date.now()}.json`;
    fs.writeFileSync(filename, JSON.stringify(report, null, 2));
    
    console.log(`Relatório de migração salvo: ${filename}`);
  }
  
  generateSummary() {
    const summary = {
      total: 0,
      success: 0,
      errors: 0,
      byType: {}
    };
    
    for (const log of this.migrationLog) {
      if (!summary.byType[log.type]) {
        summary.byType[log.type] = { total: 0, success: 0, errors: 0 };
      }
      
      summary.byType[log.type].total += log.count || 1;
      summary.total += log.count || 1;
      
      if (log.status === 'success') {
        summary.byType[log.type].success += log.count || 1;
        summary.success += log.count || 1;
      } else {
        summary.byType[log.type].errors += 1;
        summary.errors += 1;
      }
    }
    
    return summary;
  }
}

// Script de execução
async function runMigration() {
  const credentials = require('./google-credentials.json');
  
  const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'password'
  };
  
  const migration = new IARAMigration(credentials, dbConfig);
  
  try {
    // Configuração de tenants para migrar
    const tenants = [
      { tenantId: 'tenant_001', sheetId: 'your-google-sheet-id-1' },
      { tenantId: 'tenant_002', sheetId: 'your-google-sheet-id-2' }
      // Adicionar mais tenants conforme necessário
    ];
    
    for (const tenant of tenants) {
      console.log(`Migrando tenant: ${tenant.tenantId}`);
      await migration.migrateTenant(tenant.tenantId, tenant.sheetId);
    }
    
    console.log('Migração concluída com sucesso!');
    
  } catch (error) {
    console.error('Erro durante a migração:', error);
    process.exit(1);
  }
}

// Executar se chamado diretamente
if (require.main === module) {
  runMigration();
}

module.exports = IARAMigration;