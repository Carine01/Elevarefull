-- Schema do Banco de Dados Multi-Tenant IARA
-- Este script deve ser executado para cada tenant

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- Schema principal
CREATE SCHEMA IF NOT EXISTS iara;
SET search_path TO iara, public;

-- Tabela de templates
CREATE TABLE IF NOT EXISTS templates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    category VARCHAR(100),
    variables JSONB DEFAULT '[]'::jsonb,
    is_active BOOLEAN DEFAULT true,
    created_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Índices para performance
    CONSTRAINT idx_template_category UNIQUE (name, category)
);

-- Tabela de leads
CREATE TABLE IF NOT EXISTS leads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(20),
    source VARCHAR(100),
    utm_source VARCHAR(100),
    utm_medium VARCHAR(100),
    utm_campaign VARCHAR(100),
    gclid VARCHAR(255),
    fbclid VARCHAR(255),
    time_on_page INTEGER DEFAULT 0,
    scroll_depth INTEGER DEFAULT 0,
    video_percent INTEGER DEFAULT 0,
    clicked_whatsapp BOOLEAN DEFAULT false,
    score INTEGER DEFAULT 0,
    status VARCHAR(50) DEFAULT 'new', -- new, contacted, converted, lost
    stage VARCHAR(20) DEFAULT 'frio', -- frio, morno, quente
    last_event VARCHAR(100),
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Índices para performance
    INDEX idx_leads_source (source),
    INDEX idx_leads_status (status),
    INDEX idx_leads_stage (stage),
    INDEX idx_leads_score (score),
    INDEX idx_leads_created_at (created_at),
    INDEX idx_leads_email (email),
    INDEX idx_leads_phone (phone)
);

-- Tabela de eventos
CREATE TABLE IF NOT EXISTS events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    event_type VARCHAR(100) NOT NULL, -- page_view, form_submit, whatsapp_click, etc
    points INTEGER DEFAULT 0,
    source VARCHAR(100),
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Índices para performance
    INDEX idx_events_lead_id (lead_id),
    INDEX idx_events_type (event_type),
    INDEX idx_events_created_at (created_at)
);

-- Tabela de mensagens enviadas
CREATE TABLE IF NOT EXISTS sent_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    template_id UUID REFERENCES templates(id),
    message_content TEXT NOT NULL,
    channel VARCHAR(50) NOT NULL, -- whatsapp, email, sms
    status VARCHAR(50) DEFAULT 'sent', -- sent, delivered, failed
    external_message_id VARCHAR(255),
    error_message TEXT,
    sent_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    delivered_at TIMESTAMP WITH TIME ZONE,
    
    -- Índices para performance
    INDEX idx_messages_lead_id (lead_id),
    INDEX idx_messages_template_id (template_id),
    INDEX idx_messages_status (status),
    INDEX idx_messages_sent_at (sent_at)
);

-- Tabela de campanhas
CREATE TABLE IF NOT EXISTS campaigns (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    template_id UUID REFERENCES templates(id),
    target_filter JSONB DEFAULT '{}'::jsonb, -- Filtro para segmentação
    status VARCHAR(50) DEFAULT 'draft', -- draft, active, paused, completed
    scheduled_for TIMESTAMP WITH TIME ZONE,
    sent_count INTEGER DEFAULT 0,
    created_by UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Índices para performance
    INDEX idx_campaigns_status (status),
    INDEX idx_campaigns_created_by (created_by)
);

-- Tabela de configurações do tenant
CREATE TABLE IF NOT EXISTS settings (
    key VARCHAR(100) PRIMARY KEY,
    value TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de usuários (se necessário para o tenant)
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'user', -- admin, manager, user
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers para atualizar updated_at
CREATE TRIGGER update_templates_updated_at BEFORE UPDATE ON templates 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_leads_updated_at BEFORE UPDATE ON leads 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_campaigns_updated_at BEFORE UPDATE ON campaigns 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Função para calcular score do lead automaticamente
CREATE OR REPLACE FUNCTION calculate_lead_score()
RETURNS TRIGGER AS $$
DECLARE
    total_score INTEGER := 0;
BEGIN
    -- Pontuação baseada em comportamento
    IF NEW.time_on_page >= 45 THEN
        total_score := total_score + 10;
    END IF;
    
    IF NEW.scroll_depth >= 70 THEN
        total_score := total_score + 10;
    END IF;
    
    IF NEW.video_percent >= 70 THEN
        total_score := total_score + 15;
    END IF;
    
    IF NEW.clicked_whatsapp THEN
        total_score := total_score + 20;
    END IF;
    
    -- Pontuação baseada em UTM
    IF NEW.gclid IS NOT NULL THEN
        total_score := total_score + 10;
    END IF;
    
    IF NEW.fbclid IS NOT NULL THEN
        total_score := total_score + 10;
    END IF;
    
    NEW.score := total_score;
    
    -- Atualizar stage baseado no score
    IF total_score <= 30 THEN
        NEW.stage := 'frio';
    ELSIF total_score <= 60 THEN
        NEW.stage := 'morno';
    ELSE
        NEW.stage := 'quente';
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para calcular score ao inserir/atualizar lead
CREATE TRIGGER calculate_lead_score_trigger
    BEFORE INSERT OR UPDATE ON leads
    FOR EACH ROW
    EXECUTE FUNCTION calculate_lead_score();

-- View para analytics básico
CREATE OR REPLACE VIEW lead_analytics AS
SELECT 
    DATE(created_at) as date,
    COUNT(*) as total_leads,
    COUNT(CASE WHEN status = 'converted' THEN 1 END) as converted_leads,
    COUNT(CASE WHEN stage = 'quente' THEN 1 END) as hot_leads,
    COUNT(CASE WHEN stage = 'morno' THEN 1 END) as warm_leads,
    COUNT(CASE WHEN stage = 'frio' THEN 1 END) as cold_leads,
    AVG(score) as avg_score,
    COUNT(CASE WHEN clicked_whatsapp THEN 1 END) as whatsapp_clicks
FROM leads 
WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY DATE(created_at)
ORDER BY date DESC;

-- View para performance de templates
CREATE OR REPLACE VIEW template_performance AS
SELECT 
    t.id,
    t.name,
    t.category,
    COUNT(sm.id) as total_sent,
    COUNT(CASE WHEN sm.status = 'delivered' THEN 1 END) as delivered,
    COUNT(CASE WHEN sm.status = 'failed' THEN 1 END) as failed,
    CASE 
        WHEN COUNT(sm.id) > 0 
        THEN ROUND(COUNT(CASE WHEN sm.status = 'delivered' THEN 1 END) * 100.0 / COUNT(sm.id), 2)
        ELSE 0 
    END as delivery_rate
FROM templates t
LEFT JOIN sent_messages sm ON t.id = sm.template_id
WHERE t.is_active = true
GROUP BY t.id, t.name, t.category
ORDER BY total_sent DESC;

-- Inserir configurações padrão
INSERT INTO settings (key, value, description) VALUES
('whatsapp_api_key', '', 'Chave da API WhatsApp Business'),
('meta_pixel_id', '', 'ID do Pixel Meta para tracking'),
('google_conversion_id', '', 'ID de conversão Google Ads'),
('default_from_name', 'IARA', 'Nome padrão para remetente'),
('max_daily_messages', '1000', 'Limite máximo de mensagens por dia'),
('auto_follow_up_hours', '24', 'Horas para follow-up automático'),
('score_threshold_hot', '61', 'Score mínimo para lead quente'),
('score_threshold_warm', '31', 'Score mínimo para lead morno')
ON CONFLICT (key) DO NOTHING;

-- Criar índices adicionais para performance
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_leads_composite 
ON leads(status, stage, created_at);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_events_composite 
ON events(lead_id, event_type, created_at);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_messages_composite 
ON sent_messages(lead_id, status, sent_at);

-- Permissões (ajustar conforme necessário)
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA iara TO iara_user;
-- GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA iara TO iara_user;