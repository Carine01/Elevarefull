/**
 * Health Check Endpoint
 * 
 * Endpoint HTTP que retorna status da aplicação.
 * Usado por monitoramento (UptimeRobot, Datadog, etc.) e orquestradores (Kubernetes, ECS).
 * 
 * Uso:
 * GET /health
 * 
 * Resposta:
 * {
 *   "status": "ok",
 *   "uptime": 12345,
 *   "timestamp": "2025-11-29T00:30:00.000Z",
 *   "version": "1.0.0",
 *   "environment": "production",
 *   "checks": {
 *     "database": "ok",
 *     "redis": "ok",
 *     "memory": "ok"
 *   }
 * }
 */

const express = require('express');
const router = express.Router();
const { Pool } = require('pg');

// Pool de conexão para health check (não usar pool principal)
let healthCheckPool;

/**
 * Inicializar pool de health check
 */
function initHealthCheckPool() {
  if (!healthCheckPool && process.env.DATABASE_URL) {
    healthCheckPool = new Pool({
      connectionString: process.env.DATABASE_URL,
      max: 1, // Apenas 1 conexão para health check
      idleTimeoutMillis: 10000,
      connectionTimeoutMillis: 5000
    });
  }
}

/**
 * Verificar status do banco de dados
 */
async function checkDatabase() {
  try {
    if (!healthCheckPool) {
      initHealthCheckPool();
    }
    
    if (!healthCheckPool) {
      return { status: 'unknown', message: 'DATABASE_URL not configured' };
    }

    const start = Date.now();
    const result = await healthCheckPool.query('SELECT 1');
    const duration = Date.now() - start;

    return {
      status: 'ok',
      responseTime: `${duration}ms`,
      connected: true
    };
  } catch (error) {
    return {
      status: 'error',
      message: error.message,
      connected: false
    };
  }
}

/**
 * Verificar uso de memória
 */
function checkMemory() {
  const used = process.memoryUsage();
  const heapUsedMB = Math.round(used.heapUsed / 1024 / 1024);
  const heapTotalMB = Math.round(used.heapTotal / 1024 / 1024);
  const percentUsed = Math.round((used.heapUsed / used.heapTotal) * 100);

  return {
    status: percentUsed > 90 ? 'warning' : 'ok',
    heapUsed: `${heapUsedMB}MB`,
    heapTotal: `${heapTotalMB}MB`,
    percentUsed: `${percentUsed}%`
  };
}

/**
 * Verificar status do Redis (se configurado)
 */
async function checkRedis() {
  // Placeholder - implementar se usar Redis
  if (!process.env.REDIS_URL) {
    return { status: 'not_configured' };
  }

  try {
    // const redis = require('redis');
    // const client = redis.createClient({ url: process.env.REDIS_URL });
    // await client.ping();
    // await client.quit();
    return { status: 'ok' };
  } catch (error) {
    return { status: 'error', message: error.message };
  }
}

/**
 * Endpoint GET /health
 */
router.get('/health', async (req, res) => {
  try {
    const startTime = Date.now();

    // Verificações paralelas
    const [databaseCheck, redisCheck] = await Promise.all([
      checkDatabase(),
      checkRedis()
    ]);

    const memoryCheck = checkMemory();
    const responseTime = Date.now() - startTime;

    // Determinar status geral
    const allChecks = [databaseCheck, redisCheck, memoryCheck];
    const hasError = allChecks.some(check => check.status === 'error');
    const hasWarning = allChecks.some(check => check.status === 'warning');

    const overallStatus = hasError ? 'error' : hasWarning ? 'warning' : 'ok';

    const response = {
      status: overallStatus,
      uptime: Math.floor(process.uptime()),
      timestamp: new Date().toISOString(),
      version: process.env.npm_package_version || '1.0.0',
      environment: process.env.NODE_ENV || 'development',
      responseTime: `${responseTime}ms`,
      checks: {
        database: databaseCheck,
        redis: redisCheck,
        memory: memoryCheck
      }
    };

    // Status HTTP baseado no resultado
    const statusCode = overallStatus === 'ok' ? 200 : overallStatus === 'warning' ? 200 : 503;

    res.status(statusCode).json(response);

  } catch (error) {
    res.status(503).json({
      status: 'error',
      uptime: Math.floor(process.uptime()),
      timestamp: new Date().toISOString(),
      error: error.message
    });
  }
});

/**
 * Endpoint GET /health/liveness
 * 
 * Kubernetes liveness probe
 * Verifica se a aplicação está viva (não travada)
 */
router.get('/health/liveness', (req, res) => {
  res.status(200).json({
    status: 'ok',
    timestamp: new Date().toISOString()
  });
});

/**
 * Endpoint GET /health/readiness
 * 
 * Kubernetes readiness probe
 * Verifica se a aplicação está pronta para receber tráfego
 */
router.get('/health/readiness', async (req, res) => {
  try {
    const databaseCheck = await checkDatabase();

    if (databaseCheck.status === 'ok') {
      res.status(200).json({
        status: 'ready',
        timestamp: new Date().toISOString()
      });
    } else {
      res.status(503).json({
        status: 'not_ready',
        reason: 'database_unavailable',
        timestamp: new Date().toISOString()
      });
    }
  } catch (error) {
    res.status(503).json({
      status: 'not_ready',
      reason: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

/**
 * Endpoint GET /health/metrics
 * 
 * Métricas básicas para monitoramento
 */
router.get('/health/metrics', (req, res) => {
  const mem = process.memoryUsage();

  res.status(200).json({
    uptime: Math.floor(process.uptime()),
    memory: {
      rss: `${Math.round(mem.rss / 1024 / 1024)}MB`,
      heapTotal: `${Math.round(mem.heapTotal / 1024 / 1024)}MB`,
      heapUsed: `${Math.round(mem.heapUsed / 1024 / 1024)}MB`,
      external: `${Math.round(mem.external / 1024 / 1024)}MB`
    },
    cpu: process.cpuUsage(),
    pid: process.pid,
    platform: process.platform,
    nodeVersion: process.version
  });
});

// Limpar pool ao encerrar
process.on('SIGTERM', async () => {
  if (healthCheckPool) {
    await healthCheckPool.end();
  }
});

module.exports = router;
