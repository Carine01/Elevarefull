import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';

import { CacheModule } from '@nestjs/cache-manager';
import { BullModule } from '@nestjs/bull';
import * as redisStore from 'cache-manager-redis-store';
import { validationSchema } from './config/validation.schema';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { HealthModule } from './modules/health/health.module';
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { ClinicsModule } from './modules/clinics/clinics.module';
import { LeadsModule } from './modules/leads/leads.module';
import { AgendamentosModule } from './modules/agendamentos/agendamentos.module';
import { MensagensModule } from './modules/mensagens/mensagens.module';
import { CampanhasModule } from './modules/campanhas/campanhas.module';
import { FilaModule } from './modules/fila/fila.module';
import { WebhooksModule } from './modules/webhooks/webhooks.module';
import { IntegrationsModule } from './modules/integrations/integrations.module';
import { RelatoriosModule } from './modules/relatorios/relatorios.module';
import { LgpdModule } from './modules/lgpd/lgpd.module';
import { PrismaService } from './shared/prisma.service';

@Module({
  imports: [
    // Configuration
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
      validationSchema,
      validationOptions: {
        allowUnknown: true,
        abortEarly: false,
      },
    }),

    // Cache (Redis)
    CacheModule.registerAsync({
      isGlobal: true,
      inject: [ConfigService],
      useFactory: async (configService: ConfigService) => ({
        store: redisStore as any,
        host: configService.get('REDIS_HOST'),
        port: configService.get('REDIS_PORT'),
        ttl: 600, // 10 minutes
      }),
    }),

    // Message Queue (Bull)
    BullModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        redis: {
          host: configService.get('REDIS_HOST'),
          port: configService.get('REDIS_PORT'),
        },
        queues: [
          { name: 'leads' },
          { name: 'agendamentos' },
          { name: 'campanhas' },
          { name: 'mensagens' },
          { name: 'webhooks' }, // Nova fila para o Make.com
        ],
      }),
    }),

    // Feature Modules
    HealthModule,
    AuthModule,
    UsersModule,
    ClinicsModule,
    LeadsModule,
    AgendamentosModule,
    MensagensModule,
    CampanhasModule,
    FilaModule,
    WebhooksModule,
    IntegrationsModule,
    RelatoriosModule,
    LgpdModule,
  ],
  controllers: [AppController],
  providers: [AppService, PrismaService],
})
export class AppModule {}
