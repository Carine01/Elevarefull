// Integração WhatsApp Business API com Humanização
// Sistema completo de atendimento inteligente

const axios = require('axios');
const crypto = require('crypto');

class WhatsAppHumanizado {
  constructor(config) {
    this.config = config;
    this.baseURL = 'https://graph.facebook.com/v18.0';
    this.accessToken = config.accessToken;
    this.phoneNumberId = config.phoneNumberId;
    this.businessAccountId = config.businessAccountId;
    
    // Cache para otimização
    this.cache = new Map();
    this.rateLimit = new Map();
    
    // Personalidades da IARA
    this.personalidades = {
      neutra: {
        emojis: ['', '😊', '✨'],
        saudacoes: ['Olá', 'Oi', 'Oie'],
        despedidas: ['Até logo', 'Tchau', 'Até mais']
      },
      amigavel: {
        emojis: ['🌸', '💜', '😍', '✨'],
        saudacoes: ['Oi linda!', 'Olá, querida!', 'Oi amor!'],
        despedidas: ['Beijos!', 'Com carinho', 'Um abraço!']
      },
      profissional: {
        emojis: ['', '📋', '✅'],
        saudacoes: ['Bom dia', 'Olá', 'Prezada'],
        despedidas: ['Atenciosamente', 'Cordialmente', 'Até breve']
      }
    };
  }

  // Método principal para enviar mensagem humanizada
  async enviarMensagem(destinatario, mensagem, opcoes = {}) {
    try {
      const {
        personalidade = 'neutra',
        delay = true,
        usarTemplate = false,
        contexto = {},
        rastrear = true
      } = opcoes;

      // Verificar rate limit
      if (await this.verificarRateLimit(destinatario)) {
        throw new Error('Rate limit excedido para este número');
      }

      // Personalizar mensagem
      let mensagemPersonalizada = await this.personalizarMensagem(
        mensagem, 
        personalidade, 
        contexto
      );

      // Adicionar variações naturais
      mensagemPersonalizada = this.adicionarVariacoesNativas(
        mensagemPersonalizada, 
        personalidade
      );

      // Simular digitação humana se necessário
      if (delay) {
        await this.simularDigitacao(mensagemPersonalizada.length);
      }

      // Preparar payload
      const payload = {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to: this.formatarNumero(destinatario),
        type: 'text',
        text: {
          body: mensagemPersonalizada,
          preview_url: false
        }
      };

      // Enviar mensagem
      const response = await this.chamarAPI('/messages', 'POST', payload);

      // Registrar interação
      if (rastrear) {
        await this.registrarInteracao({
          destinatario,
          mensagem: mensagemPersonalizada,
          messageId: response.messages[0].id,
          timestamp: new Date(),
          personalidade,
          contexto
        });
      }

      // Atualizar rate limit
      this.atualizarRateLimit(destinatario);

      return {
        sucesso: true,
        messageId: response.messages[0].id],
        mensagem: mensagemPersonalizada,
        timestamp: new Date()
      };

    } catch (error) {
      await this.tratarErro(error, destinatario, mensagem);
      throw error;
    }
  }

  // Sistema de templates inteligentes
  async enviarTemplate(destinatario, templateId, variaveis = {}, opcoes = {}) {
    try {
      const template = await this.buscarTemplate(templateId);
      if (!template) {
        throw new Error('Template não encontrado');
      }

      // Personalizar template
      let mensagem = template.conteudo;
      
      // Substituir variáveis
      Object.keys(variaveis).forEach(chave => {
        const regex = new RegExp(`{{${chave}}}`, 'g');
        mensagem = mensagem.replace(regex, variaveis[chave]);
      });

      // Detectar perfil do cliente e ajustar tom
      const perfilCliente = await this.detectarPerfilCliente(destinatario);
      mensagem = await this.ajustarTomMensagem(mensagem, perfilCliente, template.tom);

      // Enviar mensagem personalizada
      return await this.enviarMensagem(destinatario, mensagem, opcoes);

    } catch (error) {
      console.error('Erro ao enviar template:', error);
      throw error;
    }
  }

  // Sistema de follow-up inteligente
  async agendarFollowUp(destinatario, mensagem, delay, opcoes = {}) {
    const followUpId = crypto.randomBytes(16).toString('hex');
    
    const agendamento = {
      id: followUpId,
      destinatario,
      mensagem,
      agendadoPara: new Date(Date.now() + delay),
      tentativas: 0,
      maxTentativas: opcoes.maxTentativas || 3,
      intervalo: opcoes.intervalo || 24 * 60 * 60 * 1000, // 24 horas
      opcoes
    };

    // Salvar no sistema de agendamento
    await this.salvarFollowUp(agendamento);
    
    return followUpId;
  }

  // Processar follow-ups pendentes
  async processarFollowUps() {
    const followUpsPendentes = await this.buscarFollowUpsPendentes();
    
    for (const followUp of followUpsPendentes) {
      try {
        // Verificar se é hora de enviar
        if (new Date() >= followUp.agendadoPara) {
          // Verificar condições antes de enviar
          const deveEnviar = await this.verificarCondicoesFollowUp(followUp);
          
          if (deveEnviar) {
            await this.enviarMensagem(
              followUp.destinatario,
              followUp.mensagem,
              followUp.opcoes
            );
            
            await this.marcarFollowUpConcluido(followUp.id);
          } else {
            // Reagendar para próxima tentativa
            await this.reagendarFollowUp(followUp);
          }
        }
      } catch (error) {
        console.error(`Erro ao processar follow-up ${followUp.id}:`, error);
        await this.registrarErroFollowUp(followUp.id, error);
      }
    }
  }

  // Personalização avançada de mensagens
  async personalizarMensagem(mensagem, personalidade, contexto) {
    const perfil = this.personalidades[personalidade] || this.personalidades.neutra;
    
    // Detectar horário e ajustar saudação
    const hora = new Date().getHours();
    let saudacao = '';
    
    if (hora < 12) {
      saudacao = perfil.saudacoes[Math.floor(Math.random() * perfil.saudacoes.length)];
    } else if (hora < 18) {
      saudacao = 'Boa tarde';
    } else {
      saudacao = 'Boa noite';
    }

    // Personalizar com dados do contexto
    const nome = contexto.nome || 'você';
    const clinica = contexto.clinica || 'nossa clínica';
    
    mensagem = mensagem
      .replace('{saudacao}', saudacao)
      .replace('{nome}', nome)
      .replace('{clinica}', clinica);

    // Adicionar contexto específico
    if (contexto.ultimaInteracao) {
      const diasDesdeUltimaInteracao = Math.floor(
        (Date.now() - contexto.ultimaInteracao.getTime()) / (1000 * 60 * 60 * 24)
      );
      
      if (diasDesdeUltimaInteracao > 7) {
        mensagem = `Senti sua falta! ${mensagem}`;
      }
    }

    return mensagem;
  }

  // Adicionar variações naturais às mensagens
  adicionarVariacoesNativas(mensagem, personalidade) {
    const perfil = this.personalidades[personalidade] || this.personalidades.neutra;
    
    // Adicionar emoji aleatório
    if (Math.random() > 0.3) { // 70% de chance
      const emoji = perfil.emojis[Math.floor(Math.random() * perfil.emojis.length)];
      mensagem += ` ${emoji}`;
    }

    // Variações de pontuação
    if (Math.random() > 0.8) { // 20% de chance
      mensagem = mensagem.replace(/!$/, '!!');
    }

    return mensagem;
  }

  // Detectar perfil do cliente baseado em histórico
  async detectarPerfilCliente(destinatario) {
    const historico = await this.buscarHistoricoCliente(destinatario);
    
    if (!historico || historico.length === 0) {
      return 'neutra';
    }

    // Analisar padrões de comunicação
    const analise = {
      respostasRapidas: 0,
      usaEmojis: 0,
      mensagensLongas: 0,
      totalMensagens: historico.length
    };

    historico.forEach(mensagem => {
      if (mensagem.respondidaEm && mensagem.respondidaEm - mensagem.enviadaEm < 5 * 60 * 1000) {
        analise.respostasRapidas++;
      }
      
      if (mensagem.conteudo.includes('😊') || mensagem.conteudo.includes('❤️')) {
        analise.usaEmojis++;
      }
      
      if (mensagem.conteudo.length > 100) {
        analise.mensagensLongas++;
      }
    });

    // Determinar perfil
    if (analise.usaEmojis / analise.totalMensagens > 0.5) {
      return 'amigavel';
    } else if (analise.mensagensLongas / analise.totalMensagens > 0.3) {
      return 'profissional';
    }
    
    return 'neutra';
  }

  // Ajustar tom da mensagem baseado no perfil
  async ajustarTomMensagem(mensagem, perfilCliente, tomOriginal) {
    switch (perfilCliente) {
      case 'mae_ocupada':
        // Mensagens mais diretas e objetivas
        mensagem = mensagem.replace(/(?:^|\.\s*)([^.]+)/g, (match, sentence) => {
          return sentence.length > 80 ? sentence.substring(0, 80) + '...' : sentence;
        });
        break;
        
      case 'ansiosa':
        // Mensagens mais calmantes e detalhadas
        mensagem = mensagem.replace(/!/g, '.');
        mensagem = `Fique tranquila, ${mensagem.toLowerCase()}`;
        break;
        
      case 'objetiva':
        // Tom profissional mantido
        break;
    }
    
    return mensagem;
  }

  // Simular digitação humana
  async simularDigitacao(tamanhoMensagem) {
    const tempoBase = 1000; // 1 segundo
    const tempoPorCaracter = 50; // 50ms por caractere
    const variacao = Math.random() * 1000; // Variação de até 1 segundo
    
    const tempoTotal = tempoBase + (tamanhoMensagem * tempoPorCaracter) + variacao;
    
    return new Promise(resolve => setTimeout(resolve, tempoTotal));
  }

  // Sistema de lembretes inteligentes
  async agendarLembrete(destinatario, tipo, data, mensagem, opcoes = {}) {
    const lembrete = {
      id: crypto.randomBytes(16).toString('hex'),
      destinatario,
      tipo,
      data: new Date(data),
      mensagem,
      enviado: false,
      opcoes,
      criadoEm: new Date()
    };

    await this.salvarLembrete(lembrete);
    return lembrete.id;
  }

  // Processar lembretes pendentes
  async processarLembretes() {
    const lembretesPendentes = await this.buscarLembretesPendentes();
    
    for (const lembrete of lembretesPendentes) {
      if (new Date() >= lembrete.data && !lembrete.enviado) {
        try {
          // Verificar se ainda é relevante
          const relevante = await this.verificarRelevanciaLembrete(lembrete);
          
          if (relevante) {
            await this.enviarMensagem(
              lembrete.destinatario,
              lembrete.mensagem,
              lembrete.opcoes
            );
            
            await this.marcarLembreteEnviado(lembrete.id);
          }
        } catch (error) {
          console.error(`Erro ao enviar lembrete ${lembrete.id}:`, error);
        }
      }
    }
  }

  // Verificar relevância do lembrete
  async verificarRelevanciaLembrete(lembrete) {
    switch (lembrete.tipo) {
      case 'consulta':
        // Verificar se consulta ainda está ativa
        return await this.consultaAtiva(lembrete.destinatario);
        
      case 'follow_up':
        // Verificar se cliente já respondeu
        const respondeu = await this.clienteRespondeu(lembrete.destinatario);
        return !respondeu;
        
      case 'promocao':
        // Verificar se promoção ainda é válida
        return await this.promocaoValida(lembrete.opcoes.promocaoId);
        
      default:
        return true;
    }
  }

  // Sistema de respostas rápidas (Quick Replies)
  async criarRespostasRapidas(destinatario, opcoes) {
    const quickReplies = {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: this.formatarNumero(destinatario),
      type: 'interactive',
      interactive: {
        type: 'button',
        body: {
          text: opcoes.mensagem
        },
        action: {
          buttons: opcoes.botoes.map((botao, index) => ({
            type: 'reply',
            reply: {
              id: `botao_${index}`,
              title: botao.texto
            }
          }))
        }
      }
    };

    return await this.chamarAPI('/messages', 'POST', quickReplies);
  }

  // Métodos auxiliares
  async chamarAPI(endpoint, method = 'GET', data = null) {
    const config = {
      method,
      url: `${this.baseURL}${endpoint}`,
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json'
      }
    };

    if (data) {
      config.data = data;
    }

    try {
      const response = await axios(config);
      return response.data;
    } catch (error) {
      console.error('Erro na API WhatsApp:', error.response?.data || error.message);
      throw error;
    }
  }

  formatarNumero(numero) {
    // Remover tudo que não é número
    return numero.replace(/\D/g, '');
  }

  async verificarRateLimit(destinatario) {
    const agora = Date.now();
    const limite = this.rateLimit.get(destinatario);
    
    if (limite && agora - limite < 60000) { // 1 minuto
      return true;
    }
    
    return false;
  }

  atualizarRateLimit(destinatario) {
    this.rateLimit.set(destinatario, Date.now());
  }

  // Métodos de banco de dados (mock)
  async buscarTemplate(templateId) {
    // Mock: buscar template do banco
    return {
      id: templateId,
      nome: 'Template Exemplo',
      conteudo: '{saudacao} {nome}! Tudo bem? Sobre seu interesse em {servico}, temos horários disponíveis. Quando seria melhor para você?',
      tom: 'amigavel',
      categoria: 'agendamento'
    };
  }

  async buscarHistoricoCliente(destinatario) {
    // Mock: buscar histórico do cliente
    return [
      {
        conteudo: 'Oi, gostaria de saber mais sobre o procedimento',
        enviadaEm: new Date('2024-01-15'),
        respondidaEm: new Date('2024-01-15')
      }
    ];
  }

  async registrarInteracao(dados) {
    // Mock: registrar interação no banco
    console.log('Registrando interação:', dados);
  }

  async tratarErro(error, destinatario, mensagem) {
    // Mock: tratamento de erros
    console.error('Erro WhatsApp:', {
      error: error.message,
      destinatario,
      mensagem: mensagem.substring(0, 100) + '...'
    });
  }

  // Métodos para follow-ups
  async salvarFollowUp(followUp) {
    // Mock: salvar follow-up no banco
    console.log('Follow-up agendado:', followUp.id);
  }

  async buscarFollowUpsPendentes() {
    // Mock: buscar follow-ups pendentes
    return [];
  }

  async marcarFollowUpConcluido(id) {
    console.log('Follow-up concluído:', id);
  }

  async verificarCondicoesFollowUp(followUp) {
    // Mock: verificar se deve enviar follow-up
    return true;
  }

  async reagendarFollowUp(followUp) {
    const novoAgendamento = new Date(followUp.agendadoPara.getTime() + followUp.intervalo);
    console.log('Reagendando follow-up para:', novoAgendamento);
  }

  // Métodos para lembretes
  async salvarLembrete(lembrete) {
    console.log('Lembrete salvo:', lembrete.id);
  }

  async buscarLembretesPendentes() {
    return [];
  }

  async marcarLembreteEnviado(id) {
    console.log('Lembrete enviado:', id);
  }

  async verificarRelevanciaLembrete(lembrete) {
    return true;
  }

  // Métodos auxiliares de verificação
  async consultaAtiva(destinatario) {
    // Mock: verificar se consulta ainda está ativa
    return true;
  }

  async clienteRespondeu(destinatario) {
    // Mock: verificar se cliente respondeu
    return false;
  }

  async promocaoValida(promocaoId) {
    // Mock: verificar se promoção é válida
    return true;
  }
}

// Sistema de templates inteligentes
class TemplateManager {
  constructor() {
    this.templates = new Map();
    this.carregarTemplatesPadrao();
  }

  carregarTemplatesPadrao() {
    const templatesPadrao = [
      {
        id: 'boas_vindas',
        nome: 'Boas-vindas',
        categoria: 'inicial',
        conteudo: '{saudacao} {nome}! Seja muito bem-vinda à {clinica}! 💜 Como posso te ajudar hoje?',
        tom: 'amigavel',
        gatilhos: ['nova_cliente', 'primeiro_contato']
      },
      {
        id: 'confirmacao_consulta',
        nome: 'Confirmação de Consulta',
        categoria: 'agendamento',
        conteudo: 'Oi {nome}! Passando pra confirmar seu horário {data} às {hora}. Tudo certo? 😊',
        tom: 'amigavel',
        gatilhos: ['confirmar_agendamento']
      },
      {
        id: 'follow_up_pos',
        nome: 'Follow-up Pós-Procedimento',
        conteudo: '{nome}, como você está se sentindo após o procedimento? 💕 Estou aqui se precisar de alguma coisa!',
        tom: 'cuidadoso',
        gatilhos: ['pos_procedimento']
      },
      {
        id: 'indicacao_amiga',
        nome: 'Pedido de Indicação',
        conteudo: 'Oi {nome}! Você está adorando os resultados, né? 😍 Se alguma amiga sua também quiser cuidar da pele, posso ajudar! Tem descontão pra indicadas 💜',
        tom: 'amigavel',
        gatilhos: ['satisfacao_alta', 'resultados_positivos']
      }
    ];

    templatesPadrao.forEach(template => {
      this.templates.set(template.id, template);
    });
  }

  async buscarTemplate(templateId) {
    return this.templates.get(templateId);
  }

  async listarTemplates(categoria = null) {
    const templates = Array.from(this.templates.values());
    
    if (categoria) {
      return templates.filter(t => t.categoria === categoria);
    }
    
    return templates;
  }

  async criarTemplate(dados) {
    const template = {
      id: crypto.randomBytes(16).toString('hex'),
      ...dados,
      criadoEm: new Date(),
      performance: {
        usos: 0,
        respostas: 0,
        conversao: 0
      }
    };

    this.templates.set(template.id, template);
    return template;
  }

  async atualizarPerformance(templateId, metrica) {
    const template = this.templates.get(templateId);
    if (template) {
      template.performance[metrica]++;
      
      // Calcular taxa de conversão
      if (template.performance.usos > 0) {
        template.performance.conversao = 
          (template.performance.respostas / template.performance.usos) * 100;
      }
    }
  }
}

// Sistema de analytics para mensagens
class MessageAnalytics {
  constructor() {
    this.metricas = new Map();
    this.horariosPico = new Map();
  }

  async registrarMetrica(destinatario, tipo, dados) {
    const chave = `${destinatario}_${new Date().toISOString().split('T')[0]}`;
    
    if (!this.metricas.has(chave)) {
      this.metricas.set(chave, {
        enviadas: 0,
        respondidas: 0,
        tempoResposta: [],
        horarios: []
      });
    }

    const metrica = this.metricas.get(chave);
    
    switch (tipo) {
      case 'enviada':
        metrica.enviadas++;
        metrica.horarios.push(new Date());
        break;
        
      case 'respondida':
        metrica.respondidas++;
        if (dados.tempoResposta) {
          metrica.tempoResposta.push(dados.tempoResposta);
        }
        break;
    }
  }

  async gerarRelatorio(periodo = 7) {
    const dataInicial = new Date();
    dataInicial.setDate(dataInicial.getDate() - periodo);
    
    const relatorio = {
      periodo,
      totalEnviadas: 0,
      totalRespondidas: 0,
      taxaResposta: 0,
      tempoMedioResposta: 0,
      horariosPico: [],
      templatesMaisEfetivos: []
    };

    // Processar métricas do período
    for (const [chave, metrica] of this.metricas) {
      const dataMetrica = new Date(chave.split('_')[1]);
      
      if (dataMetrica >= dataInicial) {
        relatorio.totalEnviadas += metrica.enviadas;
        relatorio.totalRespondidas += metrica.respondidas;
        
        // Calcular tempo médio de resposta
        if (metrica.tempoResposta.length > 0) {
          const media = metrica.tempoResposta.reduce((a, b) => a + b, 0) / metrica.tempoResposta.length;
          relatorio.tempoMedioResposta += media;
        }
      }
    }

    // Calcular taxa de resposta
    if (relatorio.totalEnviadas > 0) {
      relatorio.taxaResposta = (relatorio.totalRespondidas / relatorio.totalEnviadas) * 100;
    }

    // Identificar horários de pico
    relatorio.horariosPico = this.identificarHorariosPico(periodo);

    return relatorio;
  }

  identificarHorariosPico(periodo) {
    const horarios = [];
    
    // Analisar horários de envio
    for (const [chave, metrica] of this.metricas) {
      const dataMetrica = new Date(chave.split('_')[1]);
      const dataInicial = new Date();
      dataInicial.setDate(dataInicial.getDate() - periodo);
      
      if (dataMetrica >= dataInicial) {
        metrica.horarios.forEach(horario => {
          horarios.push(horario.getHours());
        });
      }
    }

    // Contar frequência por hora
    const frequenciaHoras = {};
    horarios.forEach(hora => {
      frequenciaHoras[hora] = (frequenciaHoras[hora] || 0) + 1;
    });

    // Retornar top 3 horários
    return Object.entries(frequenciaHoras)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 3)
      .map(([hora, frequencia]) => ({
        hora: parseInt(hora),
        frequencia,
        percentual: (frequencia / horarios.length) * 100
      }));
  }
}

// Integração completa
class IARAWhatsAppIntegration {
  constructor(config) {
    this.whatsApp = new WhatsAppHumanizado(config);
    this.templates = new TemplateManager();
    this.analytics = new MessageAnalytics();
    
    // Iniciar processos em background
    this.iniciarProcessosBackground();
  }

  iniciarProcessosBackground() {
    // Processar follow-ups a cada 5 minutos
    setInterval(() => {
      this.whatsApp.processarFollowUps();
    }, 5 * 60 * 1000);

    // Processar lembretes a cada minuto
    setInterval(() => {
      this.whatsApp.processarLembretes();
    }, 60 * 1000);

    // Gerar relatórios diários
    setInterval(() => {
      this.gerarRelatorioDiario();
    }, 24 * 60 * 60 * 1000);
  }

  async enviarMensagemCompleta(destinatario, tipo, dados) {
    try {
      let resultado;

      switch (tipo) {
        case 'template':
          resultado = await this.whatsApp.enviarTemplate(
            destinatario,
            dados.templateId,
            dados.variaveis,
            dados.opcoes
          );
          break;
          
        case 'personalizada':
          resultado = await this.whatsApp.enviarMensagem(
            destinatario,
            dados.mensagem,
            dados.opcoes
          );
          break;
          
        case 'quick_reply':
          resultado = await this.whatsApp.criarRespostasRapidas(
            destinatario,
            dados
          );
          break;
      }

      // Registrar métricas
      await this.analytics.registrarMetrica(destinatario, 'enviada', {
        tipo,
        timestamp: new Date()
      });

      return resultado;

    } catch (error) {
      console.error('Erro no envio completo:', error);
      throw error;
    }
  }

  async agendarFollowUpInteligente(destinatario, contexto) {
    // Analisar contexto e determinar melhor estratégia
    const estrategia = await this.determinarEstrategiaFollowUp(destinatario, contexto);
    
    // Criar sequência de follow-ups
    const followUps = await this.criarSequenciaFollowUp(estrategia);
    
    // Agendar cada follow-up
    const agendamentos = [];
    
    for (const followUp of followUps) {
      const id = await this.whatsApp.agendarFollowUp(
        destinatario,
        followUp.mensagem,
        followUp.delay,
        followUp.opcoes
      );
      agendamentos.push(id);
    }
    
    return agendamentos;
  }

  async determinarEstrategiaFollowUp(destinatario, contexto) {
    const perfil = await this.whatsApp.detectarPerfilCliente(destinatario);
    const historico = await this.whatsApp.buscarHistoricoCliente(destinatario);
    
    // Lógica para determinar a melhor estratégia
    const estrategia = {
      perfil,
      urgencia: contexto.urgencia || 'normal',
      intervalos: this.calcularIntervalos(perfil, contexto),
      mensagens: await this.gerarMensagensFollowUp(perfil, contexto)
    };
    
    return estrategia;
  }

  calcularIntervalos(perfil, contexto) {
    const intervalosBase = {
      'mae_ocupada': [2, 24, 72], // horas
      'ansiosa': [1, 12, 48],
      'objetiva': [4, 24, 96],
      'neutra': [6, 24, 72]
    };
    
    return intervalosBase[perfil] || intervalosBase.neutra;
  }

  async gerarMensagensFollowUp(perfil, contexto) {
    const mensagens = {
      'primeiro': '',
      'segundo': '',
      'ultimo': ''
    };
    
    // Gerar mensagens baseadas no perfil e contexto
    switch (perfil) {
      case 'mae_ocupada':
        mensagens.primeiro = 'Oi! Vi que você perguntou sobre {servico}. Tenho 2 minutinhos pra te explicar tudo, pode ser?';
        mensagens.segundo = 'Só passando pra lembrar que tenho horários essa semana! Qual dia seria melhor pra você?';
        mensagens.ultimo = 'Se quiser marcar, é só me avisar! Mas sem pressão, tá? 💜';
        break;
        
      case 'ansiosa':
        mensagens.primeiro = 'Oi {nome}! Tudo bem? Sobre seu interesse, quer conversar? Estou aqui pra tirar todas suas dúvidas 😊';
        mensagens.segundo = 'Lembra da nossa conversa sobre {servico}? Quando quiser marcar, estou aqui! Fique tranquila 💕';
        mensagens.ultimo = 'Sei que pode parecer muita informação! Mas estou aqui pra ajudar no seu tempo, tá bom? ✨';
        break;
        
      default:
        mensagens.primeiro = 'Oi {nome}! Sobre {servico}, quando seria melhor pra você? Tenho horários disponíveis!';
        mensagens.segundo = 'Passando pra lembrar dos horários! Qual dia combina mais pra você?';
        mensagens.ultimo = 'Se mudar de ideia ou tiver dúvidas, é só falar! Estou sempre por aqui 💜';
    }
    
    return mensagens;
  }

  async gerarRelatorioDiario() {
    const relatorio = await this.analytics.gerarRelatorio(1);
    
    // Enviar relatório para gestora
    const mensagemRelatorio = this.formatarRelatorioWhatsApp(relatorio);
    
    await this.whatsApp.enviarMensagem(
      this.config.gestoraPhone,
      mensagemRelatorio,
      { personalidade: 'profissional' }
    );
  }

  formatarRelatorioWhatsApp(relatorio) {
    return `📊 Relatório do Dia
    
🎯 Resultados:
• ${relatorio.totalEnviadas} mensagens enviadas
• ${relatorio.totalRespondidas} respostas recebidas  
• Taxa de resposta: ${relatorio.taxaResposta.toFixed(1)}%

⏱️ Performance:
• Tempo médio de resposta: ${relatorio.tempoMedioResposta.toFixed(0)}s

📈 Horários de pico:
${relatorio.horariosPico.map(h => `• ${h.hora}h: ${h.percentual.toFixed(0)}%`).join('\n')}

Continue assim! 💪`;
  }
}

// Exportar para uso
module.exports = {
  WhatsAppHumanizado,
  TemplateManager,
  MessageAnalytics,
  IARAWhatsAppIntegration
};

// Exemplo de uso
const exemplo = async () => {
  const config = {
    accessToken: 'SEU_ACCESS_TOKEN',
    phoneNumberId: 'SEU_PHONE_NUMBER_ID',
    businessAccountId: 'SEU_BUSINESS_ACCOUNT_ID',
    gestoraPhone: '5511999999999'
  };

  const iara = new IARAWhatsAppIntegration(config);

  // Enviar mensagem personalizada
  await iara.enviarMensagemCompleta('5511987654321', 'personalizada', {
    mensagem: '{saudacao} {nome}! Vi seu interesse em criolipólise. Quando seria melhor pra você?',
    opcoes: {
      personalidade: 'amigavel',
      contexto: {
        nome: 'Maria',
        servico: 'criolipólise'
      }
    }
  });

  // Agendar follow-up inteligente
  await iara.agendarFollowUpInteligente('5511987654321', {
    tipo: 'agendamento',
    urgencia: 'alta'
  });

  console.log('IARA WhatsApp integrado com sucesso!');
};

// exemplo();