/**
 * WhatsApp Auto-Sender - Modo Semi-Automático
 * 
 * Combina o melhor dos dois mundos:
 * - Modo Link: Gratuito, manual
 * - Modo API: Pago, automático
 * - Modo Auto: Híbrido (gratuito + semi-automático)
 */

const puppeteer = require('puppeteer');
const qrcode = require('qrcode-terminal');

class WhatsAppAutoSender {
  constructor(config = {}) {
    this.config = {
      headless: config.headless !== false, // Padrão: headless
      sessionPath: config.sessionPath || './whatsapp-session',
      timeout: config.timeout || 30000,
      mode: config.mode || 'link' // 'link', 'api', 'auto'
    };
    
    this.browser = null;
    this.page = null;
    this.isAuthenticated = false;
  }

  /**
   * Inicializar WhatsApp Web (modo auto)
   */
  async initialize() {
    if (this.config.mode !== 'auto') {
      console.log(`Modo ${this.config.mode} não requer inicialização`);
      return;
    }

    try {
      console.log('🚀 Iniciando WhatsApp Web...');
      
      this.browser = await puppeteer.launch({
        headless: this.config.headless,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-accelerated-2d-canvas',
          '--no-first-run',
          '--no-zygote',
          '--disable-gpu'
        ],
        userDataDir: this.config.sessionPath
      });

      this.page = await this.browser.newPage();
      await this.page.setUserAgent(
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      );

      console.log('📱 Abrindo WhatsApp Web...');
      await this.page.goto('https://web.whatsapp.com', {
        waitUntil: 'networkidle2',
        timeout: this.config.timeout
      });

      // Verificar se já está autenticado
      const isLoggedIn = await this.checkAuthentication();
      
      if (!isLoggedIn) {
        console.log('📲 Escaneie o QR Code no terminal ou no navegador:');
        await this.waitForQRCode();
        await this.waitForAuthentication();
      }

      this.isAuthenticated = true;
      console.log('✅ WhatsApp Web conectado!');
      
    } catch (error) {
      console.error('❌ Erro ao inicializar WhatsApp:', error.message);
      throw error;
    }
  }

  /**
   * Verificar se está autenticado
   */
  async checkAuthentication() {
    try {
      await this.page.waitForSelector('div[data-testid="chat-list"]', {
        timeout: 5000
      });
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Aguardar QR Code
   */
  async waitForQRCode() {
    try {
      const qrSelector = 'canvas[aria-label="Scan this QR code to link a device!"]';
      await this.page.waitForSelector(qrSelector, { timeout: 10000 });
      
      // Extrair QR Code e exibir no terminal
      const qrCodeData = await this.page.evaluate((selector) => {
        const canvas = document.querySelector(selector);
        return canvas ? canvas.toDataURL() : null;
      }, qrSelector);

      if (qrCodeData) {
        console.log('\n📱 QR CODE:\n');
        // Converter para terminal (requer biblioteca qrcode-terminal)
        // qrcode.generate(qrCodeData, { small: true });
        console.log('Abra o navegador em http://localhost:3000/qrcode para escanear\n');
      }
    } catch (error) {
      console.log('⚠️ QR Code não encontrado (pode já estar autenticado)');
    }
  }

  /**
   * Aguardar autenticação
   */
  async waitForAuthentication() {
    console.log('⏳ Aguardando autenticação...');
    
    await this.page.waitForSelector('div[data-testid="chat-list"]', {
      timeout: 60000
    });
    
    console.log('✅ Autenticado com sucesso!');
  }

  /**
   * Enviar mensagem (modo auto)
   */
  async sendMessage(phone, message) {
    const mode = this.config.mode;

    switch (mode) {
      case 'link':
        return this.sendViaLink(phone, message);
      
      case 'api':
        return this.sendViaAPI(phone, message);
      
      case 'auto':
        return this.sendViaAuto(phone, message);
      
      default:
        throw new Error(`Modo inválido: ${mode}`);
    }
  }

  /**
   * Enviar via Link (gratuito, manual)
   */
  sendViaLink(phone, message) {
    const formattedPhone = phone.replace(/\D/g, '');
    const encodedMessage = encodeURIComponent(message);
    const link = `https://wa.me/${formattedPhone}?text=${encodedMessage}`;
    
    return {
      success: true,
      mode: 'link',
      link,
      message: 'Clique no link para enviar manualmente'
    };
  }

  /**
   * Enviar via API (pago, automático)
   */
  async sendViaAPI(phone, message) {
    // Implementação da API oficial do WhatsApp
    // Requer WHATSAPP_API_TOKEN configurado
    const token = process.env.WHATSAPP_API_TOKEN;
    const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;

    if (!token || !phoneNumberId) {
      throw new Error('Credenciais da API WhatsApp não configuradas');
    }

    const axios = require('axios');
    const response = await axios.post(
      `https://graph.facebook.com/v18.0/${phoneNumberId}/messages`,
      {
        messaging_product: 'whatsapp',
        to: phone.replace(/\D/g, ''),
        type: 'text',
        text: { body: message }
      },
      {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return {
      success: true,
      mode: 'api',
      messageId: response.data.messages[0].id,
      message: 'Mensagem enviada via API'
    };
  }

  /**
   * Enviar via Auto (gratuito, semi-automático)
   */
  async sendViaAuto(phone, message) {
    if (!this.isAuthenticated) {
      throw new Error('WhatsApp não está autenticado. Execute initialize() primeiro.');
    }

    try {
      const formattedPhone = phone.replace(/\D/g, '');
      
      // Abrir conversa
      const chatUrl = `https://web.whatsapp.com/send?phone=${formattedPhone}`;
      await this.page.goto(chatUrl, { waitUntil: 'networkidle2' });

      // Aguardar campo de mensagem
      const inputSelector = 'div[contenteditable="true"][data-tab="10"]';
      await this.page.waitForSelector(inputSelector, { timeout: 10000 });

      // Digitar mensagem
      await this.page.click(inputSelector);
      await this.page.type(inputSelector, message, { delay: 100 }); // Simula digitação humana

      // Aguardar 1 segundo (humanização)
      await this.page.waitForTimeout(1000);

      // Enviar mensagem
      const sendButtonSelector = 'button[data-testid="compose-btn-send"]';
      await this.page.waitForSelector(sendButtonSelector);
      await this.page.click(sendButtonSelector);

      // Aguardar confirmação
      await this.page.waitForTimeout(2000);

      return {
        success: true,
        mode: 'auto',
        phone: formattedPhone,
        message: 'Mensagem enviada automaticamente via WhatsApp Web'
      };

    } catch (error) {
      console.error('❌ Erro ao enviar mensagem:', error.message);
      return {
        success: false,
        mode: 'auto',
        error: error.message,
        fallback: this.sendViaLink(phone, message) // Fallback para link
      };
    }
  }

  /**
   * Enviar mensagem em lote (queue)
   */
  async sendBulk(messages) {
    const results = [];
    
    for (const msg of messages) {
      try {
        const result = await this.sendMessage(msg.phone, msg.message);
        results.push({ ...msg, ...result });
        
        // Delay entre mensagens (anti-ban)
        const delay = Math.random() * 5000 + 3000; // 3-8 segundos
        await new Promise(resolve => setTimeout(resolve, delay));
        
      } catch (error) {
        results.push({
          ...msg,
          success: false,
          error: error.message
        });
      }
    }
    
    return results;
  }

  /**
   * Fechar conexão
   */
  async close() {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
      this.page = null;
      this.isAuthenticated = false;
      console.log('🔌 WhatsApp desconectado');
    }
  }

  /**
   * Obter status
   */
  getStatus() {
    return {
      mode: this.config.mode,
      authenticated: this.isAuthenticated,
      browser: this.browser ? 'ativo' : 'inativo'
    };
  }
}

// ========================================
// EXEMPLO DE USO
// ========================================

/**
 * Modo Link (Gratuito, Manual)
 */
async function exemploModoLink() {
  const whatsapp = new WhatsAppAutoSender({ mode: 'link' });
  
  const result = whatsapp.sendMessage('5511999999999', 'Olá! Teste de mensagem.');
  console.log(result.link); // Abrir no navegador
}

/**
 * Modo API (Pago, Automático)
 */
async function exemploModoAPI() {
  const whatsapp = new WhatsAppAutoSender({ mode: 'api' });
  
  const result = await whatsapp.sendMessage('5511999999999', 'Olá! Teste de mensagem.');
  console.log(result.messageId);
}

/**
 * Modo Auto (Gratuito, Semi-Automático)
 */
async function exemploModoAuto() {
  const whatsapp = new WhatsAppAutoSender({ 
    mode: 'auto',
    headless: false // Mostrar navegador
  });
  
  await whatsapp.initialize(); // Escanear QR Code uma vez
  
  const result = await whatsapp.sendMessage('5511999999999', 'Olá! Teste automático.');
  console.log(result);
  
  await whatsapp.close();
}

module.exports = WhatsAppAutoSender;
