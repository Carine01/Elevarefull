// Backend API - Exemplo de Integração IARA SaaS
// Node.js com Express e PostgreSQL

const express = require('express');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const app = express();

// Middleware de segurança
app.use(helmet());
app.use(express.json());

// Rate limiting por IP (configurável via ENV)
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutos (padrão)
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100, // limite de requisições (padrão)
  skip: (req) => {
    // Desabilitar rate limit se ENV estiver configurado
    return process.env.RATE_LIMIT_ENABLED === 'false';
  },
  message: { error: 'Muitas requisições. Tente novamente em alguns minutos.' }
});
app.use(limiter);

// Middleware de autenticação e extração de tenant
const authenticateTenant = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json({ error: 'Token não fornecido' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Suporte para múltiplos formatos de JWT
    req.tenantId = decoded.tenant || decoded.tenantId || decoded.sub?.tenant || decoded.clinic_id;
    req.userId = decoded.sub || decoded.user_id || decoded.userId;
    req.userPermissions = decoded.permissions || decoded.roles || [];

    // Conectar ao banco do tenant
    req.db = await getTenantConnection(req.tenantId);
    
    next();
  } catch (error) {
    res.status(401).json({ error: 'Token inválido' });
  }
};

// Pool de conexões para cada tenant
const tenantPools = new Map();

async function getTenantConnection(tenantId) {
  if (!tenantPools.has(tenantId)) {
    const pool = new Pool({
      host: process.env.DB_HOST,
      port: process.env.DB_PORT,
      database: `iara_${tenantId}`,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      max: 20,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    });
    tenantPools.set(tenantId, pool);
  }
  return tenantPools.get(tenantId);
}

// Rotas da API

// Templates CRUD
app.get('/api/v1/templates', authenticateTenant, async (req, res) => {
  try {
    const result = await req.db.query(
      'SELECT id, name, content, category, created_at FROM templates WHERE is_active = true ORDER BY created_at DESC'
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Erro ao buscar templates:', error);
    res.status(500).json({ error: 'Erro interno' });
  }
});

app.post('/api/v1/templates', authenticateTenant, async (req, res) => {
  try {
    // Verificar permissões
    if (!req.userPermissions.includes('templates:create')) {
      return res.status(403).json({ error: 'Permissão negada' });
    }

    const { name, content, category, variables } = req.body;
    
    const result = await req.db.query(
      'INSERT INTO templates (name, content, category, variables, created_by) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [name, content, category, JSON.stringify(variables), req.userId]
    );
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Erro ao criar template:', error);
    res.status(500).json({ error: 'Erro interno' });
  }
});

// Sistema de fila de envio
app.post('/api/v1/whatsapp/send', authenticateTenant, async (req, res) => {
  try {
    const { templateId, leadId, variables } = req.body;
    
    // Adicionar à fila de processamento
    const jobId = await addToQueue('whatsapp_send', {
      tenantId: req.tenantId,
      templateId,
      leadId,
      variables,
      userId: req.userId
    });
    
    res.json({ jobId, status: 'queued' });
  } catch (error) {
    console.error('Erro ao enfileirar mensagem:', error);
    res.status(500).json({ error: 'Erro interno' });
  }
});

// Analytics API
app.get('/api/v1/analytics/leads', authenticateTenant, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    
    const result = await req.db.query(`
      SELECT 
        DATE(created_at) as date,
        COUNT(*) as total_leads,
        COUNT(CASE WHEN status = 'converted' THEN 1 END) as converted_leads,
        AVG(score) as avg_score
      FROM leads 
      WHERE created_at BETWEEN $1 AND $2
      GROUP BY DATE(created_at)
      ORDER BY date DESC
    `, [startDate, endDate]);
    
    res.json(result.rows);
  } catch (error) {
    console.error('Erro ao buscar analytics:', error);
    res.status(500).json({ error: 'Erro interno' });
  }
});

// Webhook para eventos de pagamento
app.post('/webhooks/subscription', express.raw({type: 'application/json'}), (req, res) => {
  try {
    const event = JSON.parse(req.body);
    
    switch (event.type) {
      case 'subscription.updated':
        handleSubscriptionUpdate(event.data);
        break;
      case 'payment.failed':
        handlePaymentFailed(event.data);
        break;
      default:
        console.log('Evento não tratado:', event.type);
    }
    
    res.json({ received: true });
  } catch (error) {
    console.error('Erro no webhook:', error);
    res.status(400).json({ error: 'Webhook inválido' });
  }
});

// Middleware de tratamento de erros
app.use((err, req, res, next) => {
  console.error('Erro não tratado:', err);
  res.status(500).json({ error: 'Erro interno do servidor' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor IARA rodando na porta ${PORT}`);
});

// Funções auxiliares
async function addToQueue(queueName, data) {
  // Implementar com Bull/Redis
  return Math.random().toString(36).substr(2, 9);
}

async function handleSubscriptionUpdate(data) {
  // Atualizar configurações do tenant no banco
  console.log('Assinatura atualizada:', data);
}

async function handlePaymentFailed(data) {
  // Suspender serviços do tenant
  console.log('Pagamento falhou:', data);
}

module.exports = app;