// backend/src/common/guards/__tests__/webhook-secret.guard.spec.ts

import { WebhookSecretGuard } from '../webhook-secret.guard';
import { ConfigService } from '@nestjs/config';
import { ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { Request } from 'express';

describe('WebhookSecretGuard', () => {
  let guard: WebhookSecretGuard;
  let configService: ConfigService;

  const mockExecutionContext = (headers: Record<string, any>): ExecutionContext => ({
    switchToHttp: () => ({
      getRequest: () => ({ headers } as unknown as Request),
      getResponse: jest.fn(),
      getNext: jest.fn(),
    }),
    getClass: jest.fn(),
    getHandler: jest.fn(),
    getArgs: jest.fn(),
    getArgByIndex: jest.fn(),
    getType: jest.fn(),
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
  });

  beforeEach(() => {
    configService = {
      get: jest.fn(),
    } as unknown as ConfigService;
    guard = new WebhookSecretGuard(configService);
  });

  it('should be defined', () => {
    expect(guard).toBeDefined();
  });

  it('should return true if the secret matches', () => {
    (configService.get as jest.Mock).mockReturnValue('TEST_SECRET');
    const context = mockExecutionContext({ 'x-webhook-secret': 'TEST_SECRET' });
    expect(guard.canActivate(context)).toBe(true);
  });

  it('should throw UnauthorizedException if the secret does not match', () => {
    (configService.get as jest.Mock).mockReturnValue('TEST_SECRET');
    const context = mockExecutionContext({ 'x-webhook-secret': 'WRONG_SECRET' });
    expect(() => guard.canActivate(context)).toThrow(UnauthorizedException);
  });

  it('should throw UnauthorizedException if the header is missing', () => {
    (configService.get as jest.Mock).mockReturnValue('TEST_SECRET');
    const context = mockExecutionContext({});
    expect(() => guard.canActivate(context)).toThrow(UnauthorizedException);
  });

  it('should throw UnauthorizedException if the expected secret is not configured', () => {
    (configService.get as jest.Mock).mockReturnValue(undefined);
    const context = mockExecutionContext({ 'x-webhook-secret': 'TEST_SECRET' });
    expect(() => guard.canActivate(context)).toThrow(UnauthorizedException);
  });
});
