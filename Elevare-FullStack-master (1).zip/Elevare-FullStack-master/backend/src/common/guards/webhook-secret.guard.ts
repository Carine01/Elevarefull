// backend/src/common/guards/webhook-secret.guard.ts

import { Injectable, CanActivate, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Request } from 'express';

@Injectable()
export class WebhookSecretGuard implements CanActivate {
  constructor(private configService: ConfigService) {}

  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest<Request>();
    const secretHeader = request.headers['x-webhook-secret'];
    const expectedSecret = this.configService.get<string>('ELEVARE_WEBHOOK_SECRET');

    if (!expectedSecret) {
      // Se a variável de ambiente não estiver configurada, falha por segurança
      throw new UnauthorizedException('Webhook secret not configured on server.');
    }

    if (secretHeader !== expectedSecret) {
      // Falha se o segredo não corresponder
      throw new UnauthorizedException('Invalid webhook secret.');
    }

    return true;
  }
}
