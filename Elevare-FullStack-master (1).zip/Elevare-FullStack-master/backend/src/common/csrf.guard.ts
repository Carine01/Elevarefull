import { Injectable, CanActivate, ExecutionContext, ForbiddenException, Logger } from '@nestjs/common';
import { Request } from 'express';

@Injectable()
export class CsrfGuard implements CanActivate {
  private readonly logger = new Logger(CsrfGuard.name);

  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest<Request>();
    
    // Apenas proteja rotas que modificam dados (POST, PUT, PATCH, DELETE)
    if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(request.method)) {
        return true;
    }

    const csrfTokenHeader = request.headers['x-csrf-token'];
    const csrfTokenCookie = request.cookies['csrf-token'];
    
    // Validação: O token do header deve existir e ser IGUAL ao token do cookie
    if (!csrfTokenHeader || csrfTokenHeader !== csrfTokenCookie) {
      
      // --- LOGGING DE TENTATIVAS DE ATAQUE ---
      this.logger.warn(
        'CSRF ATTEMPT BLOCKED',
        {
          ip: request.ip,
          userAgent: request.get('User-Agent'),
          method: request.method,
          path: request.path,
          headerToken: csrfTokenHeader ? 'present' : 'missing',
          cookieToken: csrfTokenCookie ? 'present' : 'missing',
          match: false,
        }
      );
      // ---------------------------------------

      throw new ForbiddenException('CSRF token inválido ou ausente. Tentativa de ataque bloqueada.');
    }

    return true;
  }
}
