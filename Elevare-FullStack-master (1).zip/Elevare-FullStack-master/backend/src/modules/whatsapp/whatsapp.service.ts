import { Injectable, Logger } from '@nestjs/common';

@Injectable()
export class WhatsappService {
  private readonly logger = new Logger(WhatsappService.name);

  /**
   * Envia mensagem via WhatsApp
   * TODO: Integrar com WhatsApp Business API
   */
  async sendMessage(to: string, message: string): Promise<void> {
    this.logger.log(`Enviando mensagem WhatsApp para ${to}: ${message}`);
    // TODO: Implementar integração real
  }

  /**
   * Envia template de mensagem
   */
  async sendTemplate(templateName: string, params: any): Promise<void> {
    this.logger.log(`Enviando template ${templateName}`);
    // TODO: Implementar integração real
  }
}
