// backend/src/modules/clinics/dto/create-clinic.dto.ts

import { IsNotEmpty, IsString, IsOptional, IsUrl } from 'class-validator';

export class CreateClinicDto {
  @IsNotEmpty()
  @IsString()
  name: string; // Nome da clínica/unidade

  @IsNotEmpty()
  @IsString()
  address: string; // Endereço completo

  @IsOptional()
  @IsString()
  phone?: string; // Telefone de contato

  @IsOptional()
  @IsUrl()
  website?: string; // Website da clínica
}
