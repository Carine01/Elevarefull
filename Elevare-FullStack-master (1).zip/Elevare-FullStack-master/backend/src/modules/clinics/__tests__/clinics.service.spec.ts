// backend/src/modules/clinics/__tests__/clinics.service.spec.ts

import { Test, TestingModule } from '@nestjs/testing';
import { ClinicsService } from '../clinics.service';
import { CreateClinicDto } from '../dto/create-clinic.dto';
import { UpdateClinicDto } from '../dto/update-clinic.dto';
import { NotFoundException, Logger } from '@nestjs/common';

describe('ClinicsService', () => {
  let service: ClinicsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ClinicsService],
    }).compile();

    service = module.get<ClinicsService>(ClinicsService);

    // Mock do Logger
    jest.spyOn(Logger.prototype, 'log').mockImplementation(() => {});
    jest.spyOn(Logger.prototype, 'warn').mockImplementation(() => {});

    // Limpar a simulação de DB antes de cada teste
    (service as any).mockClinics.length = 0;
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  const createDto: CreateClinicDto = {
    name: 'Clínica Teste Alpha',
    address: 'Rua dos Testes, 123',
    phone: '11987654321',
  };

  describe('create', () => {
    it('should successfully create a clinic', async () => {
      const clinic = await service.create(createDto);
      expect(clinic).toBeDefined();
      expect(clinic.id).toBe(1);
      expect(clinic.name).toBe('Clínica Teste Alpha');
      expect((service as any).mockClinics.length).toBe(1);
    });
  });

  describe('findAll', () => {
    it('should return an array of clinics', async () => {
      await service.create(createDto);
      const clinics = await service.findAll();
      expect(clinics).toBeInstanceOf(Array);
      expect(clinics.length).toBe(1);
    });
  });

  describe('findOne', () => {
    it('should return a single clinic by ID', async () => {
      const createdClinic = await service.create(createDto);
      const foundClinic = await service.findOne(createdClinic.id);
      expect(foundClinic.id).toBe(createdClinic.id);
    });

    it('should throw NotFoundException if clinic is not found', async () => {
      await expect(service.findOne(999)).rejects.toThrow(NotFoundException);
    });
  });

  describe('update', () => {
    it('should update the clinic details', async () => {
      const createdClinic = await service.create(createDto);
      const updateDto: UpdateClinicDto = { name: 'Clínica Beta Atualizada' };
      const updatedClinic = await service.update(createdClinic.id, updateDto);

      expect(updatedClinic.name).toBe('Clínica Beta Atualizada');
      expect(updatedClinic.address).toBe(createDto.address); // Deve manter o campo não atualizado
    });

    it('should throw NotFoundException if clinic to update is not found', async () => {
      const updateDto: UpdateClinicDto = { name: 'Não existe' };
      await expect(service.update(999, updateDto)).rejects.toThrow(
        NotFoundException,
      );
    });
  });

  describe('remove', () => {
    it('should remove the clinic successfully', async () => {
      const createdClinic = await service.create(createDto);
      expect((service as any).mockClinics.length).toBe(1);

      await service.remove(createdClinic.id);
      expect((service as any).mockClinics.length).toBe(0);
    });

    it('should throw NotFoundException if clinic to remove is not found', async () => {
      await expect(service.remove(999)).rejects.toThrow(NotFoundException);
    });
  });
});
