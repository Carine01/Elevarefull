import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from 'src/shared/prisma.service';
import { Clinic } from '@prisma/client';
import { CreateClinicDto } from './dto/create-clinic.dto';
import { UpdateClinicDto } from './dto/update-clinic.dto';

@Injectable()
export class ClinicsService {
  private readonly logger = new Logger(ClinicsService.name);

  constructor(private prisma: PrismaService) {}

  // CREATE
  async create(dto: CreateClinicDto): Promise<Clinic> {
    const newClinic = await this.prisma.clinic.create({
      data: dto,
    });
    this.logger.log(`Clínica criada: ${newClinic.name} (ID: ${newClinic.id})`);
    return newClinic;
  }

  // READ ALL
  async findAll(): Promise<Clinic[]> {
    return this.prisma.clinic.findMany();
  }

  // READ ONE
  async findOne(id: number): Promise<Clinic> {
    const clinic = await this.prisma.clinic.findUnique({
      where: { id },
    });
    if (!clinic) {
      throw new NotFoundException(`Clínica com ID ${id} não encontrada.`);
    }
    return clinic;
  }

  // UPDATE
  async update(id: number, dto: UpdateClinicDto): Promise<Clinic> {
    try {
      const updatedClinic = await this.prisma.clinic.update({
        where: { id },
        data: dto,
      });
      this.logger.log(`Clínica atualizada: ${updatedClinic.name} (ID: ${updatedClinic.id})`);
      return updatedClinic;
    } catch (error) {
      if (error.code === 'P2025') { // Prisma error code for record not found
        throw new NotFoundException(`Clínica com ID ${id} não encontrada.`);
      }
      throw error;
    }
  }

  // DELETE
  async remove(id: number): Promise<void> {
    try {
      await this.prisma.clinic.delete({
        where: { id },
      });
      this.logger.log(`Clínica removida: ID ${id}`);
    } catch (error) {
      if (error.code === 'P2025') { // Prisma error code for record not found
        throw new NotFoundException(`Clínica com ID ${id} não encontrada.`);
      }
      throw error;
    }
  }
}
