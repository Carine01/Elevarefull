import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  ParseIntPipe,
  UseGuards,
  HttpStatus,
} from '@nestjs/common';
import { ClinicsService } from './clinics.service';
import { CreateClinicDto } from './dto/create-clinic.dto';
import { UpdateClinicDto } from './dto/update-clinic.dto';
// import { AuthGuard } from '@nestjs/passport'; // Assumindo que o AuthGuard é usado
// import { CsrfGuard } from '../../common/guards/csrf.guard'; // Assumindo que o CsrfGuard é usado

@Controller('clinics')
// @UseGuards(AuthGuard('jwt')) // Proteção do endpoint
export class ClinicsController {
  constructor(private readonly clinicsService: ClinicsService) {}

  @Post()
  // @UseGuards(CsrfGuard) // Proteção contra CSRF (rotas mutáveis)
  async create(@Body() createClinicDto: CreateClinicDto) {
    const clinic = await this.clinicsService.create(createClinicDto);
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Clínica criada com sucesso.',
      data: clinic,
    };
  }

  @Get()
  async findAll() {
    const clinics = await this.clinicsService.findAll();
    return {
      statusCode: HttpStatus.OK,
      data: clinics,
    };
  }

  @Get(':id')
  async findOne(@Param('id', ParseIntPipe) id: number) {
    const clinic = await this.clinicsService.findOne(id);
    return {
      statusCode: HttpStatus.OK,
      data: clinic,
    };
  }

  @Patch(':id')
  // @UseGuards(CsrfGuard) // Proteção contra CSRF (rotas mutáveis)
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateClinicDto: UpdateClinicDto,
  ) {
    const clinic = await this.clinicsService.update(id, updateClinicDto);
    return {
      statusCode: HttpStatus.OK,
      message: 'Clínica atualizada com sucesso.',
      data: clinic,
    };
  }

  @Delete(':id')
  // @UseGuards(CsrfGuard) // Proteção contra CSRF (rotas mutáveis)
  async remove(@Param('id', ParseIntPipe) id: number) {
    await this.clinicsService.remove(id);
    return {
      statusCode: HttpStatus.NO_CONTENT,
      message: 'Clínica removida com sucesso.',
    };
  }
}
