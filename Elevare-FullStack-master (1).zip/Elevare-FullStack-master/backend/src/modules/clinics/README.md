# Módulo de Clinics

Este módulo é responsável pela gestão das clínicas ou unidades de atendimento. Ele serve como a base para a segregação de dados (multi-tenancy) do sistema.

## Funcionalidades

- **CRUD Completo:** Criação, Leitura, Atualização e Deleção de registros de clínicas.
- **Tratamento de Erros:** Retorna `404 Not Found` para IDs inexistentes.

## Endpoints

| Método | Rota | Descrição |
| :--- | :--- | :--- |
| `POST` | `/clinics` | Cria uma nova clínica. |
| `GET` | `/clinics` | Lista todas as clínicas. |
| `GET` | `/clinics/:id` | Busca uma clínica específica por ID. |
| `PATCH` | `/clinics/:id` | Atualiza parcialmente os dados de uma clínica. |
| `DELETE` | `/clinics/:id` | Remove uma clínica. |

## DTOs (Data Transfer Objects)

### `CreateClinicDto`

| Campo | Tipo | Obrigatório | Descrição |
| :--- | :--- | :--- | :--- |
| `name` | `string` | Sim | Nome da clínica/unidade. |
| `address` | `string` | Sim | Endereço completo. |
| `phone` | `string` | Não | Telefone de contato. |
| `website` | `string` | Não | Website da clínica (deve ser uma URL válida). |

### `UpdateClinicDto`

Herda de `CreateClinicDto`, tornando todos os campos opcionais.
