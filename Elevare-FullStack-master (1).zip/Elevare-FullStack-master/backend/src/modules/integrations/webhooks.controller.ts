// backend/src/modules/integrations/webhooks.controller.ts

import { Controller, Patch, Body, UseGuards, HttpCode, HttpStatus } from '@nestjs/common';
import { WhaticketPaymentDto } from './dto/whaticket-payment.dto';
import { WebhookSecretGuard } from '../../common/guards/webhook-secret.guard';
import { WhaticketService } from './whaticket.service';

@Controller('webhooks/whaticket')
export class WebhooksController {
  constructor(private readonly whaticketService: WhaticketService) {}

  @Patch('payment')
  @UseGuards(WebhookSecretGuard) // 1. Proteção com chave secreta
  @HttpCode(HttpStatus.OK) // 2. Retorna 200 OK (Node Respond to Webhook)
  async handleWhaticketPayment(@Body() dto: WhaticketPaymentDto) {
    // 3. Validação do DTO (Node Set: Extract Data) é feita automaticamente pelo NestJS
    
    // 4. Delega a lógica de negócio (Node IF e Node HTTP) para o Service
    await this.whaticketService.handlePaymentWebhook(dto);

    // 5. Retorna a resposta de sucesso (Node Respond to Webhook)
    return { success: true, message: 'Webhook processed' };
  }
}
