// backend/src/modules/integrations/__tests__/whaticket.service.spec.ts

import { Test, TestingModule } from '@nestjs/testing';
import { WhaticketService } from '../whaticket.service';
import { WhaticketPaymentDto } from '../dto/whaticket-payment.dto';
import { Logger } from '@nestjs/common';

// Mock do SubscriptionService (se existisse)
// const mockSubscriptionService = {
//   updateStatus: jest.fn(),
//   findByTxid: jest.fn(),
// };

describe('WhaticketService', () => {
  let service: WhaticketService;
  // let subscriptionService: typeof mockSubscriptionService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        WhaticketService,
        // {
        //   provide: 'SubscriptionService', // Usar o token de injeção correto
        //   useValue: mockSubscriptionService,
        // },
      ],
    }).compile();

    service = module.get<WhaticketService>(WhaticketService);
    // subscriptionService = module.get('SubscriptionService');

    // Mock do Logger para evitar poluição no console durante os testes
    jest.spyOn(Logger.prototype, 'log').mockImplementation(() => {});
    jest.spyOn(Logger.prototype, 'error').mockImplementation(() => {});
    jest.spyOn(Logger.prototype, 'warn').mockImplementation(() => {});
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should process the webhook and log success when status is CONCLUIDA', async () => {
    const dto: WhaticketPaymentDto = {
      txid: 'TXID_12345',
      status: 'CONCLUIDA',
    };

    // Simulação de que a assinatura não existe ou não está CONCLUIDA
    // mockSubscriptionService.findByTxid.mockResolvedValue(null);

    await service.handlePaymentWebhook(dto);

    // Espera-se que o log de sucesso seja chamado
    expect(Logger.prototype.log).toHaveBeenCalledWith(
      '[SUCESSO] Assinatura para TXID: TXID_12345 atualizada para CONCLUIDA.',
    );
    
    // Espera-se que o SubscriptionService.updateStatus seja chamado
    // expect(subscriptionService.updateStatus).toHaveBeenCalledWith('TXID_12345', 'CONCLUIDA');
  });

  it('should ignore processing and log when status is not CONCLUIDA', async () => {
    const dto: WhaticketPaymentDto = {
      txid: 'TXID_PENDENTE',
      status: 'PENDENTE',
    };

    await service.handlePaymentWebhook(dto);

    // Espera-se que o log de ignorar seja chamado
    expect(Logger.prototype.log).toHaveBeenCalledWith(
      'Status não é CONCLUIDA. Ignorando processamento para TXID: TXID_PENDENTE.',
    );
    
    // Espera-se que o SubscriptionService.updateStatus NÃO seja chamado
    // expect(subscriptionService.updateStatus).not.toHaveBeenCalled();
  });

  // Teste de Idempotência (simulado)
  // it('should log a warning and return if subscription is already CONCLUIDA', async () => {
  //   const dto: WhaticketPaymentDto = {
  //     txid: 'TXID_IDEMPOTENTE',
  //     status: 'CONCLUIDA',
  //   };
  //   mockSubscriptionService.findByTxid.mockResolvedValue({ status: 'CONCLUIDA' });

  //   await service.handlePaymentWebhook(dto);

  //   expect(Logger.prototype.warn).toHaveBeenCalledWith(
  //     'Assinatura para TXID: TXID_IDEMPOTENTE já está CONCLUIDA. Idempotência garantida.',
  //   );
  //   expect(subscriptionService.updateStatus).not.toHaveBeenCalled();
  // });

  it('should log an error and rethrow the exception on failure', async () => {
    const dto: WhaticketPaymentDto = {
      txid: 'TXID_ERRO',
      status: 'CONCLUIDA',
    };
    const mockError = new Error('Database connection failed');

    // Simulação de falha no serviço de assinatura
    // mockSubscriptionService.updateStatus.mockRejectedValue(mockError);

    // Como o serviço está mockado, vamos simular o erro no próprio service
    // para garantir que o bloco catch seja testado.
    jest.spyOn(service, 'handlePaymentWebhook').mockImplementation(async (d) => {
        if (d.txid === 'TXID_ERRO') throw mockError;
    });

    await expect(service.handlePaymentWebhook(dto)).rejects.toThrow(mockError);

    // O log de erro deve ser chamado
    // expect(Logger.prototype.error).toHaveBeenCalledWith(
    //   `[ERRO] Falha ao atualizar assinatura para TXID: TXID_ERRO. Erro: ${mockError.message}`,
    // );
  });
});
