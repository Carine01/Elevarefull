// backend/src/modules/integrations/__tests__/webhooks.controller.spec.ts

import { Test, TestingModule } from '@nestjs/testing';
import { WebhooksController } from '../webhooks.controller';
import { WhaticketService } from '../whaticket.service';
import { WebhookSecretGuard } from '../../../common/guards/webhook-secret.guard';
import { WhaticketPaymentDto } from '../dto/whaticket-payment.dto';
import { ConfigService } from '@nestjs/config';

// Mock do WhaticketService
const mockWhaticketService = {
  handlePaymentWebhook: jest.fn(),
};

// Mock do WebhookSecretGuard (apenas para o teste do controller)
const mockWebhookSecretGuard = {
  canActivate: jest.fn(() => true),
};

describe('WebhooksController', () => {
  let controller: WebhooksController;
  let service: WhaticketService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [WebhooksController],
      providers: [
        {
          provide: WhaticketService,
          useValue: mockWhaticketService,
        },
        // O ConfigService é necessário para o Guard, mas o Guard está mockado
        ConfigService, 
      ],
    })
      .overrideGuard(WebhookSecretGuard)
      .useValue(mockWebhookSecretGuard)
      .compile();

    controller = module.get<WebhooksController>(WebhooksController);
    service = module.get<WhaticketService>(WhaticketService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('handleWhaticketPayment', () => {
    const mockDto: WhaticketPaymentDto = {
      txid: 'TXID_TEST',
      status: 'CONCLUIDA',
    };

    it('should call whaticketService.handlePaymentWebhook and return success', async () => {
      mockWhaticketService.handlePaymentWebhook.mockResolvedValue(undefined);

      const result = await controller.handleWhaticketPayment(mockDto);

      expect(mockWebhookSecretGuard.canActivate).toHaveBeenCalled();
      expect(mockWhaticketService.handlePaymentWebhook).toHaveBeenCalledWith(mockDto);
      expect(result).toEqual({ success: true, message: 'Webhook processed' });
    });

    it('should handle service errors gracefully (NestJS will convert to 500)', async () => {
      const mockError = new Error('Service failed');
      mockWhaticketService.handlePaymentWebhook.mockRejectedValue(mockError);

      await expect(controller.handleWhaticketPayment(mockDto)).rejects.toThrow(mockError);
    });
  });
});
