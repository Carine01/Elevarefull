// backend/src/modules/integrations/whaticket.service.ts

import { Injectable, Logger } from '@nestjs/common';
import { WhaticketPaymentDto } from './dto/whaticket-payment.dto';
// Importar o SubscriptionService (assumindo que ele existe no projeto)
// Como o projeto é modular, vamos simular a injeção do serviço de assinatura
// e a lógica de atualização.

// NOTA: No projeto real, o SubscriptionService deve ser importado e injetado.
// Para fins de demonstração da refatoração do n8n, vamos simular a dependência.

@Injectable()
export class WhaticketService {
  private readonly logger = new Logger(WhaticketService.name);

  // NOTA: O SubscriptionService deve ser injetado no construtor.
  // constructor(private subscriptionService: SubscriptionService) {}

  /**
   * Lida com o webhook de pagamento do WhaTicket, implementando a lógica do n8n.
   * @param dto O payload do webhook.
   */
  async handlePaymentWebhook(dto: WhaticketPaymentDto): Promise<void> {
    this.logger.log(`Recebido webhook de pagamento para TXID: ${dto.txid} com status: ${dto.status}`);

    // 1. Lógica do Node IF: Payment Success (status == 'CONCLUIDA')
    if (dto.status !== 'CONCLUIDA') {
      this.logger.log(`Status não é CONCLUIDA. Ignorando processamento para TXID: ${dto.txid}.`);
      return;
    }

    // 2. Lógica de Idempotência e Processamento (Node HTTP: Update Elevare Subscription)
    
    // NOTA: Aqui, o SubscriptionService seria usado para buscar a assinatura
    // e verificar seu status atual.
    
    // Simulação de busca e verificação de idempotência:
    // const subscription = await this.subscriptionService.findByTxid(dto.txid);
    // if (subscription && subscription.status === 'CONCLUIDA') {
    //   this.logger.warn(`Assinatura para TXID: ${dto.txid} já está CONCLUIDA. Idempotência garantida.`);
    //   return;
    // }

    try {
      // NOTA: Aqui, o SubscriptionService seria chamado para atualizar o status.
      // await this.subscriptionService.updateStatus(dto.txid, dto.status);
      
      this.logger.log(`[SUCESSO] Assinatura para TXID: ${dto.txid} atualizada para ${dto.status}.`);
      
      // Simulação de log de sucesso
      // O log estruturado (Pino) já está implementado no projeto base.
      // this.logger.log({ message: 'Subscription updated via Whaticket webhook', txid: dto.txid, status: dto.status });

    } catch (error) {
      this.logger.error(`[ERRO] Falha ao atualizar assinatura para TXID: ${dto.txid}. Erro: ${error.message}`);
      // Em um cenário real, o erro seria relançado ou tratado para notificação.
      throw error;
    }
  }
}
