// backend/src/modules/integrations/dto/whaticket-payment.dto.ts

import { IsString, IsNotEmpty, IsIn } from 'class-validator';

export class WhaticketPaymentDto {
  @IsString()
  @IsNotEmpty()
  txid: string; // ID da transação para identificar a fatura/assinatura

  @IsString()
  @IsNotEmpty()
  // O status deve ser um dos valores esperados, com foco em 'CONCLUIDA'
  @IsIn(['PENDENTE', 'CONCLUIDA', 'CANCELADA', 'FALHA'])
  status: 'PENDENTE' | 'CONCLUIDA' | 'CANCELADA' | 'FALHA';

  // Adicionar outros campos do payload do WhaTicket se necessário
}
