// backend/src/modules/integrations/integrations.module.ts

import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { WebhooksController } from './webhooks.controller';
import { WhaticketService } from './whaticket.service';
// Importar o SubscriptionModule para injetar o SubscriptionService
// import { SubscriptionModule } from '../subscriptions/subscription.module';

@Module({
  imports: [
    ConfigModule,
    // SubscriptionModule, // Adicionar o módulo de assinatura aqui
  ],
  controllers: [WebhooksController],
  providers: [WhaticketService],
  exports: [WhaticketService],
})
export class IntegrationsModule {}
