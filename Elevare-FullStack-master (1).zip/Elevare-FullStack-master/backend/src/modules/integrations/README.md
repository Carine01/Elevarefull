# Módulo de Integrações (IntegrationsModule)

Este módulo é responsável por gerenciar a comunicação e a integração com serviços de terceiros, garantindo que a lógica de negócio seja encapsulada, segura e aderente aos padrões do Elevare.

## Funcionalidades Atuais

### Webhook de Pagamento WhaTicket

Este é o primeiro fluxo de integração implementado, refatorado a partir de um fluxo n8n. Ele lida com a notificação de pagamento do sistema WhaTicket para atualizar o status de assinaturas no Elevare.

| Detalhe | Descrição |
| :--- | :--- |
| **Endpoint** | `PATCH /api/v1/webhooks/whaticket/payment` |
| **Método** | `PATCH` |
| **Payload** | `WhaticketPaymentDto` (requer `txid` e `status`) |
| **Segurança** | `WebhookSecretGuard` (autenticação via `X-Webhook-Secret` header) |
| **Lógica** | Implementada em `WhaticketService.handlePaymentWebhook()`. Garante idempotência e só processa status `CONCLUIDA`. |

## Variáveis de Ambiente

Para configurar a segurança deste webhook, a seguinte variável deve ser definida no seu ambiente:

| Variável | Descrição | Exemplo |
| :--- | :--- | :--- |
| `ELEVARE_WEBHOOK_SECRET` | Chave secreta compartilhada com o WhaTicket para autenticar o webhook. **Mantenha em segredo.** | `sua_chave_secreta_aqui` |

## Como Testar

1.  Defina a variável `ELEVARE_WEBHOOK_SECRET` no seu `.env`.
2.  Execute o script de QA: `sh scripts/qa/run-n8n-adapt-tests.sh`
3.  Simule uma requisição PATCH para o endpoint, incluindo o header `X-Webhook-Secret` com o valor configurado.

```bash
curl -X PATCH "http://localhost:3000/api/v1/webhooks/whaticket/payment" \
  -H "Content-Type: application/json" \
  -H "X-Webhook-Secret: sua_chave_secreta_aqui" \
  -d '{"txid": "TXID_EXEMPLO_123", "status": "CONCLUIDA"}'
```
