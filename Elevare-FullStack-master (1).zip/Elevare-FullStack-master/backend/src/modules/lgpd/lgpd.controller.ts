import { Controller, Post, UseGuards, Body, Get, Res, Req } from '@nestjs/common';
import { Response } from 'express';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard'; // Assumindo que o guard está em common
import { CsrfGuard } from '../../common/csrf.guard';
import { LgpdService } from './lgpd.service';

@Controller('lgpd')
export class LgpdController {
  constructor(private readonly lgpdService: LgpdService) {}

  /**
   * Endpoint para registrar o consentimento do usuário.
   */
  @Post('consent')
  async registerConsent(@Body('consentHash') consentHash: string, @Body('userId') userId: string) {
    // A lógica de validação e registro do hash de consentimento
    await this.lgpdService.saveConsent(userId, consentHash);
    return { message: 'Consentimento registrado com sucesso.' };
  }

  /**
   * Endpoint para exportar os dados do usuário (Direito de Acesso).
   * Protegido por JWT.
   */
  @Get('export')
  @UseGuards(JwtAuthGuard)
  async exportData(@Req() req, @Res() res: Response) {
    const userId = req.user.id; // Assumindo que o JWT injeta o user.id
    const data = await this.lgpdService.exportUserData(userId);
    
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename=dados_usuario_${userId}.json`);
    res.send(data);
  }

  /**
   * Endpoint para anonimizar os dados do usuário (Direito ao Esquecimento).
   * Protegido por JWT e CSRF.
   */
  @Post('anonymize')
  @UseGuards(JwtAuthGuard, CsrfGuard)
  async anonymizeData(@Req() req) {
    const userId = req.user.id;
    await this.lgpdService.anonymizeUser(userId);
    return { message: 'Dados anonimizados com sucesso. Sua conta será desativada.' };
  }
}
