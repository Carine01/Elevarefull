// backend/src/modules/mensagens/__tests__/mensagens.processor.spec.ts

import { Test, TestingModule } from '@nestjs/testing';
import { MensagensProcessor } from '../mensagens.processor';
import { Logger } from '@nestjs/common';

describe('MensagensProcessor', () => {
  let processor: MensagensProcessor;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [MensagensProcessor],
    }).compile();

    processor = module.get<MensagensProcessor>(MensagensProcessor);

    // Mock do Logger
    jest.spyOn(Logger.prototype, 'log').mockImplementation(() => {});
  });

  it('should be defined', () => {
    expect(processor).toBeDefined();
  });

  it('should handle send-message job successfully', async () => {
    const jobData = { recipientId: 10, content: 'Teste de envio assíncrono' };
    const mockJob = { data: jobData } as any;

    const result = await processor.handleSendMessage(mockJob);

    expect(result.success).toBe(true);
    expect(result.recipientId).toBe(10);
    expect(Logger.prototype.log).toHaveBeenCalledWith(
      expect.stringContaining('Iniciando envio de mensagem para o Lead ID: 10'),
    );
    expect(Logger.prototype.log).toHaveBeenCalledWith(
      expect.stringContaining('Mensagem enviada com sucesso para o Lead ID: 10'),
    );
  });
});
