// backend/src/modules/mensagens/__tests__/mensagens.service.spec.ts

import { Test, TestingModule } from '@nestjs/testing';
import { MensagensService } from '../mensagens.service';
import { CreateMensagemDto } from '../dto/create-mensagem.dto';
import { getQueueToken } from '@nestjs/bull';
import { NotFoundException, Logger } from '@nestjs/common';

describe('MensagensService', () => {
  let service: MensagensService;
  let mockQueue: any;

  beforeEach(async () => {
    mockQueue = {
      add: jest.fn(),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        MensagensService,
        {
          provide: getQueueToken('mensagens'),
          useValue: mockQueue,
        },
      ],
    }).compile();

    service = module.get<MensagensService>(MensagensService);

    // Mock do Logger
    jest.spyOn(Logger.prototype, 'log').mockImplementation(() => {});
    jest.spyOn(Logger.prototype, 'warn').mockImplementation(() => {});

    // Limpar a simulação de DB antes de cada teste
    (service as any).mockMensagens.length = 0;
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  const createDto: CreateMensagemDto = {
    content: 'Olá, tudo bem?',
    senderId: 1,
    recipientId: 2,
    status: 'SENT',
  };

  describe('create', () => {
    it('should create a message and enqueue job if status is SENT', async () => {
      const mensagem = await service.create(createDto);
      expect(mensagem).toBeDefined();
      expect(mockQueue.add).toHaveBeenCalledWith('send-message', {
        recipientId: createDto.recipientId,
        content: createDto.content,
      });
    });

    it('should create a message but NOT enqueue job if status is RECEIVED', async () => {
      const receivedDto = { ...createDto, status: 'RECEIVED' as const };
      const mensagem = await service.create(receivedDto);
      expect(mensagem).toBeDefined();
      expect(mockQueue.add).not.toHaveBeenCalled();
    });
  });

  describe('findOne', () => {
    it('should throw NotFoundException if message is not found', async () => {
      await expect(service.findOne(999)).rejects.toThrow(NotFoundException);
    });
  });
});
