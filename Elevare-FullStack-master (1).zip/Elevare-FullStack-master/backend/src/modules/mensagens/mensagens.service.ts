import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { PrismaService } from 'src/shared/prisma.service';
import { substituteDynamicVariables } from './mensagens.utils';
import { Mensagem, Lead, Clinic, Agendamento } from '@prisma/client';
import { CreateMensagemDto } from './dto/create-mensagem.dto';
import { UpdateMensagemDto } from './dto/update-mensagem.dto';

@Injectable()
export class MensagensService {
  private readonly logger = new Logger(MensagensService.name);

  constructor(
    @InjectQueue('mensagens') private mensagensQueue: Queue,
    private prisma: PrismaService,
  ) {}

  /**
   * Prepara o contexto de dados para a substituição de variáveis dinâmicas.
   * @param recipientId ID do Lead/Cliente
   * @param clinicId ID da Clínica
   * @param agendamentoId ID do Agendamento (opcional)
   * @returns O objeto de contexto (Lead, Clinic, Agendamento)
   */
  private async getContext(recipientId: number, clinicId: number, agendamentoId?: number): Promise<{ lead: Lead, clinic: Clinic, agendamento?: Agendamento }> {
    const lead = await this.prisma.lead.findUnique({ where: { id: recipientId } });
    if (!lead) throw new NotFoundException(`Lead com ID ${recipientId} não encontrado.`);

    const clinic = await this.prisma.clinic.findUnique({ where: { id: clinicId } });
    if (!clinic) throw new NotFoundException(`Clínica com ID ${clinicId} não encontrada.`);

    let agendamento: Agendamento | undefined;
    if (agendamentoId) {
      agendamento = await this.prisma.agendamento.findUnique({ where: { id: agendamentoId } });
    }

    return { lead, clinic, agendamento };
  }

  /**
   * Envia uma mensagem, substituindo as variáveis dinâmicas.
   * @param dto Dados da mensagem a ser enviada.
   * @returns A mensagem criada.
   */
  async sendMessage(dto: CreateMensagemDto & { agendamentoId?: number }): Promise<Mensagem> {
    // 1. Obter o contexto para substituição
    const context = await this.getContext(dto.recipientId, 1, dto.agendamentoId); // TODO: clinicId hardcoded, adicionar ao DTO

    // 2. Substituir as variáveis dinâmicas no conteúdo
    const finalContent = substituteDynamicVariables(dto.content, context);

    // 3. Criar a mensagem no banco de dados com o conteúdo final
    const newMensagem = await this.prisma.mensagem.create({
      data: {
        ...dto,
        content: finalContent, // Conteúdo final com variáveis substituídas
      },
    });
    this.logger.log(`Mensagem criada e pronta para envio: ID ${newMensagem.id}`);

    // 4. Enfileirar job para envio (o Bull fará o trabalho real)
    await this.mensagensQueue.add('send-message', {
      mensagemId: newMensagem.id,
      recipientId: newMensagem.recipientId,
      content: finalContent,
    });
    this.logger.log(`Job de envio de mensagem enfileirado para o Lead ID: ${newMensagem.recipientId}`);

    return newMensagem;
  }

  // Alias para compatibilidade com o controller
  async create(dto: CreateMensagemDto & { agendamentoId?: number }) {
    return this.sendMessage(dto);
  }

  // READ ALL
  async findAll(): Promise<Mensagem[]> {
    return this.prisma.mensagem.findMany();
  }

  // READ ONE
  async findOne(id: number): Promise<Mensagem> {
    const mensagem = await this.prisma.mensagem.findUnique({
      where: { id },
    });
    if (!mensagem) {
      throw new NotFoundException(`Mensagem com ID ${id} não encontrada.`);
    }
    return mensagem;
  }

  // UPDATE
  async update(id: number, dto: UpdateMensagemDto): Promise<Mensagem> {
    try {
      const updatedMensagem = await this.prisma.mensagem.update({
        where: { id },
        data: dto,
      });
      this.logger.log(`Mensagem atualizada: ID ${updatedMensagem.id}`);
      return updatedMensagem;
    } catch (error) {
      if (error.code === 'P2025') {
        throw new NotFoundException(`Mensagem com ID ${id} não encontrada.`);
      }
      throw error;
    }
  }

  // DELETE
  async remove(id: number): Promise<void> {
    try {
      await this.prisma.mensagem.delete({
        where: { id },
      });
      this.logger.log(`Mensagem removida: ID ${id}`);
    } catch (error) {
      if (error.code === 'P2025') {
        throw new NotFoundException(`Mensagem com ID ${id} não encontrada.`);
      }
      throw error;
    }
  }
}
