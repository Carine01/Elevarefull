// backend/src/modules/mensagens/mensagens.processor.ts

import { Process, Processor } from '@nestjs/bull';
import { Logger } from '@nestjs/common';
import { Job } from 'bull';

@Processor('mensagens')
export class MensagensProcessor {
  private readonly logger = new Logger(MensagensProcessor.name);

  @Process('send-message')
  async handleSendMessage(job: Job<{ recipientId: number; content: string }>) {
    const { recipientId, content } = job.data;
    this.logger.log(`Iniciando envio de mensagem para o Lead ID: ${recipientId}`);

    // --- Lógica de Integração com Z-API ou Gateway de WhatsApp ---
    // Simulação de envio
    await new Promise(resolve => setTimeout(resolve, 1000)); // Simula o tempo de requisição externa

    this.logger.log(`Mensagem enviada com sucesso para o Lead ID: ${recipientId}. Conteúdo: ${content.substring(0, 30)}...`);

    // Aqui você faria a chamada real para o Z-API
    // Ex: this.zapiService.send(recipientId, content);

    return { success: true, recipientId };
  }
}
