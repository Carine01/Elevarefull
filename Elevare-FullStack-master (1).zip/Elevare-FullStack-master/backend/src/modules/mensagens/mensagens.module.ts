import { Module } from '@nestjs/common';
import { MensagensService } from './mensagens.service';
import { MensagensController } from './mensagens.controller';
import { BullModule } from '@nestjs/bull';
import { MensagensProcessor } from './mensagens.processor';
@Module({
  imports: [
    BullModule.registerQueue({
      name: 'mensagens',
    }),
  ],
  controllers: [MensagensController],
  providers: [MensagensService, MensagensProcessor],
  exports: [MensagensService],
})
export class MensagensModule {}
