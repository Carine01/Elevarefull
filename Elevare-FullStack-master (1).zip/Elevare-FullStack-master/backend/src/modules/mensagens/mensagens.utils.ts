import { Lead, Clinic, Agendamento } from '@prisma/client';

// O "coração" do Elevare: Preservar a linguagem e os gatilhos da planilha.
// As variáveis dinâmicas permitem que os templates de comunicação sejam
// exatamente os mesmos da planilha SistemaElevareIara.xlsx.

interface ContextoMensagem {
  lead: Lead;
  clinic: Clinic;
  agendamento?: Agendamento; // Opcional, para mensagens relacionadas a agendamentos
}

/**
 * Realiza a substituição de variáveis dinâmicas em um template de mensagem.
 *
 * Variáveis Suportadas:
 * - {{lead.nome}}
 * - {{lead.telefone}}
 * - {{clinic.nome}}
 * - {{clinic.endereco}}
 * - {{agendamento.data}} (formato dd/mm/aaaa)
 * - {{agendamento.hora}} (formato hh:mm)
 *
 * @param template O template de mensagem com as variáveis.
 * @param contexto O objeto de contexto contendo Lead, Clinic e opcionalmente Agendamento.
 * @returns A mensagem com as variáveis substituídas.
 */
export function substituteDynamicVariables(template: string, contexto: ContextoMensagem): string {
  let message = template;
  const { lead, clinic, agendamento } = contexto;

  // 1. Variáveis do Lead
  message = message.replace(/\{\{lead\.nome\}\}/g, lead.name || 'Cliente');
  message = message.replace(/\{\{lead\.telefone\}\}/g, lead.phone || 'Não Informado');

  // 2. Variáveis da Clínica
  message = message.replace(/\{\{clinic\.nome\}\}/g, clinic.name || 'Clínica Elevare');
  message = message.replace(/\{\{clinic\.endereco\}\}/g, clinic.address || 'Endereço Não Informado');

  // 3. Variáveis do Agendamento (se existir)
  if (agendamento) {
    const dataAgendamento = new Date(agendamento.startTime);
    const dataFormatada = dataAgendamento.toLocaleDateString('pt-BR');
    const horaFormatada = dataAgendamento.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

    message = message.replace(/\{\{agendamento\.data\}\}/g, dataFormatada);
    message = message.replace(/\{\{agendamento\.hora\}\}/g, horaFormatada);
  }

  // 4. Limpeza (se houver variáveis não substituídas)
  // Isso é importante para evitar que o usuário veja {{variavel.nao.encontrada}}
  message = message.replace(/\{\{.*?\}\}/g, ' [DADO FALTANTE] ');

  return message;
}
