import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  ParseIntPipe,
  HttpStatus,
} from '@nestjs/common';
import { MensagensService } from './mensagens.service';
import { CreateMensagemDto } from './dto/create-mensagem.dto';
import { UpdateMensagemDto } from './dto/update-mensagem.dto';

@Controller('mensagens')
// @UseGuards(AuthGuard('jwt')) // Proteção do endpoint
export class MensagensController {
  constructor(private readonly mensagensService: MensagensService) {}

  @Post()
  // @UseGuards(CsrfGuard) // Proteção contra CSRF (rotas mutáveis)
  async create(@Body() createMensagemDto: CreateMensagemDto) {
    const mensagem = await this.mensagensService.create(createMensagemDto);
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Mensagem criada com sucesso.',
      data: mensagem,
    };
  }

  @Get()
  async findAll() {
    const mensagens = await this.mensagensService.findAll();
    return {
      statusCode: HttpStatus.OK,
      data: mensagens,
    };
  }

  @Get(':id')
  async findOne(@Param('id', ParseIntPipe) id: number) {
    const mensagem = await this.mensagensService.findOne(id);
    return {
      statusCode: HttpStatus.OK,
      data: mensagem,
    };
  }

  @Patch(':id')
  // @UseGuards(CsrfGuard) // Proteção contra CSRF (rotas mutáveis)
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateMensagemDto: UpdateMensagemDto,
  ) {
    const mensagem = await this.mensagensService.update(id, updateMensagemDto);
    return {
      statusCode: HttpStatus.OK,
      message: 'Mensagem atualizada com sucesso.',
      data: mensagem,
    };
  }

  @Delete(':id')
  // @UseGuards(CsrfGuard) // Proteção contra CSRF (rotas mutáveis)
  async remove(@Param('id', ParseIntPipe) id: number) {
    await this.mensagensService.remove(id);
    return {
      statusCode: HttpStatus.NO_CONTENT,
      message: 'Mensagem removida com sucesso.',
    };
  }
}
