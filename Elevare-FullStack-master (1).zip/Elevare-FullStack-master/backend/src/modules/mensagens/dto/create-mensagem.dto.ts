// backend/src/modules/mensagens/dto/create-mensagem.dto.ts

import { IsNotEmpty, IsString, IsOptional, IsNumber, IsIn } from 'class-validator';

export class CreateMensagemDto {
  @IsNotEmpty()
  @IsString()
  content: string; // Conteúdo da mensagem

  @IsNotEmpty()
  @IsNumber()
  senderId: number; // ID do remetente (usuário ou sistema)

  @IsNotEmpty()
  @IsNumber()
  recipientId: number; // ID do destinatário (lead/cliente)

  @IsOptional()
  @IsString()
  @IsIn(['SENT', 'RECEIVED', 'TEMPLATE'])
  status?: 'SENT' | 'RECEIVED' | 'TEMPLATE' = 'SENT'; // Status da mensagem

  @IsOptional()
  @IsString()
  type?: string = 'TEXT'; // Tipo de mensagem (TEXT, IMAGE, TEMPLATE)
}
