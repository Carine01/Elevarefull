# Módulo de Mensagens

Este módulo é responsável pela gestão do histórico de mensagens e pelo **envio assíncrono** de comunicações (simulando a integração com o Z-API ou outro gateway de WhatsApp).

## Funcionalidades

- **CRUD de Mensagens:** Criação, Leitura, Atualização e Deleção de mensagens (útil para histórico e templates).
- **Envio Assíncrono:** Utiliza filas (Bull/Redis) para processar o envio de mensagens em segundo plano, garantindo que o backend permaneça rápido.

## Endpoints

| Método | Rota | Descrição |
| :--- | :--- | :--- |
| `POST` | `/mensagens` | Cria uma nova mensagem. Se o status for `SENT`, enfileira o job de envio. |
| `GET` | `/mensagens` | Lista todas as mensagens. |
| `GET` | `/mensagens/:id` | Busca uma mensagem específica por ID. |
| `PATCH` | `/mensagens/:id` | Atualiza o status ou conteúdo de uma mensagem. |
| `DELETE` | `/mensagens/:id` | Remove uma mensagem. |

## Workers (Processamento Assíncrono)

- **`MensagensProcessor`**: Processa o job `send-message`, simulando a chamada externa para o gateway de mensagens.
