import { Module } from '@nestjs/common';
import { WebhooksService } from './webhooks.service';
import { BullModule } from '@nestjs/bull';
import { WebhookProcessor } from './webhook.processor';
import { WebhooksController } from './webhooks.controller';
@Module({
  imports: [
    BullModule.registerQueue({
      name: 'webhooks',
    }),
  ],
  controllers: [WebhooksController],
  providers: [WebhooksService, WebhookProcessor],
  exports: [WebhooksService],
})
export class WebhooksModule {}
