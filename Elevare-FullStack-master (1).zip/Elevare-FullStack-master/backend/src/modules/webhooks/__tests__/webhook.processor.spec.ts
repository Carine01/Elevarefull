// backend/src/modules/webhooks/__tests__/webhook.processor.spec.ts

import { Test, TestingModule } from '@nestjs/testing';
import { WebhookProcessor } from '../webhook.processor';
import { Job } from 'bull';
import { Logger } from '@nestjs/common';

// Mock do Logger para evitar poluição no console de teste
Logger.prototype.log = jest.fn();
Logger.prototype.error = jest.fn();

describe('WebhookProcessor', () => {
  let processor: WebhookProcessor;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [WebhookProcessor],
    }).compile();

    processor = module.get<WebhookProcessor>(WebhookProcessor);
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(processor).toBeDefined();
  });

  it('should log success when sending webhook (simulated)', async () => {
    const mockJob = {
      data: {
        clinicId: 'C001',
        leadId: 101,
        event: 'lead_created',
        payload: { name: 'Teste', phone: '11999999999' },
      },
    } as Job<any>;

    await processor.handleSendWebhook(mockJob);

    // Verifica se o log de sucesso foi chamado
    expect(Logger.prototype.log).toHaveBeenCalledWith(
      '[Webhook] Enviando para Make.com.',
    );
    expect(Logger.prototype.log).toHaveBeenCalledWith(
      '[Webhook] Sucesso! Evento lead_created enviado para Make.com.',
    );
    expect(Logger.prototype.error).not.toHaveBeenCalled();
  });

  it('should throw error to trigger retry (simulated failure)', async () => {
    const mockJob = {
      data: {
        clinicId: 'C002',
        leadId: 102,
        event: 'lead_created',
        payload: { name: 'Falha', phone: '11999999999' },
      },
    } as Job<any>;

    // Simula uma falha no envio (ex: erro de rede ou 5xx)
    jest.spyOn(global, 'setTimeout').mockImplementation((cb) => {
      // Força a exceção no meio do processo
      throw new Error('Simulated Network Error');
    });

    await expect(processor.handleSendWebhook(mockJob)).rejects.toThrow(
      'Simulated Network Error',
    );

    // Verifica se o log de erro foi chamado
    expect(Logger.prototype.error).toHaveBeenCalledWith(
      expect.stringContaining('[Webhook] Falha ao enviar evento lead_created para Make.com: Simulated Network Error'),
      expect.any(String),
    );

    // Restaura o setTimeout original
    jest.restoreAllMocks();
  });
});
