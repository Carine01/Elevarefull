// backend/src/modules/webhooks/webhook.processor.ts

import { Process, Processor } from '@nestjs/bull';
import { Logger } from '@nestjs/common';
import { Job } from 'bull';

/**
 * Interface para o Job de Webhook
 */
interface WebhookJob {
  clinicId: string;
  leadId: number;
  event: string; // Ex: 'lead_created', 'agendamento_confirmed'
  payload: any;
}

@Processor('webhooks')
export class WebhookProcessor {
  private readonly logger = new Logger(WebhookProcessor.name);

  /**
   * Simula o envio do Webhook para o Make.com
   * @param job Job com os dados do webhook
   */
  @Process('send-webhook')
  async handleSendWebhook(job: Job<WebhookJob>) {
    const { clinicId, leadId, event, payload } = job.data;

    this.logger.log(
      `[Webhook] Processando evento: ${event} para Lead ID: ${leadId} (Clínica: ${clinicId})`,
    );

    // --- Lógica de Envio Real (Simulação) ---
    try {
      // 1. Montar o payload final
      const finalPayload = {
        event,
        clinic_id: clinicId,
        lead_id: leadId,
        ...payload,
      };

      // 2. Simular a chamada HTTP para o Make.com
      // O URL real seria lido de uma variável de ambiente (WEBHOOK_MAKE_URL)
      // O Bearer Token seria lido de uma variável de ambiente (WEBHOOK_MAKE_SECRET)
      
      this.logger.log(`[Webhook] Enviando para Make.com...`);
      
      // Simulação de sucesso
      await new Promise(resolve => setTimeout(resolve, 500)); 

      this.logger.log(
        `[Webhook] Sucesso! Evento ${event} enviado para Make.com.`,
      );
      
      // O Bull fará o retry automático em caso de exceção (falha de rede, 5xx)
    } catch (error) {
      this.logger.error(
        `[Webhook] Falha ao enviar evento ${event} para Make.com: ${error.message}`,
        error.stack,
      );
      // O Bull re-enfileira o job automaticamente
      throw error; 
    }
  }
}
