# Módulo de Fila

Este módulo é o coração da gestão de atendimento, responsável por controlar o status dos leads no funil de comunicação.

## Funcionalidades

- **Gestão de Status:** Permite mover leads entre os status de atendimento: `PENDING` (Pendente), `IN_ATTENDANCE` (Em Atendimento) e `CLOSED` (Encerrado).
- **Visibilidade:** Endpoint para listar todos os leads na fila e seus respectivos status.

## Endpoints

| Método | Rota | Descrição |
| :--- | :--- | :--- |
| `GET` | `/fila` | Lista todos os leads na fila e seus status. |
| `PATCH` | `/fila` | Atualiza o status de um lead na fila. |

## DTOs (Data Transfer Objects)

### `UpdateFilaDto`

| Campo | Tipo | Obrigatório | Descrição |
| :--- | :--- | :--- | :--- |
| `leadId` | `number` | Sim | ID do lead a ser movido. |
| `status` | `string` | Sim | Novo status na fila. Valores: `PENDING`, `IN_ATTENDANCE`, `CLOSED`. |
