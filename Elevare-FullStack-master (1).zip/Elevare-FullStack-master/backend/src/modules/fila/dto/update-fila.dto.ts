// backend/src/modules/fila/dto/update-fila.dto.ts

import { IsNotEmpty, IsNumber, IsIn } from 'class-validator';

export class UpdateFilaDto {
  @IsNotEmpty()
  @IsNumber()
  leadId: number; // ID do lead a ser movido

  @IsNotEmpty()
  @IsIn(['PENDING', 'IN_ATTENDANCE', 'CLOSED'])
  status: 'PENDING' | 'IN_ATTENDANCE' | 'CLOSED'; // Novo status na fila
}
