// backend/src/modules/fila/__tests__/fila.service.spec.ts

import { Test, TestingModule } from '@nestjs/testing';
import { FilaService } from '../fila.service';
import { UpdateFilaDto } from '../dto/update-fila.dto';
import { Logger } from '@nestjs/common';

describe('FilaService', () => {
  let service: FilaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [FilaService],
    }).compile();

    service = module.get<FilaService>(FilaService);

    // Mock do Logger
    jest.spyOn(Logger.prototype, 'log').mockImplementation(() => {});

    // Limpar a simulação de DB antes de cada teste
    (service as any).mockFila.length = 0;
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('updateStatus', () => {
    const leadId = 10;

    it('should add a new lead to the queue if it does not exist', async () => {
      const dto: UpdateFilaDto = { leadId, status: 'PENDING' };
      const item = await service.updateStatus(dto);

      expect(item.leadId).toBe(leadId);
      expect(item.status).toBe('PENDING');
      expect((service as any).mockFila.length).toBe(1);
    });

    it('should update the status of an existing lead', async () => {
      // 1. Adiciona o lead
      await service.updateStatus({ leadId, status: 'PENDING' });

      // 2. Atualiza o status
      const dto: UpdateFilaDto = { leadId, status: 'IN_ATTENDANCE' };
      const item = await service.updateStatus(dto);

      expect(item.leadId).toBe(leadId);
      expect(item.status).toBe('IN_ATTENDANCE');
      expect((service as any).mockFila.length).toBe(1); // O tamanho deve permanecer 1
    });

    it('should return all items in the queue', async () => {
      await service.updateStatus({ leadId: 1, status: 'PENDING' });
      await service.updateStatus({ leadId: 2, status: 'IN_ATTENDANCE' });

      const fila = await service.findAll();
      expect(fila.length).toBe(2);
      expect(fila.some(i => i.leadId === 1 && i.status === 'PENDING')).toBe(true);
    });
  });
});
