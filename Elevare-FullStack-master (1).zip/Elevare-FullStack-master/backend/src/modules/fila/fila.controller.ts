import {
  Controller,
  Get,
  Patch,
  Body,
  HttpStatus,
} from '@nestjs/common';
import { FilaService } from './fila.service';
import { UpdateFilaDto } from './dto/update-fila.dto';

@Controller('fila')
// @UseGuards(AuthGuard('jwt')) // Proteção do endpoint
export class FilaController {
  constructor(private readonly filaService: FilaService) {}

  @Get()
  async findAll() {
    const fila = await this.filaService.findAll();
    return {
      statusCode: HttpStatus.OK,
      data: fila,
    };
  }

  @Patch()
  // @UseGuards(CsrfGuard) // Proteção contra CSRF (rotas mutáveis)
  async updateStatus(@Body() updateFilaDto: UpdateFilaDto) {
    const item = await this.filaService.updateStatus(updateFilaDto);
    return {
      statusCode: HttpStatus.OK,
      message: `Status do Lead ${item.leadId} atualizado para ${item.status}.`,
      data: item,
    };
  }
}
