import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from 'src/shared/prisma.service';
import { FilaItem } from '@prisma/client';
import { UpdateFilaDto } from './dto/update-fila.dto';

@Injectable()
export class FilaService {
  private readonly logger = new Logger(FilaService.name);

  constructor(private prisma: PrismaService) {}

  // READ ALL
  async findAll(): Promise<FilaItem[]> {
    return this.prisma.filaItem.findMany();
  }

  // UPDATE STATUS
  async updateStatus(dto: UpdateFilaDto): Promise<FilaItem> {
    // Tenta atualizar o item existente
    try {
      const updatedItem = await this.prisma.filaItem.update({
        where: { leadId: dto.leadId },
        data: { status: dto.status },
      });
      this.logger.log(`Status do Lead ${dto.leadId} atualizado para: ${dto.status}`);
      return updatedItem;
    } catch (error) {
      // Se não encontrar, cria um novo item (simulando a entrada na fila)
      if (error.code === 'P2025') {
        const newItem = await this.prisma.filaItem.create({
          data: {
            leadId: dto.leadId,
            status: dto.status,
          },
        });
        this.logger.log(`Lead ${dto.leadId} adicionado à fila com status: ${dto.status}`);
        return newItem;
      }
      throw error;
    }
  }
}
