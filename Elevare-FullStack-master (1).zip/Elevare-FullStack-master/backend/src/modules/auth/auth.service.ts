import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { randomBytes } from 'crypto';

// --- Entidades Mockadas (Assumindo a estrutura do seu projeto) ---
class User { id: string; email: string; role: string; }
// --- Repositório Mockado para Simular Revogação de Sessão ---
const revokedTokens = new Set<string>();
// -----------------------------------------------------------------

@Injectable()
export class AuthService {
  constructor(private jwtService: JwtService) {}

  // --- Lógica de Validação Original (Preservada) ---
  async validateUser(email: string, pass: string): Promise<User | null> {
    // Lógica original do seu projeto para buscar e validar o usuário no DB
    // Retorna o objeto User se válido, ou null
    return { id: '1', email: email, role: 'user' }; // Simulação
  }
  // --------------------------------------------------

  /**
   * Gera o JWT e o CSRF Token para o login.
   */
  async login(user: User): Promise<{ accessToken: string; csrfToken: string }> {
    const payload = { email: user.email, sub: user.id, role: user.role };
    const accessToken = this.jwtService.sign(payload);
    const csrfToken = randomBytes(32).toString('hex');
    
    return { accessToken, csrfToken };
  }

  /**
   * Gera um novo CSRF Token para renovação periódica.
   */
  generateCsrfToken(): string {
    return randomBytes(32).toString('hex');
  }

  /**
   * Marca o token JWT como revogado (simulação de blacklist).
   */
  async revokeToken(token: string): Promise<void> {
    revokedTokens.add(token);
  }

  /**
   * Verifica se o token foi revogado.
   */
  async isTokenRevoked(token: string): Promise<boolean> {
    return revokedTokens.has(token);
  }
}
