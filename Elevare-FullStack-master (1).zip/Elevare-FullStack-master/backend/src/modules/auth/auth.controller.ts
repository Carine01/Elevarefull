import { Controller, Post, Body, Res, UseGuards, Get, Req, UnauthorizedException } from '@nestjs/common';
import { Response, Request } from 'express';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard'; // Assumindo que o guard está em common
import { CsrfGuard } from '../../common/csrf.guard';
import { JwtService } from '@nestjs/jwt';

@Controller('auth')
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly jwtService: JwtService,
  ) {}

  // --- Lógica de Login (Adaptada para Double Submit Cookie) ---
  @Post('login')
  async login(@Body() credentials, @Res({ passthrough: true }) res: Response) {
    // 1. Validação de credenciais (Lógica original do seu projeto)
    const user = await this.authService.validateUser(credentials.email, credentials.password);
    if (!user) {
      throw new UnauthorizedException('Credenciais inválidas');
    }

    // 2. Geração de Tokens
    const { accessToken, csrfToken } = await this.authService.login(user);

    // 3. Setar Cookies
    // JWT em cookie HttpOnly (Proteção XSS)
    res.cookie('jwt', accessToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 3600000 * 24 * 7, // 7 dias
    });

    // CSRF Token em cookie NÃO-HttpOnly (Para leitura do JS e comparação)
    res.cookie('csrf-token', csrfToken, {
      httpOnly: false,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 3600000 * 24 * 7,
    });

    // 4. Retornar CSRF Token no body (Para o frontend armazenar no localStorage)
    return {
      message: 'Login bem-sucedido',
      csrfToken: csrfToken,
    };
  }
  // -------------------------------------------------------------

  /**
   * Endpoint para renovar o CSRF Token periodicamente.
   */
  @Post('csrf-renew')
  @UseGuards(JwtAuthGuard)
  renewCsrf(@Res({ passthrough: true }) res: Response) {
    const newCsrf = this.authService.generateCsrfToken();

    res.cookie('csrf-token', newCsrf, {
      httpOnly: false,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 3600000 * 24 * 7,
    });

    return {
      message: 'CSRF Token renovado com sucesso',
      csrfToken: newCsrf,
    };
  }

  /**
   * Endpoint para revogar o token atual (logout em todos os dispositivos).
   */
  @Post('revoke-session')
  @UseGuards(JwtAuthGuard, CsrfGuard)
  async revokeSession(@Req() req, @Res({ passthrough: true }) res: Response) {
    const token = req.cookies['jwt'];
    if (!token) {
      throw new UnauthorizedException('Token não encontrado.');
    }

    await this.authService.revokeToken(token);

    res.clearCookie('jwt', { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict' });
    res.clearCookie('csrf-token', { httpOnly: false, secure: process.env.NODE_ENV === 'production', sameSite: 'strict' });

    return { message: 'Sessão revogada com sucesso. Você foi desconectado de todos os dispositivos.' };
  }
}
