import { Lead } from '@prisma/client';

// Simulação de um modelo de Machine Learning (ML) para refinar o score.
// Em um cenário real, este módulo faria chamadas a um serviço de ML (ex: AWS SageMaker, Google AI Platform)
// ou usaria um modelo local treinado com dados históricos de conversão.

interface LeadDataForML {
  origem: string;
  servico: string;
  scoreBase: number;
  // Fatores de conversão histórica
  clinicConversionRate: number; // Taxa de conversão média da clínica
  origemConversionRate: number; // Taxa de conversão da origem específica
}

/**
 * Refina o score do lead usando uma simulação de modelo de Machine Learning.
 *
 * A lógica é: o score base (da planilha) é ajustado para cima ou para baixo
 * com base em fatores de conversão histórica da clínica e da origem.
 *
 * @param data Dados do lead e taxas de conversão.
 * @returns Score ajustado (entre 0 e 100).
 */
export function refineScoreWithML(data: LeadDataForML): number {
  let score = data.scoreBase;

  // Fator de Ajuste da Clínica: Se a clínica tem uma taxa de conversão alta, o score é ligeiramente inflado.
  const clinicFactor = (data.clinicConversionRate - 0.15) * 100; // 15% é a média de mercado (simulação)
  score += clinicFactor * 0.1; // Ajuste de 10% do fator

  // Fator de Ajuste da Origem: Se a origem tem uma taxa de conversão muito alta, o score é mais inflado.
  const origemFactor = (data.origemConversionRate - 0.10) * 100; // 10% é a média de origem (simulação)
  score += origemFactor * 0.2; // Ajuste de 20% do fator

  // Garantir que o score permaneça entre 0 e 100
  score = Math.max(0, Math.min(100, Math.round(score)));

  return score;
}

/**
 * Simulação de obtenção de taxas de conversão históricas.
 * Em um cenário real, isso seria uma consulta ao banco de dados de relatórios.
 * @param clinicId ID da clínica.
 * @param origem Origem do lead.
 * @returns Taxas de conversão.
 */
export async function getConversionRates(clinicId: number, origem: string): Promise<{ clinicConversionRate: number, origemConversionRate: number }> {
  // Simulação de dados históricos (para fins de desenvolvimento)
  const rates = {
    clinicConversionRate: 0.20, // 20% de conversão média da clínica
    origemConversionRate: 0.35, // 35% de conversão para a origem 'Google Ads'
  };

  if (origem.toLowerCase().includes('instagram')) {
    rates.origemConversionRate = 0.18; // Instagram tem conversão menor (simulação)
  }

  return rates;
}
