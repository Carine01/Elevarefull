// backend/src/modules/leads/leads.service.ts

import { Injectable, Logger } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { calcularScore, categorizarLead } from './leads.utils';
import { refineScoreWithML, getConversionRates } from './leads.ml';
import { applyAutomaticTags } from './leads.tagging';
import { PrismaService } from 'src/shared/prisma.service';
import { Lead } from '@prisma/client';
import { ListLeadsDto } from './dto/list-leads.dto';
import { CreateLeadDto } from './dto/create-lead.dto';


// Estrutura de Retorno
interface PaginatedResult<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

@Injectable()
export class LeadsService {
  private readonly logger = new Logger(LeadsService.name);

  constructor(
    private prisma: PrismaService,
    @InjectQueue('webhooks') private webhooksQueue: Queue,
  ) {}

  /**
   * Cria um novo Lead, aplicando a lógica de Score Preditivo e Categorização.
   * @param dto Dados do novo lead.
   * @returns O lead criado.
   */
  async create(dto: CreateLeadDto): Promise<Lead> {
    // Simulação: Obter o ticket médio da clínica (necessário para a etiquetagem)
    // Em um sistema real, isso viria do ClinicsService.
    const clinicConfig = await this.prisma.clinic.findUnique({ where: { id: parseInt(dto.clinicId) } });
    const ticketMedio = clinicConfig?.ticketMedio || 250; // Valor padrão se não encontrado
    // 1. Aplicar a lógica de Score e Categoria
    const dataEntrada = new Date();
    let score = calcularScore({
      origem: dto.origem || 'direct',
      servico: dto.servico || 'Não especificado',
      dataEntrada: dataEntrada,
    });

    // 1.1. Análise Preditiva Avançada (ML)
    const { clinicConversionRate, origemConversionRate } = await getConversionRates(parseInt(dto.clinicId), dto.origem || 'direct');
    score = refineScoreWithML({
      origem: dto.origem || 'direct',
      servico: dto.servico || 'Não especificado',
      scoreBase: score,
      clinicConversionRate,
      origemConversionRate,
    });

    const categoria = categorizarLead(score);

    this.logger.log(`Novo Lead: ${dto.name} | Score: ${score} | Categoria: ${categoria}`);

    // 2. Lógica de Etiquetagem (Hierarquia)
    // Simulação de Histórico para a Etiquetagem (em um sistema real, seria uma query)
    const leadWithHistory = {
      ...dto,
      agendamentosCount: 0, // Novo lead
      totalSpent: 0,
      lastAppointmentDate: null,
      noShowCount: 0,
    };
    const tags = applyAutomaticTags(leadWithHistory as any, ticketMedio);

    // 3. Persistir no banco de dados
    const newLead = await this.prisma.lead.create({
      data: {
        ...dto,
        clinicId: parseInt(dto.clinicId),
        score,
        categoria,
        tags: tags.join(','), // Salvar as tags como string separada por vírgula
        createdAt: dataEntrada,
      },
    });

    // 3. Enfileirar job para enviar webhook para o Make.com (simulando o GAS)
    this.webhooksQueue.add('send-webhook', {
      clinicId: newLead.clinicId,
      leadId: newLead.id,
      event: 'lead_created',
        payload: {
          name: newLead.name,
          phone: newLead.phone,
          score: newLead.score,
          categoria: newLead.categoria,
          tags: newLead.tags, // Adicionar as tags ao payload do webhook
          origem: newLead.origem,
          servico: newLead.servico,
        },
    });

    return newLead;
  }

  /**
   * Otimização de Performance: Implementa a listagem paginada de Leads.
   * @param dto Parâmetros de paginação e filtro.
   * @returns Resultado paginado.
   */
  async findAllPaginated(dto: ListLeadsDto): Promise<PaginatedResult<Lead>> {
    const page = parseInt(dto.page, 10) || 1;
    const limit = parseInt(dto.limit, 10) || 10;
    const skip = (page - 1) * limit;

    const where = dto.search
      ? {
          OR: [
            { name: { contains: dto.search, mode: 'insensitive' as const } },
            { email: { contains: dto.search, mode: 'insensitive' as const } },
            { phone: { contains: dto.search, mode: 'insensitive' as const } },
          ],
        }
      : {};

    const [data, total] = await this.prisma.$transaction([
      this.prisma.lead.findMany({
        where,
        skip,
        take: limit,
        orderBy: {
          [dto.sortBy]: dto.sortOrder,
        },
      }),
      this.prisma.lead.count({ where }),
    ]);

    const totalPages = Math.ceil(total / limit);

    this.logger.log(`Listando leads - Página: ${page}, Limite: ${limit}, Total: ${total}`);

    return {
      data,
      total,
      page,
      limit,
      totalPages,
    };
  }
}
