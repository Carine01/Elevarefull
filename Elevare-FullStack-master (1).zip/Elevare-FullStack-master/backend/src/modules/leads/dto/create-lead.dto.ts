// backend/src/modules/leads/dto/create-lead.dto.ts

import { IsEmail, IsNotEmpty, IsOptional, IsString, Matches } from 'class-validator';

export class CreateLeadDto {
  @IsNotEmpty()
  @IsString()
  name: string;

  @IsOptional()
  @IsEmail()
  email?: string;

  @IsNotEmpty()
  @IsString()
  @Matches(/^\d{10,15}$/, { message: 'Phone must be between 10 and 15 digits' })
  phone: string;

  @IsOptional()
  @IsString()
  origem?: string;

  @IsOptional()
  @IsString()
  servico?: string;

  @IsNotEmpty()
  @IsString()
  clinicId: string;
}
