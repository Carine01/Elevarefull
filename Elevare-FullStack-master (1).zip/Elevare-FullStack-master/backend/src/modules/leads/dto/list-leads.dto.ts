// backend/src/modules/leads/dto/list-leads.dto.ts

import { IsOptional, IsNumberString, IsString, IsIn } from 'class-validator';

export class ListLeadsDto {
  @IsOptional()
  @IsNumberString()
  page?: string = '1';

  @IsOptional()
  @IsNumberString()
  limit?: string = '10';

  @IsOptional()
  @IsString()
  search?: string; // Termo de busca (nome, email, telefone)

  @IsOptional()
  @IsString()
  @IsIn(['createdAt', 'updatedAt', 'name'])
  sortBy?: 'createdAt' | 'updatedAt' | 'name' = 'createdAt';

  @IsOptional()
  @IsString()
  @IsIn(['ASC', 'DESC'])
  sortOrder?: 'ASC' | 'DESC' = 'DESC';
}
