# Módulo de Leads (LeadsModule)

Este módulo gerencia a funcionalidade de Leads, sendo um dos módulos mais críticos para a performance do aplicativo devido ao volume de dados.

## Otimizações de Performance Implementadas

O módulo foi refatorado para garantir alta performance e escalabilidade, focando em:

### 1. Paginação e Filtros Otimizados

- **Endpoint:** `GET /leads`
- **Funcionalidade:** Lista leads com paginação (limit/offset) e ordenação.
- **Benefício:** Evita a sobrecarga do banco de dados ao buscar grandes volumes de dados.
- **Parâmetros de Query:**
    - `page` (default: 1)
    - `limit` (default: 10)
    - `search` (busca por nome, email ou telefone)
    - `sortBy` (default: `createdAt`)
    - `sortOrder` (default: `DESC`)

### 2. Processamento Assíncrono (Queues)

- **Endpoint:** `POST /leads/import`
- **Funcionalidade:** Inicia a importação de leads em massa em segundo plano.
- **Benefício:** A interface do usuário permanece responsiva (retorna `202 Accepted` imediatamente), e o processamento pesado é delegado ao `LeadsProcessor` (Worker).
- **Tecnologia:** **Bull/Redis** (configurado no `AppModule`).

## Como Testar

### 1. Testes de Unidade e Processador

Para validar a lógica de paginação, filtros e o processador de fila:

```bash
# Assumindo que você está no diretório backend/
# Rode os testes específicos do módulo Leads
npm run test -- src/modules/leads
```

### 2. Teste de Importação Assíncrona (Smoke Test)

Para testar o enfileiramento do job:

```bash
# 1. Certifique-se de que o Redis e o backend estão rodando.
# 2. Envie uma requisição para o endpoint de importação:

curl -X POST "http://localhost:3000/leads/import" \
  -H "Content-Type: application/json" \
  -d '{"fileUrl": "https://seu-s3.com/leads/arquivo.csv", "userId": 1}'
  
# Resposta esperada: 202 Accepted com o jobId.
# O LeadsProcessor irá processar o job em segundo plano.
```
