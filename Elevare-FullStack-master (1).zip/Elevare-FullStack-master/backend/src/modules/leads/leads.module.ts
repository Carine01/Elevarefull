// backend/src/modules/leads/leads.module.ts

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LeadsService } from './leads.service';
import { LeadsProcessor } from './leads.processor';
import { BullModule } from '@nestjs/bull';
import { LeadsController } from './leads.controller';
// Importar a entidade Lead (assumindo que existe)
// import { Lead } from '../../database/entities/lead.entity';

@Module({
  imports: [
    // TypeOrmModule.forFeature([Lead]),
    BullModule.registerQueue({
      name: 'leads', // Nome da fila para o LeadsWorker
    }),
    BullModule.registerQueue({
      name: 'webhooks', // Nome da fila para o WebhookProcessor

    }),
  ],
  controllers: [LeadsController],
  providers: [LeadsService, LeadsProcessor],
  exports: [LeadsService],
})
export class LeadsModule {}
