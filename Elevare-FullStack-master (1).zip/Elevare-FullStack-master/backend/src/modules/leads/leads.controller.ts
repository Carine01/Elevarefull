// backend/src/modules/leads/leads.controller.ts

import { Controller, Get, Query, UseGuards, HttpStatus, Post, Body, HttpCode } from '@nestjs/common';
import { LeadsService } from './leads.service';
import { CreateLeadDto } from './dto/create-lead.dto';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { ListLeadsDto } from './dto/list-leads.dto';
// import { AuthGuard } from '@nestjs/passport'; // Assumindo que o AuthGuard é usado

@Controller('leads')
// @UseGuards(AuthGuard('jwt')) // Proteção do endpoint
export class LeadsController {
  constructor(
    private readonly leadsService: LeadsService,
    @InjectQueue('leads') private leadsQueue: Queue,
  ) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  // @UseGuards(CsrfGuard) // Proteção contra CSRF
  async create(@Body() createLeadDto: CreateLeadDto) {
    const lead = await this.leadsService.create(createLeadDto);

    return {
      statusCode: HttpStatus.CREATED,
      message: 'Lead criado e pontuado com sucesso.',
      data: lead,
    };
  }

  @Get()
  async findAll(@Query() listLeadsDto: ListLeadsDto) {
    // Otimização de Performance: Chama o serviço com paginação
    const result = await this.leadsService.findAllPaginated(listLeadsDto);
    
    return {
      statusCode: HttpStatus.OK,
      message: 'Leads listados com sucesso.',
      data: result.data,
      meta: {
        total: result.total,
        page: result.page,
        limit: result.limit,
        totalPages: result.totalPages,
      },
    };
  }

  @Post('import')
  @HttpCode(HttpStatus.ACCEPTED) // Retorna 202 Accepted para processamento assíncrono
  async importLeads(@Body() body: { fileUrl: string; userId: number }) {
    // 1. Otimização de Performance: Enfileira o job para processamento em background
    const job = await this.leadsQueue.add('import-leads', {
      fileUrl: body.fileUrl,
      userId: body.userId,
    });

    return {
      statusCode: HttpStatus.ACCEPTED,
      message: 'Importação de leads iniciada em segundo plano.',
      jobId: job.id,
    };
  }
}
