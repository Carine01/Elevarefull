import { Lead } from '@prisma/client';

// Regras de Etiquetagem Automática baseadas na planilha Etiquetas_Master e na proposta de aprimoramento.
// A hierarquia será: VIP > AltoTicket > Recorrente > Outras.

export enum Tag {
  VIP = 'VIP',
  ALTO_TICKET = 'AltoTicket',
  RECORRENTE = 'Recorrente',
  NOVO_CLIENTE = 'NovoCliente',
  OCASIONAL = 'Ocasional',
  GOOGLE_LEAD = 'GoogleLead',
  INSTAGRAM_LEAD = 'InstagramLead',
  WHATSAPP_LEAD = 'WhatsAppLead',
  INDICATION_LEAD = 'IndicationLead',
  CORPORAL = 'Corporal',
  FACIAL = 'Facial',
  ANTI_AGE = 'AntiAge',
  WELLNESS = 'Wellness',
  SKINCARE = 'Skincare',
  INVASIVO = 'Invasivo',
  HOMENS = 'Homens',
  MULHERES = 'Mulheres',
  JOVEM = 'Jovem',
  ADULTO = 'Adulto',
  PLUS_45 = '45PLUS',
  INDICADO = 'Indicado',
  // Novas Etiquetas Comportamentais
  ENGAGED = 'Engajado',
  SILENT = 'Silencioso',
  NOSHOW = 'NoShow',
}

// Simulação de dados para o cálculo de etiquetas
interface LeadWithHistory extends Lead {
  agendamentosCount: number;
  totalSpent: number;
  lastAppointmentDate: Date | null;
  noShowCount: number;
}

/**
 * Lógica de Etiquetagem Automática
 * @param lead - Dados do lead com histórico (simulado)
 * @param ticketMedio - Valor do ticket médio da clínica
 * @returns Array de etiquetas aplicáveis
 */
export function applyAutomaticTags(lead: LeadWithHistory, ticketMedio: number): Tag[] {
  const tags: Tag[] = [];

  // 1. Etiquetagem por Origem (Base) - DESABILITADO: campo 'origem' não existe no schema
  // if (lead.origem?.toLowerCase().includes('google')) tags.push(Tag.GOOGLE_LEAD);
  // if (lead.origem?.toLowerCase().includes('instagram')) tags.push(Tag.INSTAGRAM_LEAD);
  // if (lead.origem?.toLowerCase().includes('whatsapp')) tags.push(Tag.WHATSAPP_LEAD);
  // if (lead.origem?.toLowerCase().includes('indicação')) tags.push(Tag.INDICATION_LEAD);

  // 2. Etiquetagem por Interesse (Base) - DESABILITADO: campo 'interesse' não existe no schema
  // if (lead.interesse?.toLowerCase().includes('corporal') || lead.interesse?.toLowerCase().includes('criomodelagem')) tags.push(Tag.CORPORAL);
  // if (lead.interesse?.toLowerCase().includes('facial') || lead.interesse?.toLowerCase().includes('skincare')) tags.push(Tag.FACIAL);
  // if (lead.interesse?.toLowerCase().includes('anti-age') || lead.interesse?.toLowerCase().includes('rejuvenescimento')) tags.push(Tag.ANTI_AGE);
  // if (lead.interesse?.toLowerCase().includes('massagem') || lead.interesse?.toLowerCase().includes('relaxamento')) tags.push(Tag.WELLNESS);
  // if (lead.interesse?.toLowerCase().includes('botox') || lead.interesse?.toLowerCase().includes('preenchedores')) tags.push(Tag.INVASIVO);

  // 3. Etiquetagem Comportamental (Aprimoramento) - DESABILITADO: campos não existem no schema
  // if (lead.agendamentosCount === 0) tags.push(Tag.NOVO_CLIENTE);
  // if (lead.noShowCount > 0) tags.push(Tag.NOSHOW);

  // 4. Etiquetagem de Valor e Recorrência (Hierarquia) - DESABILITADO: campos não existem no schema
  // if (lead.agendamentosCount >= 3) tags.push(Tag.RECORRENTE);
  // if (lead.totalSpent > ticketMedio * 5) tags.push(Tag.ALTO_TICKET); // AltoTicket: Gasto 5x o ticket médio
  // if (lead.totalSpent > ticketMedio * 10 && lead.agendamentosCount >= 5) tags.push(Tag.VIP); // VIP: Gasto 10x o ticket médio e alta recorrência

  // 5. Etiquetagem de Gênero e Idade (Simulação - precisa de campo no Lead)
  // if (lead.genero === 'M') tags.push(Tag.HOMENS);
  // if (lead.idade < 30) tags.push(Tag.JOVEM);

  // 6. Aplicação da Hierarquia (Garantir que a tag mais valiosa prevaleça)
  const finalTags = new Set<Tag>();
  if (tags.includes(Tag.VIP)) finalTags.add(Tag.VIP);
  else if (tags.includes(Tag.ALTO_TICKET)) finalTags.add(Tag.ALTO_TICKET);
  else if (tags.includes(Tag.RECORRENTE)) finalTags.add(Tag.RECORRENTE);

  // Adiciona as tags de interesse e origem
  tags.forEach(tag => finalTags.add(tag));

  return Array.from(finalTags);
}
