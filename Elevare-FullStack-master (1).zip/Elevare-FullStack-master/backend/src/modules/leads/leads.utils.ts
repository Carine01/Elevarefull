// backend/src/modules/leads/leads.utils.ts

// Definição dos tipos de dados necessários para o cálculo de score
interface LeadData {
  origem: string;
  servico: string;
  dataEntrada: Date;
}

export type LeadCategory = 'quente' | 'morno' | 'frio';

/**
 * Calcula o score preditivo do Lead baseado na lógica do Google Apps Script.
 * @param lead Dados do lead.
 * @returns Score de 0 a 100.
 */
export function calcularScore(lead: LeadData): number {
  let score = 50; // Base

  // 1. Origem Premium (+25)
  const origensAltas = ['instagram_ads', 'google_ads', 'indicacao'];
  if (origensAltas.includes(lead.origem.toLowerCase())) {
    score += 25;
  }

  // 2. Serviço de Alto Valor (+15)
  const servicosAltos = ['criomodelagem', 'depilacao_laser', 'estetica_avancada'];
  if (servicosAltos.includes(lead.servico.toLowerCase())) {
    score += 15;
  }

  // 3. Horário Comercial (+10)
  const hora = lead.dataEntrada.getHours();
  if (hora >= 9 && hora <= 18) {
    score += 10;
  }

  return Math.min(100, Math.max(0, score));
}

/**
 * Categoriza o Lead baseado no score.
 * @param score Score do lead.
 * @returns Categoria ('quente', 'morno', 'frio').
 */
export function categorizarLead(score: number): LeadCategory {
  if (score >= 70) return 'quente';
  if (score >= 50) return 'morno';
  return 'frio';
}
