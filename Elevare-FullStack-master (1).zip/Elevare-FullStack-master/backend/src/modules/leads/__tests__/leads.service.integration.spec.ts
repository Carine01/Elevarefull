// backend/src/modules/leads/__tests__/leads.service.integration.spec.ts

import { Test, TestingModule } from '@nestjs/testing';
import { LeadsService } from '../leads.service';
import { PrismaService } from '../../../shared/prisma.service';
import { ListLeadsDto } from '../dto/list-leads.dto';

// Mock do PrismaService para isolar o teste do banco de dados real
const prismaServiceMock = {
  lead: {
    findMany: jest.fn(),
    count: jest.fn(),
    create: jest.fn(),
  },
  $transaction: jest.fn().mockImplementation(async (queries) => {
    const results = [];
    for (const query of queries) {
      if (query.name === 'findMany') {
        results.push(prismaServiceMock.lead.findMany());
      } else if (query.name === 'count') {
        results.push(prismaServiceMock.lead.count());
      }
    }
    return results;
  }),
};

describe('LeadsService (Integration Mock)', () => {
  let service: LeadsService;
  let prisma: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        LeadsService,
        {
          provide: PrismaService,
          useValue: prismaServiceMock,
        },
      ],
    }).compile();

    service = module.get<LeadsService>(LeadsService);
    prisma = module.get<PrismaService>(PrismaService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should return paginated leads and total count', async () => {
    const mockLeads = [
      { id: 1, name: 'Lead 1', email: 'l1@e.com', phone: '123', createdAt: new Date() },
      { id: 2, name: 'Lead 2', email: 'l2@e.com', phone: '456', createdAt: new Date() },
    ];
    const mockTotal = 10;

    // Configura o mock para retornar os dados esperados
    prismaServiceMock.lead.findMany.mockResolvedValue(mockLeads);
    prismaServiceMock.lead.count.mockResolvedValue(mockTotal);

    const dto: ListLeadsDto = {
      page: '1',
      limit: '2',
      sortBy: 'createdAt',
      sortOrder: 'desc',
    };

    const result = await service.findAllPaginated(dto);

    expect(result.data).toEqual(mockLeads);
    expect(result.total).toBe(mockTotal);
    expect(result.totalPages).toBe(5); // 10 / 2 = 5
    expect(prismaServiceMock.lead.findMany).toHaveBeenCalledTimes(1);
    expect(prismaServiceMock.lead.count).toHaveBeenCalledTimes(1);
  });

  it('should apply search filter correctly', async () => {
    const mockTotal = 5;
    prismaServiceMock.lead.findMany.mockResolvedValue([]);
    prismaServiceMock.lead.count.mockResolvedValue(mockTotal);

    const dto: ListLeadsDto = {
      page: '1',
      limit: '10',
      sortBy: 'createdAt',
      sortOrder: 'desc',
      search: 'Test Lead',
    };

    await service.findAllPaginated(dto);

    // Verifica se o filtro 'where' foi passado corretamente para o Prisma
    expect(prismaServiceMock.lead.count).toHaveBeenCalledWith({
      where: {
        OR: [
          { name: { contains: 'Test Lead', mode: 'insensitive' } },
          { email: { contains: 'Test Lead', mode: 'insensitive' } },
          { phone: { contains: 'Test Lead', mode: 'insensitive' } },
        ],
      },
    });
  });
});
