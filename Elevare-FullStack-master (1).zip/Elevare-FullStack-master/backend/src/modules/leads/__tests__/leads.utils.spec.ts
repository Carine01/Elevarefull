// backend/src/modules/leads/__tests__/leads.utils.spec.ts

import { calcularScore, categorizarLead } from '../leads.utils';

describe('LeadsUtils', () => {
  describe('calcularScore', () => {
    it('should return base score of 50 for default inputs', () => {
      const leadData = {
        origem: 'direct',
        servico: 'Não especificado',
        dataEntrada: new Date(2025, 10, 26, 8, 0, 0), // Fora do horário comercial
      };
      expect(calcularScore(leadData)).toBe(50);
    });

    it('should add 25 for premium origin (instagram_ads)', () => {
      const leadData = {
        origem: 'instagram_ads',
        servico: 'Não especificado',
        dataEntrada: new Date(2025, 10, 26, 8, 0, 0),
      };
      expect(calcularScore(leadData)).toBe(75); // 50 + 25
    });

    it('should add 15 for high-value service (criomodelagem)', () => {
      const leadData = {
        origem: 'direct',
        servico: 'criomodelagem',
        dataEntrada: new Date(2025, 10, 26, 8, 0, 0),
      };
      expect(calcularScore(leadData)).toBe(65); // 50 + 15
    });

    it('should add 10 for commercial hours (10:00)', () => {
      const leadData = {
        origem: 'direct',
        servico: 'Não especificado',
        dataEntrada: new Date(2025, 10, 26, 10, 0, 0), // Dentro do horário comercial
      };
      expect(calcularScore(leadData)).toBe(60); // 50 + 10
    });

    it('should calculate max score (100) for all premium factors', () => {
      const leadData = {
        origem: 'google_ads',
        servico: 'depilacao_laser',
        dataEntrada: new Date(2025, 10, 26, 14, 0, 0), // Dentro do horário comercial
      };
      // 50 (base) + 25 (origem) + 15 (serviço) + 10 (horário) = 100
      expect(calcularScore(leadData)).toBe(100);
    });
  });

  describe('categorizarLead', () => {
    it('should return "quente" for score >= 70', () => {
      expect(categorizarLead(70)).toBe('quente');
      expect(categorizarLead(100)).toBe('quente');
    });

    it('should return "morno" for score >= 50 and < 70', () => {
      expect(categorizarLead(50)).toBe('morno');
      expect(categorizarLead(69)).toBe('morno');
    });

    it('should return "frio" for score < 50', () => {
      expect(categorizarLead(49)).toBe('frio');
      expect(categorizarLead(0)).toBe('frio');
    });
  });
});
