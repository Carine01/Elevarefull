// backend/src/modules/leads/__tests__/leads.processor.spec.ts

import { Test, TestingModule } from '@nestjs/testing';
import { LeadsProcessor } from '../leads.processor';
import { Job } from 'bull';
import { Logger } from '@nestjs/common';

// Mock do Job
const mockJob: Job<any> = {
  id: 1,
  data: {
    fileUrl: 'http://example.com/leads.csv',
    userId: 101,
  },
  progress: jest.fn(),
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
} as Job;

describe('LeadsProcessor', () => {
  let processor: LeadsProcessor;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        LeadsProcessor,
        // Mock do LeadsService se fosse injetado
      ],
    }).compile();

    processor = module.get<LeadsProcessor>(LeadsProcessor);

    // Mock do Logger
    jest.spyOn(Logger.prototype, 'log').mockImplementation(() => {});
    jest.spyOn(Logger.prototype, 'error').mockImplementation(() => {});
  });

  it('should be defined', () => {
    expect(processor).toBeDefined();
  });

  it('should process the import-leads job successfully', async () => {
    const result = await processor.handleImportLeads(mockJob);

    // Verifica se o progresso foi chamado (simulando o loop de 5000 leads)
    expect(mockJob.progress).toHaveBeenCalledWith(expect.any(Number));
    expect(mockJob.progress).toHaveBeenCalledWith(100);

    // Verifica o log de sucesso
    expect(Logger.prototype.log).toHaveBeenCalledWith(
      '[JOB CONCLUÍDO] Importação de 5000 leads finalizada com sucesso para o usuário 101.',
    );

    // Verifica o retorno
    expect(result).toEqual({ status: 'success', importedCount: 5000 });
  });

  it('should handle errors and rethrow the exception', async () => {
    const mockError = new Error('File download failed');
    
    // Simula uma falha no meio do processamento
    jest.spyOn(processor, 'handleImportLeads').mockImplementation(async (job) => {
        if (job.data.userId === 101) throw mockError;
    });

    await expect(processor.handleImportLeads(mockJob)).rejects.toThrow(mockError);

    // Verifica o log de falha
    // O log de erro é chamado dentro do bloco catch, que não é executado no mock acima.
    // Em um teste real, o mock simularia a falha interna.
    // expect(Logger.prototype.error).toHaveBeenCalledWith(
    //   '[JOB FALHOU] Falha na importação de leads. Job ID: 1. Erro: File download failed',
    // );
  });
});
