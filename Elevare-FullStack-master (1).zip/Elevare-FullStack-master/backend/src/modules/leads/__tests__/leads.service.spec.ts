// backend/src/modules/leads/__tests__/leads.service.spec.ts

import { Test, TestingModule } from '@nestjs/testing';
import { LeadsService } from '../leads.service';
import { PrismaService } from '../../../shared/prisma.service';
import { CreateLeadDto } from '../dto/create-lead.dto';

// Mock do PrismaService
const prismaServiceMock = {
  lead: {
    create: jest.fn(),
    findMany: jest.fn(),
    count: jest.fn(),
  },
  $transaction: jest.fn().mockImplementation(async (queries) => {
    return [
      prismaServiceMock.lead.findMany(),
      prismaServiceMock.lead.count(),
    ];
  }),
};

// Mock das funções utilitárias para isolar o teste
jest.mock('../leads.utils', () => ({
  calcularScore: jest.fn().mockReturnValue(85), // Sempre retorna 85 (quente)
  categorizarLead: jest.fn().mockReturnValue('quente'),
}));

describe('LeadsService', () => {
  let service: LeadsService;
  let prisma: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        LeadsService,
        {
          provide: PrismaService,
          useValue: prismaServiceMock,
        },
      ],
    }).compile();

    service = module.get<LeadsService>(LeadsService);
    prisma = module.get<PrismaService>(PrismaService);
    jest.clearAllMocks();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('create', () => {
    it('should call Prisma create with calculated score and category', async () => {
      const mockDto: CreateLeadDto = {
        name: 'Novo Lead Teste',
        phone: '11987654321',
        origem: 'google_ads',
        servico: 'criomodelagem',
      };
      const mockLead = {
        id: 1,
        ...mockDto,
        score: 85,
        categoria: 'quente',
        status: 'NEW',
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      prismaServiceMock.lead.create.mockResolvedValue(mockLead);

      const result = await service.create(mockDto);

      expect(result).toEqual(mockLead);
      expect(prismaServiceMock.lead.create).toHaveBeenCalledTimes(1);
      
      // Verifica se o score e a categoria foram passados para o Prisma
      const callData = prismaServiceMock.lead.create.mock.calls[0][0].data;
      expect(callData.score).toBe(85);
      expect(callData.categoria).toBe('quente');
      expect(callData.origem).toBe('google_ads');
    });
  });

  // Testes para findAllPaginated (já existentes)
  describe('findAllPaginated', () => {
    it('should return paginated leads and total count', async () => {
      const mockLeads = [
        { id: 1, name: 'Lead 1', email: 'l1@e.com', phone: '123', score: 50, categoria: 'morno', status: 'NEW', createdAt: new Date(), updatedAt: new Date() },
      ];
      const mockTotal = 10;

      prismaServiceMock.lead.findMany.mockResolvedValue(mockLeads);
      prismaServiceMock.lead.count.mockResolvedValue(mockTotal);

      const result = await service.findAllPaginated({ page: '1', limit: '1', sortBy: 'createdAt', sortOrder: 'desc' });

      expect(result.data).toEqual(mockLeads);
      expect(result.total).toBe(mockTotal);
    });
  });
});
