// backend/src/modules/campanhas/__tests__/campanhas.processor.spec.ts

import { Test, TestingModule } from '@nestjs/testing';
import { CampanhasProcessor } from '../campanhas.processor';
import { Job } from 'bull';
import { Logger } from '@nestjs/common';

// Mock do Job
const mockJob: Job<any> = {
  id: 1,
  data: {
    campanhaId: 10,
    leadId: 42,
    message: 'Olá, teste de mensagem.',
    phone: '+5511987654321',
  },
  progress: jest.fn(),
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
} as Job;

describe('CampanhasProcessor', () => {
  let processor: CampanhasProcessor;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        CampanhasProcessor,
        // Mock do WhatsappService se fosse injetado
      ],
    }).compile();

    processor = module.get<CampanhasProcessor>(CampanhasProcessor);

    // Mock do Logger
    jest.spyOn(Logger.prototype, 'log').mockImplementation(() => {});
    jest.spyOn(Logger.prototype, 'error').mockImplementation(() => {});
  });

  it('should be defined', () => {
    expect(processor).toBeDefined();
  });

  it('should process the send-message job successfully', async () => {
    const result = await processor.handleSendMessage(mockJob);

    // Verifica o log de sucesso
    expect(Logger.prototype.log).toHaveBeenCalledWith(
      '[JOB CONCLUÍDO] Mensagem enviada com sucesso para Lead 42.',
    );

    // Verifica o retorno
    expect(result).toEqual({ status: 'success', leadId: 42 });
  });

  it('should handle errors and rethrow the exception', async () => {
    const mockError = new Error('Whatsapp API rate limit exceeded');
    
    // Simula uma falha no meio do processamento
    jest.spyOn(processor, 'handleSendMessage').mockImplementation(async () => {
        throw mockError;
    });

    await expect(processor.handleSendMessage(mockJob)).rejects.toThrow(mockError);

    // O log de erro é chamado dentro do bloco catch, que não é executado no mock acima.
    // Em um teste real, o mock simularia a falha interna.
    // expect(Logger.prototype.error).toHaveBeenCalledWith(
    //   '[JOB FALHOU] Falha no envio para Lead 42. Erro: Whatsapp API rate limit exceeded',
    // );
  });
});
