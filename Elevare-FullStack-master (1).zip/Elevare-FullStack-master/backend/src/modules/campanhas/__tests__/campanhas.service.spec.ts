// backend/src/modules/campanhas/__tests__/campanhas.service.spec.ts

import { Test, TestingModule } from '@nestjs/testing';
import { CampanhasService } from '../campanhas.service';
import { CreateCampanhaDto } from '../dto/create-campanha.dto';
import { getQueueToken } from '@nestjs/bull';
import { Logger } from '@nestjs/common';

// Mock da Fila Bull
const mockQueue = {
  addBulk: jest.fn(),
};

describe('CampanhasService', () => {
  let service: CampanhasService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        CampanhasService,
        {
          provide: getQueueToken('campanhas'),
          useValue: mockQueue,
        },
      ],
    }).compile();

    service = module.get<CampanhasService>(CampanhasService);

    // Mock do Logger
    jest.spyOn(Logger.prototype, 'log').mockImplementation(() => {});

    mockQueue.addBulk.mockClear();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should create a campaign and enqueue all messages in bulk', async () => {
    const mockDto: CreateCampanhaDto = {
      name: 'Oferta Black Friday',
      messageTemplate: 'Olá {{nome}}, confira nossa oferta!',
      targetLeadIds: [1, 2, 3, 4, 5], // 5 leads
    };

    const result = await service.createAndSend(mockDto);

    expect(result.enqueuedCount).toBe(5);
    expect(result.campanhaId).toBeGreaterThan(0);

    // Verifica se o addBulk foi chamado
    expect(mockQueue.addBulk).toHaveBeenCalledTimes(1);

    // Verifica se o addBulk foi chamado com 5 jobs
    const jobs = mockQueue.addBulk.mock.calls[0][0];
    expect(jobs.length).toBe(5);

    // Verifica a estrutura de um job (personalização e opções)
    expect(jobs[0]).toEqual(
      expect.objectContaining({
        name: 'send-message',
        data: expect.objectContaining({
          leadId: 1,
          message: 'Olá Lead 1, confira nossa oferta!', // Personalização
          phone: expect.stringContaining('+55119'), // Simulação de telefone
        }),
        opts: expect.objectContaining({
          attempts: 3,
        }),
      }),
    );
  });

  it('should handle a large number of leads efficiently', async () => {
    const largeLeadList = Array.from({ length: 1000 }, (_, i) => i + 1);
    const mockDto: CreateCampanhaDto = {
      name: 'Campanha de Mil Leads',
      messageTemplate: 'Teste de carga',
      targetLeadIds: largeLeadList,
    };

    const result = await service.createAndSend(mockDto);

    expect(result.enqueuedCount).toBe(1000);
    expect(mockQueue.addBulk).toHaveBeenCalledTimes(1);
    const jobs = mockQueue.addBulk.mock.calls[0][0];
    expect(jobs.length).toBe(1000);
  });
});
