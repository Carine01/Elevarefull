// backend/src/modules/campanhas/dto/create-campanha.dto.ts

import { IsNotEmpty, IsString, IsArray, ArrayMinSize, IsNumber } from 'class-validator';

export class CreateCampanhaDto {
  @IsNotEmpty()
  @IsString()
  name: string; // Nome da campanha

  @IsNotEmpty()
  @IsString()
  messageTemplate: string; // Template da mensagem (ex: "Olá {{nome}}, temos uma oferta...")

  @IsArray()
  @ArrayMinSize(1)
  @IsNumber({}, { each: true })
  targetLeadIds: number[]; // Lista de IDs dos leads que receberão a mensagem
}
