# Módulo de Campanhas (CampanhasModule)

Este módulo gerencia o envio de mensagens em massa (campanhas) de forma **escalável e confiável**.

## Otimizações de Performance Implementadas

O módulo foi refatorado para ser um componente de **alta performance**, focado em lidar com picos de carga.

### 1. Processamento Assíncrono em Lotes

- **Endpoint:** `POST /campanhas`
- **Funcionalidade:** Recebe uma lista de leads e uma mensagem, e **enfileira** o envio de cada mensagem individualmente.
- **Benefício:** **Escalabilidade Ilimitada:** O servidor principal não é sobrecarregado. O envio de milhares de mensagens é delegado ao `CampanhasProcessor` (Worker) em segundo plano.
- **Resposta:** Retorna `202 Accepted` imediatamente.

### 2. Tolerância a Falhas (Retry)

- **Funcionalidade:** Cada job de envio individual é configurado para ser **tentado novamente (retry)** em caso de falha temporária (ex: falha na API do WhatsApp).
- **Benefício:** **Confiabilidade:** Garante que a mensagem será entregue, mesmo que haja problemas momentâneos na rede ou na API externa.

## Como Testar

### 1. Testes de Unidade (Enfileiramento em Lotes)

Para validar a lógica de enfileiramento em lotes e o processador:

```bash
# Assumindo que você está no diretório backend/
# Rode os testes específicos do módulo Campanhas
npm run test -- src/modules/campanhas
```

### 2. Teste de Enfileiramento (Smoke Test)

Para testar o enfileiramento do job:

```bash
# 1. Certifique-se de que o Redis e o backend estão rodando.
# 2. Envie uma requisição para o endpoint de criação de campanha:

curl -X POST "http://localhost:3000/campanhas" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Campanha de Teste",
    "messageTemplate": "Olá {{nome}}, esta é uma mensagem de teste.",
    "targetLeadIds": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
  }'
  
# Resposta esperada: 202 Accepted com o número de mensagens enfileiradas (10).
# O CampanhasProcessor irá processar o envio em segundo plano.
```
