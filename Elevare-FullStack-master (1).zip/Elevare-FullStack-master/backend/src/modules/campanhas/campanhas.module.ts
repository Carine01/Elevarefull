// backend/src/modules/campanhas/campanhas.module.ts

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CampanhasService } from './campanhas.service';
import { CampanhasController } from './campanhas.controller';
import { CampanhasProcessor } from './campanhas.processor';
import { BullModule } from '@nestjs/bull';

@Module({
  imports: [
    // TypeOrmModule.forFeature([Campanha]),
    BullModule.registerQueue({
      name: 'campanhas', // Nome da fila para o CampanhasWorker
    }),
  ],
  controllers: [CampanhasController],
  providers: [CampanhasService, CampanhasProcessor],
  exports: [CampanhasService],
})
export class CampanhasModule {}
