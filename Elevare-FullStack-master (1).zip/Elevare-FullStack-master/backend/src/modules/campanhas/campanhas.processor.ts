// backend/src/modules/campanhas/campanhas.processor.ts

import { Process, Processor } from '@nestjs/bull';
import { Logger } from '@nestjs/common';
import { Job } from 'bull';

// Simulação de Job para Envio de Mensagem Individual
interface SendMessageJob {
  campanhaId: number;
  leadId: number;
  message: string;
  phone: string;
}

@Processor('campanhas') // Processador para a fila 'campanhas'
export class CampanhasProcessor {
  private readonly logger = new Logger(CampanhasProcessor.name);

  // constructor(private readonly whatsappService: WhatsappService) {}

  /**
   * Processa o Job de Envio de Mensagem Individual.
   * Cada job representa o envio para um único lead.
   */
  @Process('send-message') // Nome do Job
  async handleSendMessage(job: Job<SendMessageJob>) {
    const { campanhaId, leadId, message, phone } = job.data;
    this.logger.log(`[JOB INICIADO] Enviando mensagem da Campanha ${campanhaId} para Lead ${leadId} (${phone}).`);

    try {
      // 1. Simulação de Envio de Mensagem (API do WhatsApp)
      // await this.whatsappService.sendMessage(phone, message);

      // Simulação de processamento
      await new Promise(resolve => setTimeout(resolve, 500)); 

      this.logger.log(`[JOB CONCLUÍDO] Mensagem enviada com sucesso para Lead ${leadId}.`);
      return { status: 'success', leadId };

    } catch (error) {
      this.logger.error(`[JOB FALHOU] Falha no envio para Lead ${leadId}. Erro: ${error.message}`);
      // O Bull irá lidar com retries
      throw error; 
    }
  }
}
