// backend/src/modules/campanhas/campanhas.controller.ts

import { Controller, Post, Body, UseGuards, HttpStatus, HttpCode } from '@nestjs/common';
import { CampanhasService } from './campanhas.service';
import { CreateCampanhaDto } from './dto/create-campanha.dto';
// import { AuthGuard } from '@nestjs/passport'; // Assumindo que o AuthGuard é usado
// import { CsrfGuard } from '../../common/csrf.guard'; // Assumindo que o CsrfGuard é usado

@Controller('campanhas')
// @UseGuards(AuthGuard('jwt')) // Proteção do endpoint
export class CampanhasController {
  constructor(private readonly campanhasService: CampanhasService) {}

  @Post()
  @HttpCode(HttpStatus.ACCEPTED) // Retorna 202 Accepted para processamento assíncrono
  // @UseGuards(CsrfGuard) // Proteção contra CSRF (rotas mutáveis)
  async create(@Body() createCampanhaDto: CreateCampanhaDto) {
    // Otimização de Performance: Enfileira o job em lotes
    const result = await this.campanhasService.createAndSend(
      createCampanhaDto,
    );

    return {
      statusCode: HttpStatus.ACCEPTED,
      message: `Campanha '${createCampanhaDto.name}' iniciada. ${result.enqueuedCount} mensagens enfileiradas.`,
      campanhaId: result.campanhaId,
      enqueuedCount: result.enqueuedCount,
    };
  }
}
