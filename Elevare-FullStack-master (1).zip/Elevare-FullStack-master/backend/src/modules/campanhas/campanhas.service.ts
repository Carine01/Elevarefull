// backend/src/modules/campanhas/campanhas.service.ts

import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from 'src/shared/prisma.service';
import { Lead, Clinic } from '@prisma/client';
import { substituteDynamicVariables } from '../mensagens/mensagens.utils'; // Reutilizar o motor de variáveis dinâmicas
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { CreateCampanhaDto } from './dto/create-campanha.dto';

@Injectable()
export class CampanhasService {
  private readonly logger = new Logger(CampanhasService.name);

  constructor(
    @InjectQueue('campanhas') private campanhasQueue: Queue,
    private prisma: PrismaService,
  ) {}

  /**
   * Otimização de Performance: Enfileira o envio de mensagens em lotes.
   * @param dto Dados da campanha.
   * @returns ID da campanha e número de mensagens enfileiradas.
   */
  /**
   * Implementa a lógica de Automação de Campanhas (Gatilhos).
   * @param clinicId ID da clínica para isolamento de dados.
   * @param trigger Tipo de gatilho (ex: 'LeadMorno7Days', 'LeadNoShow').
   * @param templateId ID do template de mensagem a ser usado.
   * @returns Número de leads impactados.
   */
  async runAutomatedCampaign(clinicId: number, trigger: string, templateId: number): Promise<{ impactedLeads: number }> {
    this.logger.log(`Executando Campanha Automatizada para Clínica ${clinicId} com Gatilho: ${trigger}`);

    // 1. Encontrar o Template de Mensagem (Simulação)
    // Em um cenário real, o template conteria o conteúdo e o agendamento (se houver)
    const template = {
      content: 'Olá {{lead.nome}}, a {{clinic.nome}} notou que você está um pouco sumido. Que tal agendar uma avaliação gratuita? Responda "SIM" para confirmar.',
    };

    // 2. Definir a Lógica de Seleção de Leads (O Coração da Automação)
    let leadsToTarget: Lead[] = [];

    // Lógica de Gatilho: Lead Morno há 7 dias
    if (trigger === 'LeadMorno7Days') {
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      leadsToTarget = await this.prisma.lead.findMany({
        where: {
          clinicId,
          categoria: 'morno',
          createdAt: {
            lte: sevenDaysAgo, // Criado há pelo menos 7 dias
          },
          // Excluir leads que já agendaram ou foram contatados recentemente (lógica a ser refinada)
          status: 'NEW',
        },
      });
    }

    // Lógica de Gatilho: Lead NoShow (Simulação - precisa de campo no Lead)
    if (trigger === 'LeadNoShow') {
      // Simulação: buscar leads com a tag 'NoShow'
      leadsToTarget = await this.prisma.lead.findMany({
        where: {
          clinicId,
          tags: {
            contains: 'NoShow',
          },
        },
      });
    }

    if (leadsToTarget.length === 0) {
      this.logger.log(`Nenhum lead encontrado para o gatilho ${trigger}.`);
      return { impactedLeads: 0 };
    }

    // 3. Obter a Configuração da Clínica (Necessário para a substituição de variáveis)
    const clinic = await this.prisma.clinic.findUnique({ where: { id: clinicId } });
    if (!clinic) throw new Error('Clínica não encontrada.');

    // 4. Enfileiramento Otimizado (Reutilizando a lógica de createAndSend)
    const jobs = leadsToTarget.map(lead => {
      // Contexto para substituição de variáveis
      const context = { lead, clinic };
      const personalizedMessage = substituteDynamicVariables(template.content, context as any);

      return {
        name: 'send-message',
        data: {
          campanhaId: templateId, // Usando o templateId como referência
          leadId: lead.id,
          message: personalizedMessage,
          phone: lead.phone,
        },
        opts: {
          attempts: 3,
        },
      };
    });

    await this.campanhasQueue.addBulk(jobs);

    this.logger.log(`Campanha Automatizada ${trigger}: ${jobs.length} mensagens enfileiradas.`);

    return {
      impactedLeads: jobs.length,
    };
  }

  /**
   * Otimização de Performance: Enfileira o envio de mensagens em lotes (Método original adaptado).
   * @param dto Dados da campanha.
   * @returns ID da campanha e número de mensagens enfileiradas.
   */
  async createAndSend(dto: CreateCampanhaDto): Promise<{ campanhaId: number; enqueuedCount: number }> {
    // 1. Simulação de Criação da Campanha no DB (em um cenário real, salvaríamos a campanha aqui)
    const campanhaId = Math.floor(Math.random() * 1000) + 1;
    this.logger.log(`Campanha '${dto.name}' criada com ID: ${campanhaId}`);

    // 2. Busca dos Leads (usando Prisma)
    const targetLeads = await this.prisma.lead.findMany({
      where: {
        id: { in: dto.targetLeadIds },
      },
      select: {
        id: true,
        name: true,
        phone: true,
        clinicId: true,
      },
    });

    // 3. Otimização Crítica: Enfileiramento em Lotes
    const jobs = targetLeads.map(async (lead) => {
      // 3. Obter a Configuração da Clínica (Necessário para a substituição de variáveis)
      const clinic = await this.prisma.clinic.findUnique({ where: { id: lead.clinicId } });
      if (!clinic) throw new Error('Clínica não encontrada.');

      // Contexto para substituição de variáveis
      const context = { lead, clinic };
      const personalizedMessage = substituteDynamicVariables(dto.messageTemplate, context as any);

      return {
        name: 'send-message', // Nome do job para o Processor
        data: {
          campanhaId: campanhaId,
          leadId: lead.id,
          message: personalizedMessage,
          phone: lead.phone,
        },
        opts: {
          attempts: 3, // Tentar 3 vezes em caso de falha
        },
      };
    });

    // Adiciona todos os jobs à fila de uma vez
    const resolvedJobs = await Promise.all(jobs);
    await this.campanhasQueue.addBulk(resolvedJobs);

    this.logger.log(`Campanha ${campanhaId}: ${jobs.length} mensagens enfileiradas com sucesso.`);

    return {
      campanhaId,
      enqueuedCount: jobs.length,
    };
  }
}
