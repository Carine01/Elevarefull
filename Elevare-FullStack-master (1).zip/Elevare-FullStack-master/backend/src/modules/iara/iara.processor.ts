import { Processor, Process } from '@nestjs/bull';
import { Logger } from '@nestjs/common';
import { Job } from 'bull';

@Processor('iara-flows')
export class IaraProcessor {
  private readonly logger = new Logger(IaraProcessor.name);

  @Process('send-welcome-message')
  async handleWelcomeMessage(job: Job) {
    this.logger.log(`Enviando mensagem de boas-vindas para lead ${job.data.leadId}`);
    
    // TODO: Integrar com WhatsApp API
    // await this.whatsappService.sendTemplate('welcome_message', {
    //   to: job.data.telefone,
    //   variables: {
    //     nome: job.data.nome,
    //   },
    // });

    return { sent: true };
  }

  @Process('schedule-follow-up')
  async handleFollowUp(job: Job) {
    this.logger.log(`Enviando follow-up para lead ${job.data.leadId}`);
    
    // TODO: Integrar com WhatsApp API
    // await this.whatsappService.sendTemplate('follow_up_message', {
    //   to: job.data.telefone,
    // });

    return { sent: true };
  }

  @Process('notify-clinic')
  async handleClinicNotification(job: Job) {
    this.logger.log(`Notificando clínica ${job.data.clinicId} sobre novo lead`);
    
    // TODO: Integrar com WhatsApp API ou Email
    // await this.whatsappService.sendMessage({
    //   to: clinic.adminPhone,
    //   text: `Novo lead: ${job.data.leadName} (Score: ${job.data.score})`,
    // });

    return { sent: true };
  }
}
