import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { Lead } from '../../database/entities/lead.entity';
import { IaraFlowService } from './iara-flow.service';
import { IaraScoringService } from './iara-scoring.service';
import { IaraTaggingService } from './iara-tagging.service';

export interface LeadQualificationInput {
  nome: string;
  telefone: string;
  email?: string;
  interesse: string;
  origem: string;
  clinicId: string;
}

@Injectable()
export class IaraService {
  private readonly logger = new Logger(IaraService.name);

  constructor(
    @InjectRepository(Lead)
    private readonly leadRepository: Repository<Lead>,
    @InjectQueue('iara-flows')
    private readonly iaraQueue: Queue,
    private readonly flowService: IaraFlowService,
    private readonly scoringService: IaraScoringService,
    private readonly taggingService: IaraTaggingService,
  ) {}

  /**
   * Fluxo principal de qualificação de leads (iara-lead-qualification-v1)
   */
  async qualifyLead(input: LeadQualificationInput): Promise<Lead> {
    this.logger.log(`Iniciando qualificação de lead: ${input.nome}`);

    try {
      // Step 2: Validar dados
      this.validateLeadData(input);

      // Step 3: Calcular score inicial
      const score = await this.scoringService.calculateScore({
        origem: input.origem,
        interesse: input.interesse,
        email: input.email,
      });

      // Step 4: Gerar tags automáticas
      const tags = await this.taggingService.generateTags({
        score,
        interesse: input.interesse,
        origem: input.origem,
      });

      // Step 7: Registrar no banco de dados
      const lead = this.leadRepository.create({
        ...input,
        score,
        tags,
        stage: this.determineStage(score),
      });

      const savedLead = await this.leadRepository.save(lead);

      // Step 5: Enviar mensagem de boas-vindas (assíncrono)
      await this.iaraQueue.add('send-welcome-message', {
        leadId: savedLead.id,
        nome: savedLead.nome,
        telefone: savedLead.telefone,
      });

      // Step 6: Agendar follow-up automático (se score < 40)
      if (score < 40) {
        await this.iaraQueue.add(
          'schedule-follow-up',
          {
            leadId: savedLead.id,
          },
          {
            delay: 3600000, // 1 hora
          },
        );
      }

      // Step 8: Notificar clínica
      await this.iaraQueue.add('notify-clinic', {
        leadId: savedLead.id,
        clinicId: input.clinicId,
        score,
        tags,
      });

      this.logger.log(`Lead qualificado com sucesso: ${savedLead.id}`);
      return savedLead;
    } catch (error) {
      this.logger.error(`Erro ao qualificar lead: ${error.message}`, error.stack);
      throw error;
    }
  }

  /**
   * Validação de dados do lead (Step 2)
   */
  private validateLeadData(input: LeadQualificationInput): void {
    // Validar telefone
    if (!input.telefone || input.telefone.length < 10) {
      throw new Error('Telefone inválido');
    }

    // Validar nome
    if (!input.nome || input.nome.length < 3 || input.nome.length > 100) {
      throw new Error('Nome inválido');
    }

    // Validar email (se fornecido)
    if (input.email && !this.isValidEmail(input.email)) {
      throw new Error('Email inválido');
    }
  }

  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private determineStage(score: number): string {
    if (score >= 40) return 'hot';
    if (score >= 25) return 'warm';
    return 'cold';
  }
}
