import { Injectable } from '@nestjs/common';

interface TaggingInput {
  score: number;
  interesse: string;
  origem: string;
}

@Injectable()
export class IaraTaggingService {
  /**
   * Gera tags automáticas baseadas em score, interesse e origem
   * Implementação do Step 4 do fluxo iara-lead-qualification-v1
   */
  async generateTags(input: TaggingInput): Promise<string[]> {
    const tags: string[] = [];

    // Tags baseadas em score
    if (input.score >= 40) {
      tags.push('hot_lead');
    } else if (input.score >= 25) {
      tags.push('warm_lead');
    } else {
      tags.push('cold_lead');
    }

    // Tags baseadas em interesse
    if (input.interesse.toLowerCase().includes('depilacao_laser')) {
      tags.push('depilacao');
    }
    if (input.interesse.toLowerCase().includes('botox')) {
      tags.push('botox');
    }
    if (input.interesse.toLowerCase().includes('preenchimento')) {
      tags.push('preenchimento');
    }

    // Tags baseadas em origem
    if (input.origem.toLowerCase() === 'indicacao') {
      tags.push('vip');
    }

    return tags;
  }
}
