import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BullModule } from '@nestjs/bull';
import { IaraService } from './iara.service';
import { IaraController } from './iara.controller';
import { IaraFlowService } from './iara-flow.service';
import { IaraScoringService } from './iara-scoring.service';
import { IaraTaggingService } from './iara-tagging.service';
import { IaraProcessor } from './iara.processor';
import { Lead } from '../../database/entities/lead.entity';
import { Mensagem } from '../../database/entities/mensagem.entity';
import { WhatsappModule } from '../whatsapp/whatsapp.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Lead, Mensagem]),
    BullModule.registerQueue({
      name: 'iara-flows',
    }),
    WhatsappModule,
  ],
  controllers: [IaraController],
  providers: [
    IaraService,
    IaraFlowService,
    IaraScoringService,
    IaraTaggingService,
    IaraProcessor,
  ],
  exports: [IaraService, IaraFlowService],
})
export class IaraModule {}
