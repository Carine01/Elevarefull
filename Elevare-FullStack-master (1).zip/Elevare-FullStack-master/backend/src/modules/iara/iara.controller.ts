import { Controller, Post, Body, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { IaraService, LeadQualificationInput } from './iara.service';

@ApiTags('IARA - Automação de Leads')
@Controller('iara')
export class IaraController {
  constructor(private readonly iaraService: IaraService) {}

  @Post('qualify-lead')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Qualificar novo lead (Fluxo IARA v1.0)' })
  @ApiResponse({ status: 201, description: 'Lead qualificado com sucesso' })
  @ApiResponse({ status: 400, description: 'Dados inválidos' })
  async qualifyLead(@Body() input: LeadQualificationInput) {
    return this.iaraService.qualifyLead(input);
  }
}
