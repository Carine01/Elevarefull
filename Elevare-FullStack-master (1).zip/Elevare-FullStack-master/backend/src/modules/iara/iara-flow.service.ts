import { Injectable, Logger } from '@nestjs/common';

/**
 * Serviço responsável por gerenciar os fluxos IARA
 * Baseado em IARA_LARA_FLUXOS.md
 */
@Injectable()
export class IaraFlowService {
  private readonly logger = new Logger(IaraFlowService.name);

  /**
   * Retorna a definição do fluxo de qualificação de leads
   */
  getLeadQualificationFlow() {
    return {
      id: 'iara-lead-qualification-v1',
      name: 'IARA - Qualificação de Leads',
      description: 'Fluxo automático de qualificação de leads via WhatsApp',
      version: '1.0',
      trigger: 'new_lead_received',
      steps: [
        {
          id: 'step-1',
          name: 'Receber Lead',
          type: 'webhook',
          action: 'POST /webhooks/leads',
        },
        {
          id: 'step-2',
          name: 'Validar Dados',
          type: 'validation',
        },
        {
          id: 'step-3',
          name: 'Calcular Score Inicial',
          type: 'scoring',
        },
        {
          id: 'step-4',
          name: 'Gerar Tags Automáticas',
          type: 'tagging',
        },
        {
          id: 'step-5',
          name: 'Enviar Mensagem de Boas-vindas',
          type: 'send_message',
          channel: 'whatsapp',
        },
        {
          id: 'step-6',
          name: 'Agendar Follow-up Automático',
          type: 'schedule_message',
        },
        {
          id: 'step-7',
          name: 'Registrar no Banco de Dados',
          type: 'database',
        },
        {
          id: 'step-8',
          name: 'Notificar Clínica',
          type: 'send_message',
        },
      ],
    };
  }

  /**
   * Retorna a definição do fluxo de agendamento
   */
  getSchedulingFlow() {
    return {
      id: 'iara-scheduling-flow-v1',
      name: 'IARA - Fluxo de Agendamento',
      description: 'Fluxo automático de agendamento via WhatsApp',
      version: '1.0',
      trigger: 'lead_ready_for_scheduling',
      steps: [
        {
          id: 'step-1',
          name: 'Verificar Disponibilidade',
          type: 'check_availability',
        },
        {
          id: 'step-2',
          name: 'Enviar Opções de Agendamento',
          type: 'send_message',
        },
        {
          id: 'step-3',
          name: 'Aguardar Resposta do Lead',
          type: 'wait_for_input',
        },
        {
          id: 'step-4',
          name: 'Processar Seleção',
          type: 'conditional',
        },
        {
          id: 'step-5',
          name: 'Coletar Data/Hora Customizada',
          type: 'collect_input',
        },
        {
          id: 'step-6',
          name: 'Confirmar Agendamento',
          type: 'create_appointment',
        },
        {
          id: 'step-7',
          name: 'Enviar Confirmação ao Lead',
          type: 'send_message',
        },
        {
          id: 'step-8',
          name: 'Agendar Lembretes',
          type: 'schedule_messages',
        },
      ],
    };
  }
}
