import { Injectable } from '@nestjs/common';

interface ScoringInput {
  origem: string;
  interesse: string;
  email?: string;
}

interface ScoringBreakdown {
  origemScore: number;
  interesseScore: number;
  emailScore: number;
  total: number;
}

@Injectable()
export class IaraScoringService {
  private readonly origemScores = {
    google: 30,
    facebook: 25,
    instagram: 20,
    indicacao: 40,
    website: 35,
    whatsapp: 15,
  };

  private readonly interesseScores = {
    depilacao_laser: 50,
    botox: 45,
    preenchimento: 40,
    limpeza_pele: 30,
    outros: 20,
  };

  /**
   * Calcula o score de um lead baseado em origem, interesse e email
   * Implementação do Step 3 do fluxo iara-lead-qualification-v1
   */
  async calculateScore(input: ScoringInput): Promise<number> {
    const breakdown = this.getScoreBreakdown(input);
    return breakdown.total;
  }

  /**
   * Retorna o detalhamento do score
   */
  getScoreBreakdown(input: ScoringInput): ScoringBreakdown {
    const origemScore = this.origemScores[input.origem.toLowerCase()] || 10;
    const interesseScore = this.interesseScores[input.interesse.toLowerCase()] || 15;
    const emailScore = input.email ? 10 : 0;

    return {
      origemScore,
      interesseScore,
      emailScore,
      total: origemScore + interesseScore + emailScore,
    };
  }
}
