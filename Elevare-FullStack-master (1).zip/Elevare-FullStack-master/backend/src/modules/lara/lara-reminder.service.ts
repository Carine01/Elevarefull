import { Injectable, Logger } from '@nestjs/common';

@Injectable()
export class LaraReminderService {
  private readonly logger = new Logger(LaraReminderService.name);

  /**
   * Envia lembrete 24h antes do agendamento
   */
  async sendReminder24h(agendamentoId: string, leadId: string): Promise<void> {
    this.logger.log(`Enviando lembrete 24h para agendamento ${agendamentoId}`);
    
    // TODO: Integrar com WhatsApp API
    // await this.whatsappService.sendTemplate('appointment_reminder_24h', {
    //   to: lead.telefone,
    //   variables: {
    //     nome: lead.nome,
    //     data: agendamento.dataHora,
    //     procedimento: agendamento.procedimento,
    //   },
    // });
  }

  /**
   * Envia lembrete 1h antes do agendamento
   */
  async sendReminder1h(agendamentoId: string, leadId: string): Promise<void> {
    this.logger.log(`Enviando lembrete 1h para agendamento ${agendamentoId}`);
    
    // TODO: Integrar com WhatsApp API
    // await this.whatsappService.sendTemplate('appointment_reminder_1h', {
    //   to: lead.telefone,
    //   variables: {
    //     nome: lead.nome,
    //     data: agendamento.dataHora,
    //   },
    // });
  }
}
