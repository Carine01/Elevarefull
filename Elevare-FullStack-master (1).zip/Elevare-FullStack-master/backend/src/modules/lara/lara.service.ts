import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { Agendamento } from '../../database/entities/agendamento.entity';
import { LaraReminderService } from './lara-reminder.service';
import { LaraFeedbackService } from './lara-feedback.service';

@Injectable()
export class LaraService {
  private readonly logger = new Logger(LaraService.name);

  constructor(
    @InjectRepository(Agendamento)
    private readonly agendamentoRepository: Repository<Agendamento>,
    @InjectQueue('lara-reminders')
    private readonly laraQueue: Queue,
    private readonly reminderService: LaraReminderService,
    private readonly feedbackService: LaraFeedbackService,
  ) {}

  /**
   * Agenda lembretes automáticos para um agendamento
   * Implementação do fluxo lara-appointment-reminder-v1
   */
  async scheduleReminders(agendamentoId: string): Promise<void> {
    this.logger.log(`Agendando lembretes para agendamento ${agendamentoId}`);

    const agendamento = await this.agendamentoRepository.findOne({
      where: { id: agendamentoId },
      relations: ['lead'],
    });

    if (!agendamento) {
      throw new Error(`Agendamento ${agendamentoId} não encontrado`);
    }

    const appointmentDate = new Date(agendamento.dataHora);
    const now = new Date();

    // Lembrete 24h antes
    const reminder24h = new Date(appointmentDate.getTime() - 24 * 60 * 60 * 1000);
    if (reminder24h > now) {
      await this.laraQueue.add(
        'send-reminder-24h',
        {
          agendamentoId,
          leadId: agendamento.leadId,
        },
        {
          delay: reminder24h.getTime() - now.getTime(),
        },
      );
    }

    // Lembrete 1h antes
    const reminder1h = new Date(appointmentDate.getTime() - 60 * 60 * 1000);
    if (reminder1h > now) {
      await this.laraQueue.add(
        'send-reminder-1h',
        {
          agendamentoId,
          leadId: agendamento.leadId,
        },
        {
          delay: reminder1h.getTime() - now.getTime(),
        },
      );
    }

    this.logger.log(`Lembretes agendados para ${agendamentoId}`);
  }

  /**
   * Agenda coleta de feedback após o agendamento
   * Implementação do fluxo lara-feedback-collection-v1
   */
  async scheduleFeedbackCollection(agendamentoId: string): Promise<void> {
    this.logger.log(`Agendando coleta de feedback para ${agendamentoId}`);

    const agendamento = await this.agendamentoRepository.findOne({
      where: { id: agendamentoId },
    });

    if (!agendamento) {
      throw new Error(`Agendamento ${agendamentoId} não encontrado`);
    }

    const appointmentDate = new Date(agendamento.dataHora);
    const feedbackDate = new Date(appointmentDate.getTime() + 2 * 60 * 60 * 1000); // 2h depois
    const now = new Date();

    if (feedbackDate > now) {
      await this.laraQueue.add(
        'collect-feedback',
        {
          agendamentoId,
          leadId: agendamento.leadId,
        },
        {
          delay: feedbackDate.getTime() - now.getTime(),
        },
      );
    }

    this.logger.log(`Coleta de feedback agendada para ${agendamentoId}`);
  }
}
