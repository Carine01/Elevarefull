import { Controller, Post, Param, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { LaraService } from './lara.service';

@ApiTags('LARA - Automação de Agendamentos')
@Controller('lara')
export class LaraController {
  constructor(private readonly laraService: LaraService) {}

  @Post('schedule-reminders/:agendamentoId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Agendar lembretes automáticos (Fluxo LARA v1.0)' })
  @ApiResponse({ status: 200, description: 'Lembretes agendados com sucesso' })
  async scheduleReminders(@Param('agendamentoId') agendamentoId: string) {
    await this.laraService.scheduleReminders(agendamentoId);
    return { message: 'Lembretes agendados com sucesso' };
  }

  @Post('schedule-feedback/:agendamentoId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Agendar coleta de feedback (Fluxo LARA v1.0)' })
  @ApiResponse({ status: 200, description: 'Coleta de feedback agendada' })
  async scheduleFeedback(@Param('agendamentoId') agendamentoId: string) {
    await this.laraService.scheduleFeedbackCollection(agendamentoId);
    return { message: 'Coleta de feedback agendada com sucesso' };
  }
}
