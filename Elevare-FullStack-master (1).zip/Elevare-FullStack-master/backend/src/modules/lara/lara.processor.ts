import { Processor, Process } from '@nestjs/bull';
import { Logger } from '@nestjs/common';
import { Job } from 'bull';
import { LaraReminderService } from './lara-reminder.service';
import { LaraFeedbackService } from './lara-feedback.service';

@Processor('lara-reminders')
export class LaraProcessor {
  private readonly logger = new Logger(LaraProcessor.name);

  constructor(
    private readonly reminderService: LaraReminderService,
    private readonly feedbackService: LaraFeedbackService,
  ) {}

  @Process('send-reminder-24h')
  async handleReminder24h(job: Job) {
    this.logger.log(`Processando lembrete 24h para ${job.data.agendamentoId}`);
    await this.reminderService.sendReminder24h(
      job.data.agendamentoId,
      job.data.leadId,
    );
    return { sent: true };
  }

  @Process('send-reminder-1h')
  async handleReminder1h(job: Job) {
    this.logger.log(`Processando lembrete 1h para ${job.data.agendamentoId}`);
    await this.reminderService.sendReminder1h(
      job.data.agendamentoId,
      job.data.leadId,
    );
    return { sent: true };
  }

  @Process('collect-feedback')
  async handleFeedbackCollection(job: Job) {
    this.logger.log(`Coletando feedback para ${job.data.agendamentoId}`);
    await this.feedbackService.collectFeedback(
      job.data.agendamentoId,
      job.data.leadId,
    );
    return { sent: true };
  }
}
