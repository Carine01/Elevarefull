import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BullModule } from '@nestjs/bull';
import { LaraService } from './lara.service';
import { LaraController } from './lara.controller';
import { LaraReminderService } from './lara-reminder.service';
import { LaraFeedbackService } from './lara-feedback.service';
import { LaraProcessor } from './lara.processor';
import { Agendamento } from '../../database/entities/agendamento.entity';
import { Mensagem } from '../../database/entities/mensagem.entity';
import { WhatsappModule } from '../whatsapp/whatsapp.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Agendamento, Mensagem]),
    BullModule.registerQueue({
      name: 'lara-reminders',
    }),
    WhatsappModule,
  ],
  controllers: [LaraController],
  providers: [
    LaraService,
    LaraReminderService,
    LaraFeedbackService,
    LaraProcessor,
  ],
  exports: [LaraService],
})
export class LaraModule {}
