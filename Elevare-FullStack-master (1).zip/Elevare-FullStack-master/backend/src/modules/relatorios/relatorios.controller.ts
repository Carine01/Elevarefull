import { Controller, Get, Query, HttpStatus } from '@nestjs/common';
import { RelatoriosService } from './relatorios.service';
import { RelatorioFilterDto } from './dto/relatorio-filter.dto';

@Controller('relatorios')
// @UseGuards(AuthGuard('jwt')) // Proteção do endpoint
export class RelatoriosController {
  constructor(private readonly relatoriosService: RelatoriosService) {}

  @Get('conversao')
  async getConversaoReport(@Query() filter: RelatorioFilterDto): Promise<any> {
    const report = await this.relatoriosService.getConversaoReport(filter);
    return {
      statusCode: HttpStatus.OK,
      data: report,
    };
  }

  @Get('no-show')
  async getNoShowReport(@Query() filter: RelatorioFilterDto): Promise<any> {
    const report = await this.relatoriosService.getNoShowReport(filter);
    return {
      statusCode: HttpStatus.OK,
      data: report,
    };
  }

  @Get('volume-mensagens')
  async getMensagensVolume(@Query() filter: RelatorioFilterDto) {
    const report = await this.relatoriosService.getMensagensVolume(filter);
    return {
      statusCode: HttpStatus.OK,
      data: report,
    };
  }
}
