// backend/src/modules/relatorios/dto/relatorio-filter.dto.ts

import { IsOptional, IsDateString, IsNumberString } from 'class-validator';

export class RelatorioFilterDto {
  @IsOptional()
  @IsDateString()
  startDate?: string; // Data de início do período

  @IsOptional()
  @IsDateString()
  endDate?: string; // Data de fim do período

  @IsOptional()
  @IsNumberString()
  clinicId?: string; // Filtro por ID da clínica
}
