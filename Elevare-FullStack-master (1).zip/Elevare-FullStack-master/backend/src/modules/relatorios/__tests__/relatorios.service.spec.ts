// backend/src/modules/relatorios/__tests__/relatorios.service.spec.ts

import { Test, TestingModule } from '@nestjs/testing';
import { RelatoriosService } from '../relatorios.service';
import { RelatorioFilterDto } from '../dto/relatorio-filter.dto';
import { Logger } from '@nestjs/common';

describe('RelatoriosService', () => {
  let service: RelatoriosService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [RelatoriosService],
    }).compile();

    service = module.get<RelatoriosService>(RelatoriosService);

    // Mock do Logger
    jest.spyOn(Logger.prototype, 'log').mockImplementation(() => {});
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  const filter: RelatorioFilterDto = {
    startDate: '2025-01-01',
    endDate: '2025-01-31',
    clinicId: '1',
  };

  describe('getConversaoReport', () => {
    it('should return the conversion report with correct calculation', async () => {
      const report = await service.getConversaoReport(filter);
      // Mock data: totalLeads: 1500, agendados: 500. Taxa = 500/1500 * 100 = 33.333...
      expect(report.totalLeads).toBe(1500);
      expect(report.agendados).toBe(500);
      expect(report.taxaConversao).toBe(33.33); // Arredondado para 2 casas decimais
    });
  });

  describe('getNoShowReport', () => {
    it('should return the no-show report with correct calculation', async () => {
      const report = await service.getNoShowReport(filter);
      // Mock data: totalAgendamentos: 800, noShow: 80. Taxa = 80/800 * 100 = 10.00
      expect(report.totalAgendamentos).toBe(800);
      expect(report.noShow).toBe(80);
      expect(report.taxaNoShow).toBe(10.0);
    });
  });

  describe('getMensagensVolume', () => {
    it('should return the message volume report', async () => {
      const report = await service.getMensagensVolume(filter);
      // Mock data: mensagensEnviadas: 12000
      expect(report.volume).toBe(12000);
    });
  });
});
