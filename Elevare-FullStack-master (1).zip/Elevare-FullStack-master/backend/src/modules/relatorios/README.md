# Módulo de Relatórios

Este módulo é o ponto de coleta de dados para a **tomada de decisão** e análise de performance do Elevare. Ele fornece endpoints para gerar relatórios de performance baseados em filtros de tempo e clínica.

## Funcionalidades

- **Relatório de Conversão:** Mede a eficácia do funil (Leads -> Agendamentos).
- **Relatório de No-Show:** Mede a taxa de agendamentos perdidos.
- **Relatório de Volume de Mensagens:** Mede a atividade de comunicação.

## Endpoints

| Método | Rota | Descrição |
| :--- | :--- | :--- |
| `GET` | `/relatorios/conversao` | Retorna a taxa de conversão (Leads -> Agendamentos). |
| `GET` | `/relatorios/no-show` | Retorna a taxa de no-show (Agendamentos Perdidos). |
| `GET` | `/relatorios/volume-mensagens` | Retorna o volume total de mensagens enviadas. |

## Filtros (Query Parameters)

Todos os endpoints de relatório aceitam os seguintes filtros:

### `RelatorioFilterDto`

| Campo | Tipo | Obrigatório | Descrição |
| :--- | :--- | :--- | :--- |
| `startDate` | `string` (ISO Date) | Não | Data de início do período. |
| `endDate` | `string` (ISO Date) | Não | Data de fim do período. |
| `clinicId` | `string` (Number) | Não | Filtro por ID da clínica. |
