import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from 'src/shared/prisma.service';
import { RelatorioFilterDto } from './dto/relatorio-filter.dto';

// Simulação de Estruturas de Relatório
interface ConversaoReport {
  totalLeads: number;
  agendados: number;
  taxaConversao: number; // %
}

interface NoShowReport {
  totalAgendamentos: number;
  noShow: number;
  taxaNoShow: number; // %
}

@Injectable()
export class RelatoriosService {
  private readonly logger = new Logger(RelatoriosService.name);

  constructor(private prisma: PrismaService) {}

  // Relatório de Conversão (Leads -> Agendamentos)
  async getConversaoReport(filter: RelatorioFilterDto): Promise<ConversaoReport> {
    this.logger.log(`Gerando Relatório de Conversão com filtro: ${JSON.stringify(filter)}`);
    
    // 1. Contar Leads (Total de Leads)
    const totalLeads = await this.prisma.lead.count({
      where: {
        createdAt: {
          gte: filter.startDate ? new Date(filter.startDate) : undefined,
          lte: filter.endDate ? new Date(filter.endDate) : undefined,
        },
        // Adicionar filtro por clínica se necessário
      },
    });

    // 2. Contar Agendamentos (Leads que viraram Agendamentos)
    // Em um cenário real, faríamos um JOIN ou buscaríamos leads com agendamentos
    // Aqui, simulamos a contagem de agendamentos criados no período
    const agendados = await this.prisma.agendamento.count({
      where: {
        createdAt: {
          gte: filter.startDate ? new Date(filter.startDate) : undefined,
          lte: filter.endDate ? new Date(filter.endDate) : undefined,
        },
        // Adicionar filtro por clínica se necessário
      },
    });

    const taxaConversao = totalLeads > 0 ? (agendados / totalLeads) * 100 : 0;

    return {
      totalLeads,
      agendados,
      taxaConversao: parseFloat(taxaConversao.toFixed(2)),
    };
  }

  // Relatório de No-Show (Agendamentos Perdidos)
  async getNoShowReport(filter: RelatorioFilterDto): Promise<NoShowReport> {
    this.logger.log(`Gerando Relatório de No-Show com filtro: ${JSON.stringify(filter)}`);

    // 1. Contar Total de Agendamentos
    const totalAgendamentos = await this.prisma.agendamento.count({
      where: {
        createdAt: {
          gte: filter.startDate ? new Date(filter.startDate) : undefined,
          lte: filter.endDate ? new Date(filter.endDate) : undefined,
        },
      },
    });

    // 2. Contar No-Show (Simulamos que 'CANCELED' é No-Show)
    const noShow = await this.prisma.agendamento.count({
      where: {
        status: 'CANCELED', // Em um cenário real, seria um status específico de No-Show
        createdAt: {
          gte: filter.startDate ? new Date(filter.startDate) : undefined,
          lte: filter.endDate ? new Date(filter.endDate) : undefined,
        },
      },
    });

    const taxaNoShow = totalAgendamentos > 0 ? (noShow / totalAgendamentos) * 100 : 0;

    return {
      totalAgendamentos,
      noShow,
      taxaNoShow: parseFloat(taxaNoShow.toFixed(2)),
    };
  }

  // Relatório de Volume de Mensagens
  async getMensagensVolume(filter: RelatorioFilterDto): Promise<{ volume: number }> {
    this.logger.log(`Gerando Relatório de Volume de Mensagens com filtro: ${JSON.stringify(filter)}`);
    
    const volume = await this.prisma.mensagem.count({
      where: {
        createdAt: {
          gte: filter.startDate ? new Date(filter.startDate) : undefined,
          lte: filter.endDate ? new Date(filter.endDate) : undefined,
        },
      },
    });

    return {
      volume,
    };
  }
}
