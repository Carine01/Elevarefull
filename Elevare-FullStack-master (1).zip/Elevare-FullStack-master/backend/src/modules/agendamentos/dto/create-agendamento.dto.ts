// backend/src/modules/agendamentos/dto/create-agendamento.dto.ts

import { IsNotEmpty, IsDateString, IsNumber, IsString } from 'class-validator';

export class CreateAgendamentoDto {
  @IsNotEmpty()
  @IsDateString()
  startTime!: string; // Data e hora de início do agendamento

  @IsNotEmpty()
  @IsDateString()
  endTime!: string; // Data e hora de fim do agendamento

  @IsNumber()
  @IsNotEmpty()
  clientId!: number; // ID do cliente

  @IsNumber()
  @IsNotEmpty()
  professionalId!: number; // ID do profissional

  @IsString()
  @IsNotEmpty()
  service!: string; // Tipo de serviço agendado
}
