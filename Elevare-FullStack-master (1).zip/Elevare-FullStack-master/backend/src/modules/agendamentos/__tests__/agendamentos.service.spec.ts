// backend/src/modules/agendamentos/__tests__/agendamentos.service.spec.ts

import { Test, TestingModule } from '@nestjs/testing';
import { AgendamentosService } from '../agendamentos.service';
import { CreateAgendamentoDto } from '../dto/create-agendamento.dto';
import { ConflictException, Logger } from '@nestjs/common';
import { getQueueToken } from '@nestjs/bull';

// Mock da Fila Bull
const mockQueue = {
  add: jest.fn(),
};

describe('AgendamentosService', () => {
  let service: AgendamentosService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AgendamentosService,
        {
          provide: getQueueToken('agendamentos'),
          useValue: mockQueue,
        },
      ],
    }).compile();

    service = module.get<AgendamentosService>(AgendamentosService);

    // Mock do Logger
    jest.spyOn(Logger.prototype, 'log').mockImplementation(() => {});
    jest.spyOn(Logger.prototype, 'warn').mockImplementation(() => {});

    // Limpar a simulação de DB antes de cada teste
    (service as any).mockAgendamentos.length = 0;
    mockQueue.add.mockClear();
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  const baseDto: CreateAgendamentoDto = {
    startTime: '2025-12-01T10:00:00.000Z',
    endTime: '2025-12-01T11:00:00.000Z',
    clientId: 1,
    professionalId: 5,
    service: 'Consulta',
  };

  describe('create', () => {
    it('should create an agendamento and enqueue a reminder', async () => {
      const agendamento = await service.create(baseDto);

      expect(agendamento).toBeDefined();
      expect(agendamento.professionalId).toBe(5);
      expect((service as any).mockAgendamentos.length).toBe(1);

      // Verifica se o job de lembrete foi enfileirado
      expect(mockQueue.add).toHaveBeenCalledWith(
        'send-reminder',
        expect.objectContaining({ agendamentoId: agendamento.id }),
        expect.objectContaining({ jobId: `reminder-${agendamento.id}` }),
      );
    });

    it('should throw ConflictException if a conflict is detected', async () => {
      // 1. Cria o primeiro agendamento (ocupa 10:00 - 11:00)
      await service.create(baseDto);

      // 2. Tenta criar um agendamento conflitante (10:30 - 11:30)
      const conflictingDto: CreateAgendamentoDto = {
        ...baseDto,
        startTime: '2025-12-01T10:30:00.000Z',
        endTime: '2025-12-01T11:30:00.000Z',
      };

      await expect(service.create(conflictingDto)).rejects.toThrow(
        ConflictException,
      );
      expect((service as any).mockAgendamentos.length).toBe(1); // Garante que o segundo não foi salvo
    });

    it('should NOT throw ConflictException if there is no conflict', async () => {
      // 1. Cria o primeiro agendamento (ocupa 10:00 - 11:00)
      await service.create(baseDto);

      // 2. Tenta criar um agendamento sem conflito (11:00 - 12:00)
      const nonConflictingDto: CreateAgendamentoDto = {
        ...baseDto,
        startTime: '2025-12-01T11:00:00.000Z',
        endTime: '2025-12-01T12:00:00.000Z',
      };

      await expect(service.create(nonConflictingDto)).resolves.toBeDefined();
      expect((service as any).mockAgendamentos.length).toBe(2);
    });

    it('should NOT throw ConflictException if the conflict is with a different professional', async () => {
      // 1. Cria o primeiro agendamento (Profissional 5, 10:00 - 11:00)
      await service.create(baseDto);

      // 2. Tenta criar um agendamento no mesmo horário, mas com outro profissional (Profissional 6)
      const differentProfessionalDto: CreateAgendamentoDto = {
        ...baseDto,
        professionalId: 6,
      };

      await expect(service.create(differentProfessionalDto)).resolves.toBeDefined();
      expect((service as any).mockAgendamentos.length).toBe(2);
    });
  });
});
