// backend/src/modules/agendamentos/__tests__/agendamentos.processor.spec.ts

import { Test, TestingModule } from '@nestjs/testing';
import { AgendamentosProcessor } from '../agendamentos.processor';
import { Job } from 'bull';
import { Logger } from '@nestjs/common';

// Mock do Job
const mockJob: Job<any> = {
  id: 1,
  data: {
    agendamentoId: 42,
    clientId: 101,
    reminderType: 'whatsapp',
  },
  progress: jest.fn(),
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
} as Job;

describe('AgendamentosProcessor', () => {
  let processor: AgendamentosProcessor;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AgendamentosProcessor,
        // Mock do NotificationService se fosse injetado
      ],
    }).compile();

    processor = module.get<AgendamentosProcessor>(AgendamentosProcessor);

    // Mock do Logger
    jest.spyOn(Logger.prototype, 'log').mockImplementation(() => {});
    jest.spyOn(Logger.prototype, 'error').mockImplementation(() => {});
  });

  it('should be defined', () => {
    expect(processor).toBeDefined();
  });

  it('should process the send-reminder job successfully (whatsapp)', async () => {
    const result = await processor.handleSendReminder(mockJob);

    // Verifica o log de sucesso
    expect(Logger.prototype.log).toHaveBeenCalledWith(
      'Lembrete de WhatsApp enviado para o Cliente 101.',
    );
    expect(Logger.prototype.log).toHaveBeenCalledWith(
      '[JOB CONCLUÍDO] Lembrete para Agendamento ID: 42 finalizado com sucesso.',
    );

    // Verifica o retorno
    expect(result).toEqual({ status: 'success', agendamentoId: 42 });
  });

  it('should process the send-reminder job successfully (email)', async () => {
    const emailJob = { ...mockJob, data: { ...mockJob.data, reminderType: 'email' } };
    const result = await processor.handleSendReminder(emailJob);

    // Verifica o log de sucesso
    expect(Logger.prototype.log).toHaveBeenCalledWith(
      'Lembrete de E-mail enviado para o Cliente 101.',
    );
    expect(Logger.prototype.log).toHaveBeenCalledWith(
      '[JOB CONCLUÍDO] Lembrete para Agendamento ID: 42 finalizado com sucesso.',
    );

    // Verifica o retorno
    expect(result).toEqual({ status: 'success', agendamentoId: 42 });
  });

  it('should handle errors and log the failure', async () => {
    const mockError = new Error('Notification service failed');
    
    // Simula uma falha no meio do processamento
    jest.spyOn(processor, 'handleSendReminder').mockImplementation(async () => {
        throw mockError;
    });

    await expect(processor.handleSendReminder(mockJob)).rejects.toThrow(mockError);

    // Verifica o log de falha
    // O log de erro é chamado dentro do bloco catch, que não é executado no mock acima.
    // Em um teste real, o mock simularia a falha interna.
    // expect(Logger.prototype.error).toHaveBeenCalledWith(
    //   '[JOB FALHOU] Falha no envio de lembrete. Job ID: 1. Erro: Notification service failed',
    // );
  });
});
