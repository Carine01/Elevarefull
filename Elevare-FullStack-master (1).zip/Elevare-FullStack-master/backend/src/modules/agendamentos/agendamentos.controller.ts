// backend/src/modules/agendamentos/agendamentos.controller.ts

import { Controller, Post, Body, UseGuards, HttpStatus } from '@nestjs/common';
import { AgendamentosService } from './agendamentos.service';
import { CreateAgendamentoDto } from './dto/create-agendamento.dto';
// import { AuthGuard } from '@nestjs/passport'; // Assumindo que o AuthGuard é usado
// import { CsrfGuard } from '../../common/csrf.guard'; // Assumindo que o CsrfGuard é usado

@Controller('agendamentos')
// @UseGuards(AuthGuard('jwt')) // Proteção do endpoint
export class AgendamentosController {
  constructor(private readonly agendamentosService: AgendamentosService) {}

  @Post()
  // @UseGuards(CsrfGuard) // Proteção contra CSRF (rotas mutáveis)
  async create(@Body() createAgendamentoDto: CreateAgendamentoDto) {
    const agendamento = await this.agendamentosService.create(
      createAgendamentoDto,
    );

    return {
      statusCode: HttpStatus.CREATED,
      message: 'Agendamento criado com sucesso.',
      data: agendamento,
    };
  }
}
