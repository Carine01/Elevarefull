# Módulo de Agendamentos (AgendamentosModule)

Este módulo gerencia a criação e o ciclo de vida dos agendamentos, com foco em garantir a **integridade dos dados** e a **confiabilidade das notificações**.

## Otimizações de Funcionalidade Implementadas

O módulo foi refatorado para ser **à prova de erros** e de alta performance, focando em:

### 1. Validação de Conflitos de Horário

- **Endpoint:** `POST /agendamentos`
- **Funcionalidade:** Antes de salvar um novo agendamento, o sistema verifica se o `professionalId` já possui um agendamento que se sobreponha ao período solicitado (`startTime` e `endTime`).
- **Benefício:** **Elimina erros operacionais** e garante que o mesmo profissional não seja agendado duas vezes no mesmo horário.
- **Resposta:** Em caso de conflito, retorna um erro `409 Conflict`.

### 2. Notificações Assíncronas (Lembretes)

- **Funcionalidade:** O envio de lembretes de agendamento é delegado a um Worker em segundo plano.
- **Enfileiramento Inteligente:** O job de lembrete é enfileirado com um **delay** calculado para ser executado **exatamente 24 horas antes** do agendamento.
- **Tecnologia:** **Bull/Redis** (configurado no `AppModule`).
- **Benefício:** **Reduz o *no-show*** (faltas) e garante que a criação do agendamento seja instantânea, pois o envio da notificação não a atrasa.

## Como Testar

### 1. Testes de Unidade (Lógica de Conflito)

Para validar a lógica de conflito e o enfileiramento:

```bash
# Assumindo que você está no diretório backend/
# Rode os testes específicos do módulo Agendamentos
npm run test -- src/modules/agendamentos
```

### 2. Teste de Conflito (Smoke Test)

Para testar a validação de conflito:

```bash
# 1. Crie o primeiro agendamento (10:00 - 11:00)
curl -X POST "http://localhost:3000/agendamentos" \
  -H "Content-Type: application/json" \
  -d '{"startTime": "2025-12-01T10:00:00.000Z", "endTime": "2025-12-01T11:00:00.000Z", "clientId": 1, "professionalId": 5, "service": "Consulta"}'
  
# Resposta esperada: 201 Created

# 2. Tente criar um agendamento conflitante (10:30 - 11:30) para o mesmo profissional (ID 5)
curl -X POST "http://localhost:3000/agendamentos" \
  -H "Content-Type: application/json" \
  -d '{"startTime": "2025-12-01T10:30:00.000Z", "endTime": "2025-12-01T11:30:00.000Z", "clientId": 2, "professionalId": 5, "service": "Retorno"}'

# Resposta esperada: 409 Conflict (Conflito de horário)
```
