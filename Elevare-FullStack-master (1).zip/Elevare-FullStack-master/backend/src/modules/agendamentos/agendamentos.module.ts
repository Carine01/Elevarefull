// backend/src/modules/agendamentos/agendamentos.module.ts

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AgendamentosService } from './agendamentos.service';
import { AgendamentosProcessor } from './agendamentos.processor';
import { AgendamentosController } from './agendamentos.controller';
import { BullModule } from '@nestjs/bull';

@Module({
  imports: [
    // TypeOrmModule.forFeature([Agendamento]),
    BullModule.registerQueue({
      name: 'agendamentos', // Nome da fila para o AgendamentosWorker
    }),
  ],
  controllers: [AgendamentosController],
  providers: [AgendamentosService, AgendamentosProcessor],
  exports: [AgendamentosService],
})
export class AgendamentosModule {}
