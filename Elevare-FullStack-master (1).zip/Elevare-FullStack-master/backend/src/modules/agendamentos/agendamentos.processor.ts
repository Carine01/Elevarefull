// backend/src/modules/agendamentos/agendamentos.processor.ts

import { Process, Processor } from '@nestjs/bull';
import { Logger } from '@nestjs/common';
import { Job } from 'bull';

// Simulação de Job para Envio de Lembrete
interface SendReminderJob {
  agendamentoId: number;
  clientId: number;
  reminderType: 'whatsapp' | 'email';
}

@Processor('agendamentos') // Processador para a fila 'agendamentos'
export class AgendamentosProcessor {
  private readonly logger = new Logger(AgendamentosProcessor.name);

  // constructor(private readonly notificationService: NotificationService) {}

  /**
   * Processa o Job de Envio de Lembrete.
   * Esta é uma tarefa que deve rodar em background (ex: 24h antes do agendamento).
   */
  @Process('send-reminder') // Nome do Job
  async handleSendReminder(job: Job<SendReminderJob>) {
    this.logger.log(`[JOB INICIADO] Enviando lembrete para Agendamento ID: ${job.data.agendamentoId}, Cliente: ${job.data.clientId}`);

    const { agendamentoId, clientId, reminderType } = job.data;

    try {
      // 1. Simulação de Busca de Dados do Agendamento e Cliente
      // const agendamento = await this.agendamentosService.findById(agendamentoId);
      // const client = await this.clientService.findById(clientId);

      // 2. Simulação de Envio (e-mail ou WhatsApp)
      if (reminderType === 'whatsapp') {
        // await this.notificationService.sendWhatsappReminder(client.phone, agendamento.details);
        this.logger.log(`Lembrete de WhatsApp enviado para o Cliente ${clientId}.`);
      } else if (reminderType === 'email') {
        // await this.notificationService.sendEmailReminder(client.email, agendamento.details);
        this.logger.log(`Lembrete de E-mail enviado para o Cliente ${clientId}.`);
      }

      // Simulação de processamento
      await new Promise(resolve => setTimeout(resolve, 500)); 

      this.logger.log(`[JOB CONCLUÍDO] Lembrete para Agendamento ID: ${agendamentoId} finalizado com sucesso.`);
      return { status: 'success', agendamentoId };

    } catch (error: any) {
      this.logger.error(`[JOB FALHOU] Falha no envio de lembrete. Job ID: ${job.id}. Erro: ${error.message}`);
      throw error; // O Bull irá lidar com retries
    }
  }
}
