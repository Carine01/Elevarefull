// backend/src/modules/agendamentos/agendamentos.service.ts

import { Injectable, Logger, ConflictException } from '@nestjs/common';
import { PrismaService } from 'src/shared/prisma.service';
import { generateAvailableSlots, prioritizeSlots } from './agendamentos.utils';
import { Agendamento, Lead, Clinic } from '@prisma/client';
import { createExternalCalendarEvent } from './agendamentos.calendar';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { CreateAgendamentoDto } from './dto/create-agendamento.dto';


@Injectable()
export class AgendamentosService {
  private readonly logger = new Logger(AgendamentosService.name);

  constructor(
    @InjectQueue('agendamentos') private agendamentosQueue: Queue,
    private prisma: PrismaService,
  ) {}

  /**
   * Otimização de Funcionalidade: Verifica se há conflito de horário para o profissional.
   * @param professionalId ID do profissional.
   * @param startTime Início do novo agendamento.
   * @param endTime Fim do novo agendamento.
   */
  private async checkConflict(
    professionalId: number,
    startTime: Date,
    endTime: Date,
  ): Promise<void> {
    this.logger.log(`Verificando conflito para Profissional ${professionalId} entre ${startTime.toISOString()} e ${endTime.toISOString()}`);

    const conflictingAgendamento = await this.prisma.agendamento.findFirst({
      where: {
        professionalId,
        // Verifica se há sobreposição de horários
        startTime: { lt: endTime },
        endTime: { gt: startTime },
      },
    });

    if (conflictingAgendamento) {
      this.logger.warn(`Conflito detectado para Profissional ${professionalId}.`);
      throw new ConflictException(
        `O profissional já possui um agendamento das ${conflictingAgendamento.startTime.toLocaleTimeString()} às ${conflictingAgendamento.endTime.toLocaleTimeString()}.`,
      );
    }
  }

  /**
   * Cria um novo agendamento com validação de conflito.
   * @param dto Dados do novo agendamento.
   * @returns O agendamento criado.
   */
  /**
   * Sugere horários de agendamento inteligentes baseados na categoria do Lead.
   * @param clinicId ID da clínica (para isolamento de dados).
   * @param professionalId ID do profissional.
   * @param leadId ID do lead (para categoria).
   * @param date Data para a sugestão de horários.
   * @returns Lista de horários sugeridos.
   */
  async getSuggestedSlots(
    clinicId: number,
    professionalId: number,
    leadId: number,
    date: Date,
  ): Promise<{ startTime: Date; endTime: Date }[]> {
    // 1. Obter a categoria do Lead (Inteligência)
    const lead = await this.prisma.lead.findUnique({
      where: { id: leadId },
      select: { categoria: true },
    });

    if (!lead) {
      this.logger.warn(`Lead ID ${leadId} não encontrado na Clínica ${clinicId}. Usando categoria 'morno'.`);
    }
    const leadCategory = lead?.categoria || 'morno';

    // 2. Obter agendamentos existentes para o profissional na data
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const existingAppointments = await this.prisma.agendamento.findMany({
      where: {
        professionalId,
        startTime: {
          gte: startOfDay,
          lte: endOfDay,
        },
      },
    });

    // 3. Gerar slots disponíveis
    const availableSlots = generateAvailableSlots(date, existingAppointments);

    // 4. Priorizar slots com base na categoria do Lead
    const suggestedSlots = prioritizeSlots(availableSlots, leadCategory);

    this.logger.log(
      `Sugestão de horários para Lead ${leadId} (${leadCategory}): ${suggestedSlots.length} slots encontrados.`,
    );

    return suggestedSlots;
  }

  /**
   * Cria um novo agendamento com validação de conflito.
   * @param dto Dados do novo agendamento.
   * @returns O agendamento criado.
   */
  /**
   * Cria um novo agendamento com validação de conflito e integração com calendário.
   * @param dto Dados do novo agendamento.
   * @returns O agendamento criado.
   */
  async create(dto: CreateAgendamentoDto): Promise<Agendamento> {
    const startTime = new Date(dto.startTime);
    const endTime = new Date(dto.endTime);

    // 1. Validação de Conflito (Funcionalidade Crítica)
    await this.checkConflict(dto.professionalId, startTime, endTime);

    // 2. Criação do Agendamento
    const newAgendamento = await this.prisma.agendamento.create({
      data: {
        ...dto,
        startTime,
        endTime,
      },
    });

    this.logger.log(`Agendamento criado com sucesso. ID: ${newAgendamento.id}`);

    // 3. Integração com Calendário (Google/Outlook)
    // Simulação: Obter o e-mail do profissional (em um sistema real, viria do ProfessionalService)
    const professionalEmail = 'profissional@clinic.com'; // Hardcoded para simulação
    try {
      const externalEventId = await createExternalCalendarEvent(newAgendamento, professionalEmail);
      this.logger.log(`Evento criado no calendário externo para ${professionalEmail}. ID: ${externalEventId}`);
    } catch (error: any) {
      this.logger.error(`Falha ao criar evento no calendário externo: ${error.message}`);
      // A falha na integração do calendário não deve impedir a criação do agendamento no Elevare.
    }

    // 4. Otimização de Performance: Enfileirar o envio de lembretes (24h antes)

    // 3. Otimização de Performance: Enfileirar o envio de lembretes (24h antes)
    const reminderTime = new Date(startTime.getTime() - (24 * 60 * 60 * 1000));
    const delay = reminderTime.getTime() - Date.now();

    if (delay > 0) {
      this.agendamentosQueue.add(
        'send-reminder',
        {
          agendamentoId: newAgendamento.id,
          clientId: newAgendamento.clientId,
          reminderType: 'whatsapp', // Priorizar WhatsApp
        },
        {
          delay: delay, // Executa o job no momento exato do lembrete
          jobId: `reminder-${newAgendamento.id}`, // Garante idempotência do job
        },
      );
      this.logger.log(`Lembrete enfileirado para execução em ${delay / 1000} segundos.`);
    } else {
      this.logger.warn('Agendamento muito próximo. Lembrete não enfileirado.');
    }

    return newAgendamento;
  }
}
