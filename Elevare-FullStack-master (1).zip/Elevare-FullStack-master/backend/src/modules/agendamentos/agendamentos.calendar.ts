import { Agendamento } from '@prisma/client';

// Simulação de Integração com Calendário (Google/Outlook)
// Em um cenário real, este módulo usaria as APIs do Google Calendar ou Microsoft Graph
// para verificar a disponibilidade e criar eventos.

interface CalendarEvent {
  summary: string;
  start: Date;
  end: Date;
  attendees: string[];
}

/**
 * Simula a criação de um evento no calendário externo (Google/Outlook).
 * @param agendamento O agendamento criado no Elevare.
 * @param professionalEmail E-mail do profissional para o calendário.
 * @returns ID do evento criado no calendário externo.
 */
export async function createExternalCalendarEvent(agendamento: Agendamento, professionalEmail: string): Promise<string> {
  // 1. Formatar o evento
  const event: CalendarEvent = {
    summary: `Agendamento Elevare: Cliente ${agendamento.clientId}`,
    start: agendamento.startTime,
    end: agendamento.endTime,
    attendees: [professionalEmail],
  };

  // 2. Simulação de chamada à API do Google Calendar/Outlook
  // Aqui ocorreria a autenticação e a chamada real.
  // Para fins de desenvolvimento, apenas logamos a ação.
  console.log(`[Calendar Integration] Criando evento para ${professionalEmail}: ${event.summary}`);

  // 3. Retorna um ID de evento simulado
  const externalEventId = `cal-${agendamento.id}-${Math.random().toString(36).substring(2, 9)}`;
  return externalEventId;
}

/**
 * Simula a verificação de disponibilidade em um calendário externo.
 * Em um cenário real, isso seria usado em `getSuggestedSlots` para excluir horários
 * que estão ocupados no calendário do profissional, mas não foram agendados via Elevare.
 * @param professionalEmail E-mail do profissional.
 * @param startTime Início do período a verificar.
 * @param endTime Fim do período a verificar.
 * @returns Lista de eventos conflitantes.
 */
export async function checkExternalCalendarConflict(professionalEmail: string, startTime: Date, endTime: Date): Promise<CalendarEvent[]> {
  // Simulação: O profissional tem um bloqueio de 14:00 às 15:00
  if (professionalEmail === 'profissional@clinic.com') {
    const conflictStart = new Date(startTime);
    conflictStart.setHours(14, 0, 0, 0);
    const conflictEnd = new Date(startTime);
    conflictEnd.setHours(15, 0, 0, 0);

    if (startTime < conflictEnd && endTime > conflictStart) {
      return [{
        summary: 'Bloqueio Pessoal',
        start: conflictStart,
        end: conflictEnd,
        attendees: [professionalEmail],
      }];
    }
  }

  return [];
}
