import { Agendamento } from '@prisma/client';

// Configurações de horário de trabalho (Simulação)
const WORK_START_HOUR = 9; // 9:00
const WORK_END_HOUR = 18; // 18:00
const SLOT_DURATION_MINUTES = 60; // Slots de 1 hora

/**
 * Gera uma lista de horários disponíveis para agendamento em um determinado dia.
 *
 * @param date O dia para verificar a disponibilidade.
 * @param existingAppointments Agendamentos existentes para o profissional/clínica.
 * @returns Array de objetos com sugestões de horários (startTime e endTime).
 */
export function generateAvailableSlots(date: Date, existingAppointments: Agendamento[]): { startTime: Date, endTime: Date }[] {
  const availableSlots: { startTime: Date, endTime: Date }[] = [];
  const dayOfWeek = date.getDay(); // 0 = Domingo, 6 = Sábado

  // Simulação: Apenas dias úteis (Segunda a Sexta)
  if (dayOfWeek === 0 || dayOfWeek === 6) {
    return [];
  }

  // Define o início e o fim do dia de trabalho
  const startOfDay = new Date(date);
  startOfDay.setHours(WORK_START_HOUR, 0, 0, 0);

  const endOfDay = new Date(date);
  endOfDay.setHours(WORK_END_HOUR, 0, 0, 0);

  let currentTime = startOfDay;

  while (currentTime < endOfDay) {
    const slotStartTime = new Date(currentTime);
    const slotEndTime = new Date(slotStartTime.getTime() + SLOT_DURATION_MINUTES * 60000);

    // Verifica se o slot se sobrepõe a algum agendamento existente
    const isConflicting = existingAppointments.some(appointment => {
      const apptStart = new Date(appointment.startTime);
      const apptEnd = new Date(appointment.endTime);

      // Conflito se:
      // 1. O slot começa antes do fim do agendamento E
      // 2. O slot termina depois do início do agendamento
      return slotStartTime < apptEnd && slotEndTime > apptStart;
    });

    if (!isConflicting && slotEndTime <= endOfDay) {
      availableSlots.push({
        startTime: slotStartTime,
        endTime: slotEndTime,
      });
    }

    // Avança para o próximo slot
    currentTime = slotEndTime;
  }

  return availableSlots;
}

/**
 * Aplica a lógica de "Inteligência" para priorizar slots.
 * Por exemplo, priorizar horários nobres (manhã cedo, fim de tarde) para leads "Quentes".
 *
 * @param slots Slots disponíveis.
 * @param leadCategory Categoria do lead (quente, morno, frio).
 * @returns Slots priorizados.
 */
export function prioritizeSlots(slots: { startTime: Date, endTime: Date }[], leadCategory: string): { startTime: Date, endTime: Date }[] {
  if (leadCategory.toLowerCase() === 'quente') {
    // Priorizar horários nobres (9h-11h e 16h-18h)
    const prioritizedSlots = slots.filter(slot => {
      const hour = slot.startTime.getHours();
      return (hour >= 9 && hour < 11) || (hour >= 16 && hour < 18);
    });

    // Se houver slots priorizados, retorna apenas eles. Caso contrário, retorna todos.
    return prioritizedSlots.length > 0 ? prioritizedSlots : slots;
  }

  // Para leads Morno/Frio, retorna os slots em ordem cronológica
  return slots;
}
