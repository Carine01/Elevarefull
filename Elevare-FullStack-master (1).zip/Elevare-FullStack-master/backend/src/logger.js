/**
 * Logger Automático - Pino
 * 
 * Sistema de logs estruturados e automáticos para rastrear eventos, erros e auditoria.
 * 
 * Uso:
 * const logger = require('./logger');
 * 
 * logger.info('App started');
 * logger.error('Something went wrong', { error: err });
 * logger.debug('Debug info', { data: someData });
 * 
 * Recursos:
 * - Logs estruturados (JSON)
 * - Níveis: trace, debug, info, warn, error, fatal
 * - Timestamps automáticos
 * - Contexto de requisição (req_id)
 * - Rotação de arquivos automática
 * - Envio para serviços externos (Datadog, ELK, etc.)
 */

const pino = require('pino');
const path = require('path');

// Configuração baseada em ambiente
const isDevelopment = process.env.NODE_ENV !== 'production';
const logLevel = process.env.LOG_LEVEL || (isDevelopment ? 'debug' : 'info');

// Diretório de logs
const logsDir = process.env.LOGS_DIR || path.join(__dirname, '../../logs');

/**
 * Configuração do Pino
 */
const logger = pino({
  level: logLevel,
  
  // Formato de timestamp
  timestamp: pino.stdTimeFunctions.isoTime,
  
  // Formatação de desenvolvimento (pretty print)
  transport: isDevelopment ? {
    target: 'pino-pretty',
    options: {
      colorize: true,
      translateTime: 'SYS:standard',
      ignore: 'pid,hostname',
      singleLine: false
    }
  } : undefined,
  
  // Serializers para objetos comuns
  serializers: {
    req: pino.stdSerializers.req,
    res: pino.stdSerializers.res,
    err: pino.stdSerializers.err
  },
  
  // Redact de informações sensíveis
  redact: {
    paths: [
      'req.headers.authorization',
      'req.headers.cookie',
      'password',
      'token',
      'secret',
      'apiKey',
      'api_key',
      'access_token',
      'refresh_token'
    ],
    censor: '[REDACTED]'
  },
  
  // Base fields
  base: {
    pid: process.pid,
    hostname: process.env.HOSTNAME || require('os').hostname(),
    env: process.env.NODE_ENV || 'development',
    version: process.env.npm_package_version || '1.0.0'
  }
});

/**
 * Logger com contexto de requisição
 * 
 * Uso em Express:
 * app.use((req, res, next) => {
 *   req.log = logger.child({ req_id: req.id });
 *   next();
 * });
 */
function createRequestLogger(req) {
  return logger.child({
    req_id: req.id || req.headers['x-request-id'] || generateRequestId(),
    tenant_id: req.tenantId,
    user_id: req.userId
  });
}

/**
 * Gerar ID de requisição único
 */
function generateRequestId() {
  return `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Middleware Express para logging automático
 */
function expressLogger(req, res, next) {
  const startTime = Date.now();
  
  // Criar logger com contexto
  req.log = createRequestLogger(req);
  
  // Log de início da requisição
  req.log.info({
    method: req.method,
    url: req.url,
    ip: req.ip,
    userAgent: req.headers['user-agent']
  }, 'Request started');
  
  // Capturar resposta
  const originalSend = res.send;
  res.send = function(data) {
    const duration = Date.now() - startTime;
    
    req.log.info({
      method: req.method,
      url: req.url,
      statusCode: res.statusCode,
      duration: `${duration}ms`
    }, 'Request completed');
    
    return originalSend.call(this, data);
  };
  
  // Capturar erros
  res.on('error', (err) => {
    req.log.error({ err }, 'Response error');
  });
  
  next();
}

/**
 * Handler de erros não capturados
 */
process.on('uncaughtException', (err) => {
  logger.fatal({ err }, 'Uncaught exception');
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error({ reason, promise }, 'Unhandled promise rejection');
});

/**
 * Log de shutdown graceful
 */
process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down gracefully');
});

process.on('SIGINT', () => {
  logger.info('SIGINT received, shutting down gracefully');
});

/**
 * Exportações
 */
module.exports = logger;
module.exports.createRequestLogger = createRequestLogger;
module.exports.expressLogger = expressLogger;
module.exports.generateRequestId = generateRequestId;

/**
 * Exemplo de uso em aplicação Express:
 * 
 * const express = require('express');
 * const { expressLogger } = require('./logger');
 * const logger = require('./logger');
 * 
 * const app = express();
 * 
 * // Middleware de logging
 * app.use(expressLogger);
 * 
 * // Usar logger em rotas
 * app.get('/api/users', (req, res) => {
 *   req.log.info('Fetching users');
 *   
 *   try {
 *     const users = getUsers();
 *     req.log.info({ count: users.length }, 'Users fetched');
 *     res.json(users);
 *   } catch (err) {
 *     req.log.error({ err }, 'Error fetching users');
 *     res.status(500).json({ error: 'Internal server error' });
 *   }
 * });
 * 
 * // Log global
 * logger.info('Application started');
 */

/**
 * Configuração de transporte para serviços externos
 * 
 * Datadog:
 * const logger = pino({
 *   transport: {
 *     target: '@datadog/pino',
 *     options: {
 *       apiKey: process.env.DATADOG_API_KEY,
 *       service: 'elevare-backend',
 *       env: process.env.NODE_ENV
 *     }
 *   }
 * });
 * 
 * ELK Stack:
 * const logger = pino({
 *   transport: {
 *     target: 'pino-elasticsearch',
 *     options: {
 *       node: process.env.ELASTICSEARCH_URL,
 *       index: 'elevare-logs'
 *     }
 *   }
 * });
 * 
 * Arquivo com rotação:
 * const logger = pino(pino.destination({
 *   dest: path.join(logsDir, 'app.log'),
 *   sync: false,
 *   mkdir: true
 * }));
 */
