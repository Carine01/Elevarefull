# 🚀 Elevare Backend - API REST

Backend completo para o sistema Elevare com integração WhatsApp, gerenciamento de leads e gamificação.

---

## 📋 Índice

1. [Arquitetura](#arquitetura)
2. [Instalação](#instalação)
3. [Configuração](#configuração)
4. [Endpoints da API](#endpoints-da-api)
5. [Integração WhatsApp](#integração-whatsapp)
6. [Banco de Dados](#banco-de-dados)
7. [Testes](#testes)
8. [Deploy](#deploy)

---

## 🏗️ Arquitetura

```
backend/
├── src/
│   ├── api/
│   │   ├── leads.controller.js      # Controller de leads (NOVO)
│   │   └── whatsapp.service.js      # Serviço WhatsApp (NOVO)
│   ├── modules/
│   │   ├── auth/
│   │   ├── users/
│   │   └── clinics/
│   ├── common/
│   └── config/
├── prisma/
│   ├── schema.prisma                # Schema Prisma (TypeScript)
│   └── schema.sql                   # Schema SQL completo (NOVO)
└── package.json
```

**Stack:**
- Node.js 20+
- NestJS (Framework)
- Prisma ORM
- PostgreSQL / Supabase
- JWT Authentication
- WhatsApp Business API

---

## 📦 Instalação

### Pré-requisitos

```bash
node >= 20.0.0
npm >= 10.0.0
postgresql >= 15.0 (ou Supabase)
```

### Passo 1: Instalar dependências

```bash
cd backend
npm install
```

### Passo 2: Configurar variáveis de ambiente

```bash
cp .env.example .env
# Edite .env com suas credenciais
```

### Passo 3: Configurar banco de dados

**Opção A: PostgreSQL local**
```bash
# Criar banco
createdb elevare_db

# Executar migrations
npm run prisma:migrate
```

**Opção B: Supabase**
```bash
# 1. Acesse https://supabase.com/dashboard
# 2. Crie novo projeto
# 3. Execute o SQL em prisma/schema.sql no SQL Editor
# 4. Configure SUPABASE_URL e SUPABASE_ANON_KEY no .env
```

### Passo 4: Iniciar servidor

```bash
# Desenvolvimento
npm run start:dev

# Produção
npm run build
npm run start:prod
```

**Servidor rodando em:** http://localhost:3000

---

## ⚙️ Configuração

### Variáveis de Ambiente Essenciais

| Variável | Descrição | Exemplo |
|----------|-----------|---------|
| `DATABASE_URL` | URL do PostgreSQL | `postgresql://user:pass@localhost:5432/db` |
| `JWT_SECRET` | Chave secreta JWT | `min_32_caracteres_aleatorios` |
| `WHATSAPP_MODE` | Modo WhatsApp | `link` ou `api` |
| `PORT` | Porta do servidor | `3000` |

### Configuração JWT

O backend usa JWT para autenticação. Certifique-se de que seu JWT contém:

```json
{
  "sub": "user_id",
  "tenantId": "clinic_id",
  "role": "admin",
  "iat": 1234567890,
  "exp": 1234567890
}
```

**Ajuste necessário em `src/api/leads.controller.js` (linha 16):**

```javascript
// Se seu JWT usa 'tenant' ao invés de 'tenantId':
const tenantId = req.user.tenant || req.user.tenantId;
```

---

## 🔌 Endpoints da API

### Autenticação

Todos os endpoints requerem header:
```
Authorization: Bearer <seu_jwt_token>
```

### Leads

#### `POST /api/v1/leads`
Criar novo lead

**Request:**
```json
{
  "name": "João Silva",
  "phone": "5511999999999",
  "email": "joao@example.com",
  "source": "landing_page",
  "metadata": {
    "utm_source": "google",
    "utm_campaign": "ads"
  }
}
```

**Response:**
```json
{
  "id": "uuid",
  "name": "João Silva",
  "phone": "5511999999999",
  "score": 50,
  "status": "novo",
  "createdAt": "2025-11-28T23:00:00Z"
}
```

#### `GET /api/v1/leads`
Listar leads com filtros

**Query params:**
- `status`: novo, contatado, convertido
- `minScore`: score mínimo
- `startDate`: data inicial (ISO)
- `endDate`: data final (ISO)
- `page`: número da página
- `limit`: itens por página

**Response:**
```json
{
  "data": [...],
  "pagination": {
    "total": 100,
    "page": 1,
    "limit": 20,
    "totalPages": 5
  }
}
```

#### `GET /api/v1/leads/:id`
Obter lead por ID

#### `PATCH /api/v1/leads/:id`
Atualizar lead

**Request:**
```json
{
  "status": "contatado",
  "notes": "Cliente interessado em botox"
}
```

#### `DELETE /api/v1/leads/:id`
Deletar lead

### WhatsApp

#### `POST /api/v1/whatsapp/send`
Enviar mensagem WhatsApp

**Request:**
```json
{
  "to": "5511999999999",
  "message": "Olá! Obrigado pelo interesse.",
  "leadId": "uuid"
}
```

**Response (modo 'link'):**
```json
{
  "success": true,
  "url": "https://wa.me/5511999999999?text=Olá!%20Obrigado%20pelo%20interesse."
}
```

**Response (modo 'api'):**
```json
{
  "success": true,
  "messageId": "wamid.xxx",
  "status": "sent"
}
```

### Analytics

#### `GET /api/v1/analytics/dashboard`
Métricas do dashboard

**Response:**
```json
{
  "totalLeads": 150,
  "newLeads": 23,
  "avgScore": 65,
  "conversionRate": 0.35,
  "topSources": [
    { "source": "google", "count": 50 },
    { "source": "instagram", "count": 30 }
  ]
}
```

---

## 📱 Integração WhatsApp

### Modo 1: Link (Gratuito)

Gera links `wa.me` que abrem WhatsApp Web/App.

**Configuração:**
```env
WHATSAPP_MODE=link
```

**Uso:**
```javascript
const response = await fetch('/api/v1/whatsapp/send', {
  method: 'POST',
  body: JSON.stringify({
    to: '5511999999999',
    message: 'Olá!'
  })
});

const { url } = await response.json();
window.open(url, '_blank'); // Abre WhatsApp
```

### Modo 2: API Oficial (Pago)

Usa WhatsApp Business API da Meta.

**Configuração:**
```env
WHATSAPP_MODE=api
WHATSAPP_API_TOKEN=seu_token
WHATSAPP_PHONE_NUMBER_ID=seu_phone_id
WHATSAPP_BUSINESS_ACCOUNT_ID=seu_account_id
```

**Custo:** ~R$ 0,015 por mensagem

**Obter credenciais:**
1. Acesse https://business.facebook.com
2. Crie Business Account
3. Adicione WhatsApp Business
4. Obtenha token em Configurações > API

---

## 🗄️ Banco de Dados

### Schema Completo

O schema está em `prisma/schema.sql` e inclui:

**Tabelas:**
- `leads` - Leads capturados
- `lead_interactions` - Interações (WhatsApp, email)
- `lead_scores` - Histórico de scoring
- `gamification_achievements` - Conquistas
- `analytics_events` - Eventos de analytics

**Triggers:**
- `update_lead_score` - Atualiza score automaticamente
- `update_updated_at` - Atualiza timestamp

**Índices:**
- Performance otimizada para queries comuns
- GIN index para busca em metadata (JSONB)

### Executar Schema

**PostgreSQL:**
```bash
psql -U postgres -d elevare_db -f prisma/schema.sql
```

**Supabase:**
1. Acesse SQL Editor no dashboard
2. Cole conteúdo de `prisma/schema.sql`
3. Execute

### Migrations

```bash
# Criar migration
npm run prisma:migrate:dev --name nome_da_migration

# Aplicar migrations
npm run prisma:migrate:deploy

# Resetar banco (CUIDADO!)
npm run prisma:migrate:reset
```

---

## 🧪 Testes

```bash
# Testes unitários
npm test

# Testes E2E
npm run test:e2e

# Cobertura
npm run test:cov
```

---

## 🚀 Deploy

### Docker

```bash
# Build
docker build -t elevare-backend .

# Run
docker run -p 3000:3000 --env-file .env elevare-backend
```

### Docker Compose

```bash
docker-compose up -d
```

### Vercel (Serverless)

```bash
# Instalar Vercel CLI
npm i -g vercel

# Deploy
vercel --prod
```

### Railway

```bash
# Conectar repositório
railway link

# Deploy
railway up
```

---

## 📊 Monitoramento

### Logs

```bash
# Desenvolvimento
npm run start:dev

# Produção (JSON logs)
NODE_ENV=production npm run start:prod
```

### Métricas (Prometheus)

Acesse: http://localhost:9090/metrics

### Sentry (Erros)

Configure `SENTRY_DSN` no `.env`

---

## 🔧 Troubleshooting

### Erro: "JWT malformed"

**Causa:** Token inválido ou expirado  
**Solução:** Verifique `JWT_SECRET` e renove token

### Erro: "Database connection failed"

**Causa:** PostgreSQL não acessível  
**Solução:** Verifique `DATABASE_URL` e se o banco está rodando

### Erro: "WhatsApp API rate limit"

**Causa:** Muitas mensagens em curto período  
**Solução:** Implemente fila (Redis + Bull)

---

## 📚 Documentação Adicional

- [Guia de Personalização](../docs/guias/GUIA_PERSONALIZACAO_LANDING.md)
- [Checklist de Deploy](../docs/guias/CHECKLIST_MIGRACAO_DEPLOY.md)
- [Arquitetura Docker](../docs/arquitetura/docker_deployment.md)

---

**Criado por:** Manus AI  
**Versão:** 1.0  
**Data:** 28/11/2025
