#!/bin/sh

echo "🚀 Iniciando Elevare SaaS..."

# Aguardar PostgreSQL (no Railway já estará pronto, mas mantemos por segurança)
sleep 3

# Rodar migrations automaticamente
echo "📦 Executando migrations do Prisma..."
npx prisma migrate deploy

# Iniciar aplicação
echo "✅ Iniciando servidor..."
node dist/main
