#!/usr/bin/env python3
"""
Script de Auditoria Completa - Elevare FullStack
Analisa segurança, qualidade de código e boas práticas
"""

import os
import json
import re
import subprocess
from datetime import datetime
from pathlib import Path
from collections import defaultdict

class ElevareAuditor:
    def __init__(self, project_root):
        self.project_root = Path(project_root)
        self.results = {
            "timestamp": datetime.now().isoformat(),
            "project": "Elevare-FullStack",
            "health_score": 0,
            "critical_issues": [],
            "warnings": [],
            "info": [],
            "security": {},
            "quality": {},
            "tests": {},
            "dependencies": {}
        }
        
    def scan_secrets(self):
        """Escaneia por secrets expostos no código"""
        print("🔍 Escaneando secrets...")
        secrets_found = []
        
        # Padrões de secrets
        patterns = {
            "supabase_key": r"(eyJhbGciOiJIUzI1NI[A-Za-z0-9_-]{100,})",
            "api_key": r"(api[_-]?key|apikey)[\s]*[:=][\s]*['\"]([A-Za-z0-9_-]{20,})['\"]",
            "jwt_secret": r"(jwt[_-]?secret)[\s]*[:=][\s]*['\"]([^'\"]{10,})['\"]",
            "password": r"(password|passwd|pwd)[\s]*[:=][\s]*['\"]([^'\"]{8,})['\"]",
            "token": r"(token|access[_-]?token)[\s]*[:=][\s]*['\"]([A-Za-z0-9_-]{20,})['\"]"
        }
        
        # Arquivos para escanear
        extensions = ['.js', '.ts', '.jsx', '.tsx', '.env', '.json']
        exclude_dirs = {'node_modules', '.git', 'dist', 'build', 'coverage'}
        
        for root, dirs, files in os.walk(self.project_root):
            # Filtrar diretórios
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                if any(file.endswith(ext) for ext in extensions):
                    file_path = Path(root) / file
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                            
                        for secret_type, pattern in patterns.items():
                            matches = re.finditer(pattern, content, re.IGNORECASE)
                            for match in matches:
                                # Ignorar .example e comentários
                                if '.example' not in str(file_path) and not match.group(0).strip().startswith('//'):
                                    secrets_found.append({
                                        "type": secret_type,
                                        "file": str(file_path.relative_to(self.project_root)),
                                        "line": content[:match.start()].count('\n') + 1,
                                        "preview": match.group(0)[:50] + "..."
                                    })
                    except Exception as e:
                        pass
        
        self.results["security"]["secrets_found"] = len(secrets_found)
        if secrets_found:
            for secret in secrets_found[:10]:  # Limitar a 10 para não poluir
                self.results["critical_issues"].append({
                    "type": "SECRET_EXPOSED",
                    "severity": "CRITICAL",
                    "message": f"Secret {secret['type']} encontrado em {secret['file']}:{secret['line']}",
                    "file": secret["file"],
                    "line": secret["line"]
                })
        
        return secrets_found
    
    def check_env_files(self):
        """Verifica arquivos .env"""
        print("📁 Verificando arquivos .env...")
        env_files = []
        
        for root, dirs, files in os.walk(self.project_root):
            dirs[:] = [d for d in dirs if d not in {'node_modules', '.git'}]
            for file in files:
                if file.startswith('.env') and not file.endswith('.example'):
                    file_path = Path(root) / file
                    env_files.append(str(file_path.relative_to(self.project_root)))
        
        self.results["security"]["env_files"] = env_files
        if env_files:
            self.results["critical_issues"].append({
                "type": "ENV_FILE_COMMITTED",
                "severity": "CRITICAL",
                "message": f"{len(env_files)} arquivo(s) .env encontrado(s) no repositório",
                "files": env_files
            })
        
        return env_files
    
    def analyze_dependencies(self):
        """Analisa vulnerabilidades de dependências"""
        print("📦 Analisando dependências...")
        
        try:
            result = subprocess.run(
                ['npm', 'audit', '--json'],
                cwd=self.project_root,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.stdout:
                audit_data = json.loads(result.stdout)
                
                vulnerabilities = audit_data.get('vulnerabilities', {})
                metadata = audit_data.get('metadata', {})
                
                self.results["dependencies"] = {
                    "total_vulnerabilities": metadata.get('vulnerabilities', {}).get('total', 0),
                    "critical": metadata.get('vulnerabilities', {}).get('critical', 0),
                    "high": metadata.get('vulnerabilities', {}).get('high', 0),
                    "moderate": metadata.get('vulnerabilities', {}).get('moderate', 0),
                    "low": metadata.get('vulnerabilities', {}).get('low', 0)
                }
                
                # Adicionar vulnerabilidades críticas e high
                for pkg, vuln in list(vulnerabilities.items())[:5]:
                    if vuln.get('severity') in ['critical', 'high']:
                        self.results["critical_issues"].append({
                            "type": "DEPENDENCY_VULNERABILITY",
                            "severity": vuln.get('severity', 'unknown').upper(),
                            "message": f"Vulnerabilidade {vuln.get('severity')} em {pkg}",
                            "package": pkg,
                            "via": vuln.get('via', [])
                        })
        except Exception as e:
            self.results["dependencies"]["error"] = str(e)
    
    def analyze_code_quality(self):
        """Analisa qualidade do código"""
        print("📊 Analisando qualidade do código...")
        
        stats = {
            "total_files": 0,
            "total_lines": 0,
            "js_files": 0,
            "ts_files": 0,
            "test_files": 0,
            "commented_lines": 0,
            "todo_comments": 0,
            "fixme_comments": 0
        }
        
        extensions = {'.js': 'js_files', '.ts': 'ts_files', '.jsx': 'js_files', '.tsx': 'ts_files'}
        exclude_dirs = {'node_modules', '.git', 'dist', 'build', 'coverage'}
        
        for root, dirs, files in os.walk(self.project_root):
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                ext = Path(file).suffix
                if ext in extensions:
                    stats["total_files"] += 1
                    stats[extensions[ext]] += 1
                    
                    if 'test' in file or 'spec' in file:
                        stats["test_files"] += 1
                    
                    file_path = Path(root) / file
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            lines = f.readlines()
                            stats["total_lines"] += len(lines)
                            
                            for line in lines:
                                stripped = line.strip()
                                if stripped.startswith('//') or stripped.startswith('*') or stripped.startswith('/*'):
                                    stats["commented_lines"] += 1
                                if 'TODO' in line.upper():
                                    stats["todo_comments"] += 1
                                if 'FIXME' in line.upper():
                                    stats["fixme_comments"] += 1
                    except Exception:
                        pass
        
        self.results["quality"] = stats
        
        # Adicionar warnings
        if stats["fixme_comments"] > 0:
            self.results["warnings"].append({
                "type": "FIXME_COMMENTS",
                "message": f"{stats['fixme_comments']} comentários FIXME encontrados no código"
            })
        
        if stats["test_files"] < 10:
            self.results["warnings"].append({
                "type": "LOW_TEST_COVERAGE",
                "message": f"Apenas {stats['test_files']} arquivos de teste encontrados"
            })
    
    def check_git_config(self):
        """Verifica configuração do Git"""
        print("🔧 Verificando configuração Git...")
        
        gitignore_path = self.project_root / '.gitignore'
        if gitignore_path.exists():
            with open(gitignore_path, 'r') as f:
                gitignore_content = f.read()
            
            required_patterns = ['.env', 'node_modules', 'dist', '*.log']
            missing_patterns = []
            
            for pattern in required_patterns:
                if pattern not in gitignore_content:
                    missing_patterns.append(pattern)
            
            if missing_patterns:
                self.results["warnings"].append({
                    "type": "GITIGNORE_INCOMPLETE",
                    "message": f"Padrões faltando no .gitignore: {', '.join(missing_patterns)}"
                })
        else:
            self.results["critical_issues"].append({
                "type": "GITIGNORE_MISSING",
                "severity": "HIGH",
                "message": "Arquivo .gitignore não encontrado"
            })
    
    def calculate_health_score(self):
        """Calcula o health score do projeto"""
        print("💯 Calculando health score...")
        
        score = 100
        
        # Penalidades
        score -= len(self.results["critical_issues"]) * 15
        score -= len(self.results["warnings"]) * 5
        
        # Vulnerabilidades
        deps = self.results.get("dependencies", {})
        score -= deps.get("critical", 0) * 10
        score -= deps.get("high", 0) * 5
        score -= deps.get("moderate", 0) * 2
        
        # Garantir que não seja negativo
        score = max(0, score)
        
        self.results["health_score"] = score
        
        # Classificação
        if score >= 80:
            self.results["health_classification"] = "EXCELLENT"
        elif score >= 60:
            self.results["health_classification"] = "GOOD"
        elif score >= 40:
            self.results["health_classification"] = "NEEDS_IMPROVEMENT"
        else:
            self.results["health_classification"] = "CRITICAL"
    
    def run_full_audit(self):
        """Executa auditoria completa"""
        print("=" * 60)
        print("🚀 AUDITORIA COMPLETA - ELEVARE FULLSTACK")
        print("=" * 60)
        
        self.scan_secrets()
        self.check_env_files()
        self.analyze_dependencies()
        self.analyze_code_quality()
        self.check_git_config()
        self.calculate_health_score()
        
        # Salvar resultados
        output_file = self.project_root / '.manus' / f'audit-{datetime.now().strftime("%Y%m%d-%H%M%S")}.json'
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=2, ensure_ascii=False)
        
        print("\n" + "=" * 60)
        print(f"✅ Auditoria concluída!")
        print(f"📊 Health Score: {self.results['health_score']}/100 ({self.results['health_classification']})")
        print(f"🚨 Issues Críticos: {len(self.results['critical_issues'])}")
        print(f"⚠️  Warnings: {len(self.results['warnings'])}")
        print(f"📁 Resultados salvos em: {output_file}")
        print("=" * 60)
        
        return self.results

if __name__ == "__main__":
    auditor = ElevareAuditor("/home/ubuntu/Elevare-FullStack")
    results = auditor.run_full_audit()
    
    # Imprimir resumo
    print("\n📋 RESUMO EXECUTIVO:")
    print(f"   • Health Score: {results['health_score']}/100")
    print(f"   • Issues Críticos: {len(results['critical_issues'])}")
    print(f"   • Warnings: {len(results['warnings'])}")
    print(f"   • Vulnerabilidades: {results['dependencies'].get('total_vulnerabilities', 0)}")
    print(f"   • Arquivos de código: {results['quality']['total_files']}")
    print(f"   • Linhas de código: {results['quality']['total_lines']}")
