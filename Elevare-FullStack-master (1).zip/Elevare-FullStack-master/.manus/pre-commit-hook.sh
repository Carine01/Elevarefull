#!/bin/bash
###############################################################################
# Pre-Commit Hook - Elevare FullStack
# Bloqueia commits com secrets expostos ou arquivos .env
###############################################################################

set -e

echo "🔒 Manus Security Check - Pre-Commit"
echo "======================================"

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

BLOCKED=0

# 1. Verificar arquivos .env
echo "📁 Verificando arquivos .env..."
ENV_FILES=$(git diff --cached --name-only --diff-filter=ACM | grep -E "^\.env$|\.env\.[^.]*$" | grep -v ".env.example" || true)

if [ ! -z "$ENV_FILES" ]; then
    echo -e "${RED}❌ BLOQUEADO: Arquivos .env detectados no commit${NC}"
    echo "$ENV_FILES"
    BLOCKED=1
fi

# 2. Verificar SUPABASE keys
echo "🔑 Verificando SUPABASE keys..."
SUPABASE_KEYS=$(git diff --cached | grep -E "eyJhbGciOiJIUzI1NI[A-Za-z0-9_-]{100,}" || true)

if [ ! -z "$SUPABASE_KEYS" ]; then
    echo -e "${RED}❌ BLOQUEADO: SUPABASE_KEY detectada no commit${NC}"
    echo "Chave encontrada (truncada): ${SUPABASE_KEYS:0:50}..."
    BLOCKED=1
fi

# 3. Verificar API Keys genéricas
echo "🔐 Verificando API keys genéricas..."
API_KEYS=$(git diff --cached | grep -iE "(api[_-]?key|apikey)[\s]*[:=][\s]*['\"][A-Za-z0-9_-]{20,}['\"]" || true)

if [ ! -z "$API_KEYS" ]; then
    echo -e "${YELLOW}⚠️  WARNING: Possível API key detectada${NC}"
    echo "Revise manualmente se não for um exemplo/mock"
fi

# 4. Verificar senhas hardcoded (exceto em testes)
echo "🔒 Verificando senhas hardcoded..."
PASSWORDS=$(git diff --cached --name-only --diff-filter=ACM | grep -v "test\|spec\|mock" | xargs -I {} git diff --cached {} | grep -iE "(password|passwd)[\s]*[:=][\s]*['\"][^'\"]{8,}['\"]" || true)

if [ ! -z "$PASSWORDS" ]; then
    echo -e "${YELLOW}⚠️  WARNING: Possível senha hardcoded detectada (fora de testes)${NC}"
fi

# 5. Verificar JWT secrets
echo "🎫 Verificando JWT secrets..."
JWT_SECRETS=$(git diff --cached | grep -iE "jwt[_-]?secret[\s]*[:=][\s]*['\"][^'\"]{10,}['\"]" | grep -v "process.env" || true)

if [ ! -z "$JWT_SECRETS" ]; then
    echo -e "${RED}❌ BLOQUEADO: JWT_SECRET hardcoded detectado${NC}"
    BLOCKED=1
fi

# Resultado final
echo "======================================"
if [ $BLOCKED -eq 1 ]; then
    echo -e "${RED}❌ COMMIT BLOQUEADO${NC}"
    echo ""
    echo "Corrija os problemas acima antes de commitar."
    echo "Para ignorar esta verificação (NÃO RECOMENDADO):"
    echo "  git commit --no-verify"
    exit 1
else
    echo -e "${GREEN}✅ Verificações de segurança aprovadas${NC}"
    exit 0
fi
