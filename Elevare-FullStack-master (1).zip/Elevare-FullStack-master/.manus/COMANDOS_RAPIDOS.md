# 🚀 Comandos Rápidos - Manus Audit System

## 📦 Instalação Inicial

```bash
# Instalar dependências
npm install --legacy-peer-deps

# Instalar pre-commit hook
ln -sf ../../.manus/pre-commit-hook.sh .git/hooks/pre-commit
chmod +x .git/hooks/pre-commit
```

## 🔍 Auditoria e Validação

```bash
# Auditoria completa
npm run audit:security

# Validar comandos e estrutura
npm run validate

# Aplicar correções automáticas
npm run fix:auto

# Monitoramento contínuo (watch mode)
npm run audit:watch

# Abrir dashboard
open .manus/dashboard.html
```

## 🔒 Segurança

```bash
# Escanear por secrets
grep -r "eyJhbGciOiJIUzI1NI" --include="*.js" --include="*.ts" .

# Verificar arquivos .env
find . -name ".env" -not -name "*.example" | grep -v node_modules

# Remover .env do Git
git rm --cached frontend/.env.development
git rm --cached frontend/.env.production
git rm --cached frontend-landing/backend/.env.mock
git rm --cached frontend-landing/backend/.env.whatsapp
```

## 🧪 Testes

```bash
# Executar testes
npm test

# Testes com cobertura
npm test -- --coverage

# Testes E2E
npm run test:e2e

# Testes em watch mode
npm run test:watch
```

## 🏗️ Build e Deploy

```bash
# Build do backend
cd backend && npm run build

# Build do frontend
cd frontend && npm run build

# Build da landing page
cd frontend-landing && npm run build:prod:frontend
```

## 📊 Análise de Dependências

```bash
# Listar vulnerabilidades
npm audit

# Corrigir vulnerabilidades automaticamente
npm audit fix

# Corrigir com breaking changes
npm audit fix --force

# Ver árvore de dependências
npm list --depth=0
```

## 🔧 Manutenção

```bash
# Limpar node_modules e reinstalar
rm -rf node_modules package-lock.json
npm install --legacy-peer-deps

# Limpar cache do npm
npm cache clean --force

# Atualizar dependências
npm update

# Ver pacotes desatualizados
npm outdated
```

## 📝 Git

```bash
# Verificar status
git status

# Commitar com validação
git commit -m "feat: sua mensagem"

# Commitar ignorando hook (NÃO RECOMENDADO)
git commit --no-verify -m "sua mensagem"

# Ver histórico de commits
git log --oneline --graph --decorate

# Desfazer último commit (mantendo mudanças)
git reset --soft HEAD~1
```

## 🐛 Debug

```bash
# Ver logs do pre-commit hook
cat .git/hooks/pre-commit

# Executar pre-commit manualmente
bash .git/hooks/pre-commit

# Ver resultado da última auditoria
cat .manus/audit-*.json | jq '.'

# Ver logs do Jest
npm test -- --verbose

# Debug de testes específicos
npm test -- lead-tracker.test.js --verbose
```

## 📈 Estatísticas

```bash
# Contar linhas de código
find . -name "*.js" -o -name "*.ts" | grep -v node_modules | xargs wc -l

# Contar arquivos de teste
find . -name "*.test.js" -o -name "*.spec.ts" | grep -v node_modules | wc -l

# Ver tamanho do projeto
du -sh .

# Ver tamanho do node_modules
du -sh node_modules
```

## 🔄 CI/CD

```bash
# Validar GitHub Action localmente (requer act)
act -j security-scan

# Ver status das Actions no GitHub
gh run list

# Ver logs da última Action
gh run view --log
```

## 💡 Dicas Úteis

### Criar .env a partir do .example

```bash
cp .env.example .env
# Edite o .env com suas credenciais reais
```

### Gerar novo secret JWT

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### Verificar se .env está no .gitignore

```bash
grep "^\.env" .gitignore
```

### Adicionar .env ao .gitignore

```bash
echo ".env" >> .gitignore
echo ".env.local" >> .gitignore
echo ".env.*.local" >> .gitignore
```

## 🚨 Comandos de Emergência

### Health Score Crítico

```bash
# 1. Execute auditoria
npm run audit:security

# 2. Veja o dashboard
open .manus/dashboard.html

# 3. Aplique correções
npm run fix:auto

# 4. Execute novamente
npm run audit:security
```

### Secret Exposto no Git

```bash
# 1. Remova o arquivo do Git
git rm --cached arquivo-com-secret.js

# 2. Adicione ao .gitignore
echo "arquivo-com-secret.js" >> .gitignore

# 3. Commite a remoção
git commit -m "security: remove exposed secret"

# 4. IMPORTANTE: Revogue o secret no serviço (Supabase, etc.)
```

### Build Quebrado

```bash
# 1. Limpe tudo
rm -rf node_modules package-lock.json dist build

# 2. Reinstale
npm install --legacy-peer-deps

# 3. Tente o build novamente
npm run build
```

## 📞 Suporte

Se encontrar problemas:

1. Verifique o README em `.manus/README.md`
2. Veja o relatório completo em `AUDITORIA_MANUS_COMPLETA.md`
3. Execute `npm run validate` para diagnóstico
4. Abra uma issue no GitHub com os logs de erro

---

**Última atualização:** 29/11/2025
