# 🔒 Manus Security & Quality Audit System

Sistema completo de auditoria de segurança e qualidade para o projeto Elevare-FullStack.

## 📋 Visão Geral

Este diretório contém todas as ferramentas e scripts desenvolvidos para garantir a segurança, qualidade e conformidade do código do projeto. O sistema foi projetado para ser executado automaticamente em diferentes estágios do ciclo de desenvolvimento.

## 🚀 Quick Start

### Executar Auditoria Completa

```bash
npm run audit:security
```

### Validar Comandos Críticos

```bash
npm run validate
```

### Aplicar Correções Automáticas

```bash
npm run fix:auto
```

### Monitoramento Contínuo (Watch Mode)

```bash
npm run audit:watch
```

## 📦 Componentes do Sistema

### 1. Scripts de Auditoria

#### `audit-script.py`
Script principal de auditoria que escaneia o projeto em busca de:
- Secrets expostos (API keys, tokens, senhas)
- Arquivos .env commitados
- Vulnerabilidades de dependências
- Qualidade do código
- Configurações do Git

**Uso:**
```bash
python3 .manus/audit-script.py
```

**Output:**
- Arquivo JSON com resultados detalhados em `.manus/audit-YYYYMMDD-HHMMSS.json`
- Health Score de 0-100
- Lista de issues críticos e warnings

#### `audit-watch.py`
Monitora o projeto em tempo real e executa auditorias quando detecta mudanças.

**Uso:**
```bash
python3 .manus/audit-watch.py --interval 30
```

**Funcionalidades:**
- Detecção de mudanças em arquivos
- Quick scan de segurança em arquivos alterados
- Alertas automáticos se Health Score < 60
- Execução de auditoria completa quando necessário

### 2. MVP de Bloqueio

#### `pre-commit-hook.sh`
Hook de Git que bloqueia commits com problemas de segurança.

**Instalação:**
```bash
ln -sf ../../.manus/pre-commit-hook.sh .git/hooks/pre-commit
```

**Verificações:**
- Arquivos .env
- SUPABASE keys
- API keys genéricas
- JWT secrets hardcoded
- Senhas hardcoded (fora de testes)

**Bypass (NÃO RECOMENDADO):**
```bash
git commit --no-verify
```

#### `.github/workflows/security-audit.yml`
GitHub Action que executa as mesmas verificações do pre-commit hook em CI/CD.

**Triggers:**
- Push para `main` ou `develop`
- Pull requests para `main` ou `develop`

### 3. Auto-Fix

#### `auto-fix.py`
Corrige automaticamente problemas comuns.

**Uso:**
```bash
python3 .manus/auto-fix.py
```

**Correções:**
- Configuração do Jest (testEnvironment, setupFiles)
- Mocks ausentes em testes (fetch, localStorage)
- Padrões .env no .gitignore
- Scripts úteis no package.json

### 4. Validação

#### `validate-commands.sh`
Valida comandos críticos e estrutura do projeto.

**Uso:**
```bash
bash .manus/validate-commands.sh
```

**Validações:**
- Dependências instaladas
- Testes unitários
- Estrutura de arquivos (package.json, tsconfig.json, .gitignore)
- Arquivos .env (não devem existir)
- .gitignore contém .env

### 5. Dashboard

#### `dashboard.html`
Painel visual para acompanhamento do Health Score e issues.

**Acesso:**
```bash
open .manus/dashboard.html
# ou
python3 -m http.server 8080 --directory .manus
# Acesse http://localhost:8080/dashboard.html
```

**Visualizações:**
- Health Score com classificação
- Issues críticos
- Vulnerabilidades
- Estatísticas de código
- Recomendações prioritárias

## 📊 Health Score

O Health Score é calculado com base em:

| Fator | Penalidade |
| :--- | :--- |
| Issue Crítico | -15 pontos |
| Warning | -5 pontos |
| Vulnerabilidade Critical | -10 pontos |
| Vulnerabilidade High | -5 pontos |
| Vulnerabilidade Moderate | -2 pontos |

**Classificação:**
- 80-100: EXCELLENT ✅
- 60-79: GOOD 🟢
- 40-59: NEEDS_IMPROVEMENT 🟡
- 0-39: CRITICAL 🔴

## 🔐 Regras de Segurança

### Secrets Não Permitidos

1. **Arquivos .env:** Nunca commite arquivos `.env` (exceto `.env.example`)
2. **SUPABASE keys:** Padrão `eyJhbGciOiJIUzI1NI...`
3. **API keys:** Padrão `api_key = "..."`
4. **JWT secrets:** Padrão `jwt_secret = "..."`
5. **Senhas:** Padrão `password = "..."` (exceto em testes)

### Como Usar Secrets Corretamente

```javascript
// ❌ ERRADO
const apiKey = "sk_live_abc123...";

// ✅ CORRETO
const apiKey = process.env.API_KEY;
```

### Arquivo .env.example

```bash
# API Configuration
API_URL=http://localhost:3000
API_KEY=your_api_key_here

# Database
DB_HOST=localhost
DB_PORT=5432
```

## 🛠️ Comandos Úteis

### Remover .env do Git

```bash
# Remover do staging
git rm --cached .env

# Remover do histórico (CUIDADO!)
git filter-branch --force --index-filter \
  "git rm --cached --ignore-unmatch .env" \
  --prune-empty --tag-name-filter cat -- --all
```

### Atualizar Dependências Vulneráveis

```bash
# Tentar correção automática
npm audit fix

# Correção forçada (pode quebrar compatibilidade)
npm audit fix --force

# Ver detalhes
npm audit
```

### Executar Testes com Cobertura

```bash
npm test -- --coverage
```

## 📁 Estrutura de Arquivos

```
.manus/
├── README.md                    # Este arquivo
├── audit-script.py              # Auditoria completa
├── audit-watch.py               # Monitoramento contínuo
├── auto-fix.py                  # Correções automáticas
├── validate-commands.sh         # Validação de comandos
├── pre-commit-hook.sh           # Hook de pre-commit
├── dashboard.html               # Dashboard visual
├── audit-YYYYMMDD-HHMMSS.json  # Resultados de auditoria
└── auto-fix-report-*.json      # Relatórios de correções
```

## 🔄 Fluxo de Trabalho Recomendado

### Desenvolvimento Diário

1. **Antes de começar:** Execute `npm run validate`
2. **Durante o desenvolvimento:** Watch mode rodando em background
3. **Antes de commitar:** Pre-commit hook valida automaticamente
4. **Após commit:** GitHub Action valida no CI

### Auditoria Semanal

1. Execute `npm run audit:security`
2. Revise o dashboard em `.manus/dashboard.html`
3. Corrija issues críticos imediatamente
4. Planeje correção de warnings para a sprint

### Auditoria Mensal

1. Execute auditoria completa
2. Atualize dependências vulneráveis
3. Revise e atualize as regras de auditoria
4. Execute `npm run fix:auto` para manutenção

## 🚨 Alertas e Notificações

### Health Score < 60

Quando o Health Score cai abaixo de 60, o sistema emite um alerta:

```
🚨 ALERTA: HEALTH SCORE CRÍTICO!
Health Score atual: 45/100
Issues críticos: 3

⚠️  AÇÃO NECESSÁRIA:
  1. Revise os issues críticos imediatamente
  2. Execute correções antes do próximo deploy
  3. Verifique o dashboard em .manus/dashboard.html
```

### Integração com Slack/Discord (Futuro)

O sistema está preparado para integração com ferramentas de comunicação. Para implementar:

1. Configure webhook do Slack/Discord
2. Adicione URL do webhook como variável de ambiente
3. Descomente as funções de alerta em `audit-watch.py`

## 📚 Referências

- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [GitHub Secret Scanning](https://docs.github.com/en/code-security/secret-scanning)
- [npm audit](https://docs.npmjs.com/cli/v8/commands/npm-audit)
- [Jest Best Practices](https://jestjs.io/docs/getting-started)

## 🤝 Contribuindo

Para adicionar novas regras ou melhorias ao sistema de auditoria:

1. Edite o script apropriado em `.manus/`
2. Teste localmente
3. Atualize este README
4. Faça commit das mudanças

## 📝 Changelog

### v1.0.0 (2025-11-29)
- ✅ Auditoria completa implementada
- ✅ MVP de bloqueio (pre-commit + CI)
- ✅ Watch mode para monitoramento contínuo
- ✅ Auto-fix para correções automáticas
- ✅ Dashboard de visualização
- ✅ Scripts integrados ao package.json

## 📄 Licença

Este sistema de auditoria é parte do projeto Elevare-FullStack.

---

**Desenvolvido por:** Manus AI  
**Data:** 29 de Novembro de 2025
