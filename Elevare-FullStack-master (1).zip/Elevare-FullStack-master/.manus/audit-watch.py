#!/usr/bin/env python3
"""
Auditoria Contínua com Watch Mode - Elevare FullStack
Monitora alterações em tempo real e executa auditorias automáticas
"""

import os
import sys
import time
import json
import hashlib
from pathlib import Path
from datetime import datetime
from collections import defaultdict

class WatchModeAuditor:
    def __init__(self, project_root, interval=30):
        self.project_root = Path(project_root)
        self.interval = interval
        self.file_hashes = {}
        self.audit_count = 0
        self.last_health_score = 100
        
    def calculate_file_hash(self, filepath):
        """Calcula hash MD5 de um arquivo"""
        try:
            with open(filepath, 'rb') as f:
                return hashlib.md5(f.read()).hexdigest()
        except Exception:
            return None
    
    def scan_files(self):
        """Escaneia arquivos do projeto"""
        current_hashes = {}
        extensions = ['.js', '.ts', '.jsx', '.tsx', '.json', '.env']
        exclude_dirs = {'node_modules', '.git', 'dist', 'build', 'coverage'}
        
        for root, dirs, files in os.walk(self.project_root):
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                if any(file.endswith(ext) for ext in extensions):
                    filepath = Path(root) / file
                    file_hash = self.calculate_file_hash(filepath)
                    if file_hash:
                        current_hashes[str(filepath)] = file_hash
        
        return current_hashes
    
    def detect_changes(self, current_hashes):
        """Detecta mudanças nos arquivos"""
        changes = {
            'added': [],
            'modified': [],
            'deleted': []
        }
        
        # Arquivos novos ou modificados
        for filepath, file_hash in current_hashes.items():
            if filepath not in self.file_hashes:
                changes['added'].append(filepath)
            elif self.file_hashes[filepath] != file_hash:
                changes['modified'].append(filepath)
        
        # Arquivos deletados
        for filepath in self.file_hashes:
            if filepath not in current_hashes:
                changes['deleted'].append(filepath)
        
        return changes
    
    def quick_security_scan(self, changed_files):
        """Escaneia rapidamente apenas os arquivos alterados"""
        issues = []
        
        patterns = {
            "supabase_key": r"eyJhbGciOiJIUzI1NI[A-Za-z0-9_-]{100,}",
            "api_key": r"(api[_-]?key|apikey)[\s]*[:=][\s]*['\"]([A-Za-z0-9_-]{20,})['\"]",
            "jwt_secret": r"(jwt[_-]?secret)[\s]*[:=][\s]*['\"]([^'\"]{10,})['\"]",
            "password": r"(password|passwd|pwd)[\s]*[:=][\s]*['\"]([^'\"]{8,})['\"]"
        }
        
        import re
        
        for filepath in changed_files:
            try:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                for secret_type, pattern in patterns.items():
                    if re.search(pattern, content, re.IGNORECASE):
                        issues.append({
                            'type': secret_type,
                            'file': filepath,
                            'severity': 'CRITICAL'
                        })
            except Exception:
                pass
        
        return issues
    
    def run_full_audit(self):
        """Executa auditoria completa usando o script principal"""
        import subprocess
        
        try:
            result = subprocess.run(
                ['python3.11', str(self.project_root / '.manus' / 'audit-script.py')],
                cwd=self.project_root,
                capture_output=True,
                text=True,
                timeout=60
            )
            
            # Ler o último arquivo de auditoria
            audit_files = sorted(self.project_root.glob('.manus/audit-*.json'))
            if audit_files:
                with open(audit_files[-1], 'r') as f:
                    audit_data = json.load(f)
                    return audit_data.get('health_score', 0)
            
            return 0
        except Exception as e:
            print(f"❌ Erro ao executar auditoria: {e}")
            return 0
    
    def send_alert(self, health_score, issues):
        """Envia alerta se health score < 60"""
        if health_score < 60:
            print("\n" + "="*60)
            print("🚨 ALERTA: HEALTH SCORE CRÍTICO!")
            print("="*60)
            print(f"Health Score atual: {health_score}/100")
            print(f"Issues críticos: {len(issues)}")
            print("\n⚠️  AÇÃO NECESSÁRIA:")
            print("  1. Revise os issues críticos imediatamente")
            print("  2. Execute correções antes do próximo deploy")
            print("  3. Verifique o dashboard em .manus/dashboard.html")
            print("="*60 + "\n")
            
            # Em produção, aqui enviaria para Slack/Discord
            # self.send_slack_alert(health_score, issues)
            # self.send_discord_alert(health_score, issues)
    
    def watch(self):
        """Modo watch - monitora alterações continuamente"""
        print("="*60)
        print("👁️  MANUS WATCH MODE - AUDITORIA CONTÍNUA")
        print("="*60)
        print(f"📁 Projeto: {self.project_root}")
        print(f"⏱️  Intervalo: {self.interval}s")
        print(f"🔄 Pressione Ctrl+C para parar")
        print("="*60 + "\n")
        
        # Scan inicial
        print("🔍 Executando scan inicial...")
        self.file_hashes = self.scan_files()
        print(f"✅ {len(self.file_hashes)} arquivos monitorados\n")
        
        try:
            while True:
                time.sleep(self.interval)
                
                # Escanear arquivos
                current_hashes = self.scan_files()
                changes = self.detect_changes(current_hashes)
                
                total_changes = len(changes['added']) + len(changes['modified']) + len(changes['deleted'])
                
                if total_changes > 0:
                    self.audit_count += 1
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    
                    print(f"\n[{timestamp}] 🔄 Mudanças detectadas (Auditoria #{self.audit_count})")
                    print(f"  • Adicionados: {len(changes['added'])}")
                    print(f"  • Modificados: {len(changes['modified'])}")
                    print(f"  • Deletados: {len(changes['deleted'])}")
                    
                    # Quick scan nos arquivos alterados
                    changed_files = changes['added'] + changes['modified']
                    if changed_files:
                        print("\n  🔍 Escaneando mudanças...")
                        issues = self.quick_security_scan(changed_files)
                        
                        if issues:
                            print(f"  🚨 {len(issues)} issue(s) de segurança detectado(s)!")
                            for issue in issues[:3]:  # Mostrar apenas os 3 primeiros
                                print(f"    • {issue['type']} em {Path(issue['file']).name}")
                            
                            # Executar auditoria completa
                            print("\n  📊 Executando auditoria completa...")
                            health_score = self.run_full_audit()
                            
                            print(f"  💯 Health Score: {health_score}/100")
                            
                            # Enviar alerta se necessário
                            if health_score < 60:
                                self.send_alert(health_score, issues)
                            
                            self.last_health_score = health_score
                        else:
                            print("  ✅ Nenhum issue de segurança detectado")
                    
                    # Atualizar hashes
                    self.file_hashes = current_hashes
                else:
                    # Heartbeat a cada 5 minutos
                    if self.audit_count % 10 == 0:
                        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        print(f"[{timestamp}] 💚 Sistema monitorando... (Health Score: {self.last_health_score}/100)")
                
        except KeyboardInterrupt:
            print("\n\n" + "="*60)
            print("🛑 Watch mode interrompido")
            print(f"📊 Total de auditorias executadas: {self.audit_count}")
            print(f"💯 Último Health Score: {self.last_health_score}/100")
            print("="*60)
            sys.exit(0)

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Auditoria Contínua - Elevare FullStack')
    parser.add_argument('--interval', type=int, default=30, help='Intervalo de verificação em segundos (padrão: 30)')
    parser.add_argument('--project-root', type=str, default='/home/ubuntu/Elevare-FullStack', help='Raiz do projeto')
    
    args = parser.parse_args()
    
    auditor = WatchModeAuditor(args.project_root, args.interval)
    auditor.watch()

if __name__ == "__main__":
    main()
