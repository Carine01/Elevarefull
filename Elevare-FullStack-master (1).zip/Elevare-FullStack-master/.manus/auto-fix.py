#!/usr/bin/env python3
"""
Auto-Fix Script - Elevare FullStack
Corrige automaticamente problemas comuns em testes e configurações
"""

import os
import re
import json
from pathlib import Path
from datetime import datetime

class AutoFixer:
    def __init__(self, project_root):
        self.project_root = Path(project_root)
        self.fixes_applied = []
        
    def fix_jest_config(self):
        """Corrige configurações do Jest"""
        print("🔧 Verificando configuração do Jest...")
        
        jest_config_path = self.project_root / 'frontend-landing' / 'jest.config.js'
        
        if jest_config_path.exists():
            with open(jest_config_path, 'r') as f:
                content = f.read()
            
            fixes = []
            
            # Verificar se tem testEnvironment
            if 'testEnvironment' not in content:
                content = content.replace(
                    'module.exports = {',
                    "module.exports = {\n    testEnvironment: 'jsdom',"
                )
                fixes.append("Adicionado testEnvironment: 'jsdom'")
            
            # Verificar se tem setupFilesAfterEnv
            if 'setupFilesAfterEnv' not in content:
                # Verificar se jest.setup.js existe
                setup_file = self.project_root / 'frontend-landing' / 'jest.setup.js'
                if not setup_file.exists():
                    # Criar jest.setup.js
                    setup_content = """/**
 * Jest Setup File
 * Configurações globais para testes
 */

// Mock de APIs do navegador
global.fetch = jest.fn();

// Mock de localStorage
const localStorageMock = {
    getItem: jest.fn(),
    setItem: jest.fn(),
    removeItem: jest.fn(),
    clear: jest.fn(),
};
global.localStorage = localStorageMock;

// Mock de sessionStorage
global.sessionStorage = localStorageMock;

// Mock de window.location
delete window.location;
window.location = { href: '', reload: jest.fn() };

// Limpar mocks após cada teste
afterEach(() => {
    jest.clearAllMocks();
});
"""
                    with open(setup_file, 'w') as f:
                        f.write(setup_content)
                    fixes.append("Criado jest.setup.js")
            
            if fixes:
                with open(jest_config_path, 'w') as f:
                    f.write(content)
                
                self.fixes_applied.extend(fixes)
                print(f"  ✅ {len(fixes)} correção(ões) aplicada(s) no Jest")
                for fix in fixes:
                    print(f"    • {fix}")
            else:
                print("  ✅ Configuração do Jest OK")
        else:
            print("  ⚠️  jest.config.js não encontrado")
    
    def fix_test_mocks(self):
        """Adiciona mocks faltantes em arquivos de teste"""
        print("\n🔧 Verificando mocks em testes...")
        
        test_files = list(self.project_root.glob('**/tests/**/*.test.js'))
        test_files.extend(self.project_root.glob('**/tests/**/*.spec.js'))
        
        fixes_count = 0
        
        for test_file in test_files:
            if 'node_modules' in str(test_file):
                continue
            
            try:
                with open(test_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                modified = False
                
                # Verificar se usa fetch sem mock
                if 'fetch(' in content and 'jest.fn()' not in content and 'mock' not in content.lower():
                    # Adicionar mock de fetch no início do arquivo
                    if 'beforeEach' not in content:
                        mock_setup = "\n\nbeforeEach(() => {\n    global.fetch = jest.fn();\n});\n\n"
                        # Inserir após os imports
                        import_end = content.rfind('import ')
                        if import_end != -1:
                            next_line = content.find('\n', import_end)
                            content = content[:next_line] + mock_setup + content[next_line:]
                            modified = True
                            fixes_count += 1
                
                # Verificar se usa localStorage sem mock
                if 'localStorage' in content and 'jest.fn()' not in content:
                    if 'beforeEach' in content and 'localStorage' not in content[:content.find('beforeEach')]:
                        # Adicionar mock dentro do beforeEach existente
                        beforeEach_pos = content.find('beforeEach(() => {')
                        if beforeEach_pos != -1:
                            insert_pos = beforeEach_pos + len('beforeEach(() => {')
                            content = content[:insert_pos] + "\n    global.localStorage = { getItem: jest.fn(), setItem: jest.fn(), removeItem: jest.fn() };" + content[insert_pos:]
                            modified = True
                            fixes_count += 1
                
                if modified:
                    with open(test_file, 'w', encoding='utf-8') as f:
                        f.write(content)
                    
                    self.fixes_applied.append(f"Mocks adicionados em {test_file.name}")
            
            except Exception as e:
                print(f"  ⚠️  Erro ao processar {test_file.name}: {e}")
        
        if fixes_count > 0:
            print(f"  ✅ {fixes_count} arquivo(s) de teste corrigido(s)")
        else:
            print("  ✅ Mocks de teste OK")
    
    def fix_env_files(self):
        """Remove arquivos .env do staging e adiciona ao .gitignore"""
        print("\n🔧 Verificando arquivos .env...")
        
        env_files = []
        for root, dirs, files in os.walk(self.project_root):
            if 'node_modules' in root or '.git' in root:
                continue
            
            for file in files:
                if file.startswith('.env') and not file.endswith('.example'):
                    env_files.append(Path(root) / file)
        
        if env_files:
            print(f"  ⚠️  {len(env_files)} arquivo(s) .env encontrado(s)")
            print("  📝 Comandos para remover do Git:")
            for env_file in env_files:
                rel_path = env_file.relative_to(self.project_root)
                print(f"    git rm --cached {rel_path}")
            
            # Verificar .gitignore
            gitignore_path = self.project_root / '.gitignore'
            if gitignore_path.exists():
                with open(gitignore_path, 'r') as f:
                    gitignore_content = f.read()
                
                patterns_to_add = []
                
                if '.env' not in gitignore_content:
                    patterns_to_add.append('.env')
                if '.env.local' not in gitignore_content:
                    patterns_to_add.append('.env.local')
                if '.env.*.local' not in gitignore_content:
                    patterns_to_add.append('.env.*.local')
                
                if patterns_to_add:
                    with open(gitignore_path, 'a') as f:
                        f.write('\n# Environment files\n')
                        for pattern in patterns_to_add:
                            f.write(f'{pattern}\n')
                    
                    print(f"  ✅ {len(patterns_to_add)} padrão(ões) adicionado(s) ao .gitignore")
                    self.fixes_applied.append(f"Padrões .env adicionados ao .gitignore")
        else:
            print("  ✅ Nenhum arquivo .env encontrado")
    
    def fix_package_json_scripts(self):
        """Adiciona scripts úteis ao package.json"""
        print("\n🔧 Verificando scripts do package.json...")
        
        package_json_path = self.project_root / 'package.json'
        
        if package_json_path.exists():
            with open(package_json_path, 'r') as f:
                package_data = json.load(f)
            
            scripts = package_data.get('scripts', {})
            scripts_added = []
            
            # Scripts de auditoria
            if 'audit:security' not in scripts:
                scripts['audit:security'] = 'python3 .manus/audit-script.py'
                scripts_added.append('audit:security')
            
            if 'audit:watch' not in scripts:
                scripts['audit:watch'] = 'python3 .manus/audit-watch.py'
                scripts_added.append('audit:watch')
            
            if 'validate' not in scripts:
                scripts['validate'] = 'bash .manus/validate-commands.sh'
                scripts_added.append('validate')
            
            if 'fix:auto' not in scripts:
                scripts['fix:auto'] = 'python3 .manus/auto-fix.py'
                scripts_added.append('fix:auto')
            
            if scripts_added:
                package_data['scripts'] = scripts
                
                with open(package_json_path, 'w') as f:
                    json.dump(package_data, f, indent=2)
                
                print(f"  ✅ {len(scripts_added)} script(s) adicionado(s):")
                for script in scripts_added:
                    print(f"    • npm run {script}")
                
                self.fixes_applied.append(f"{len(scripts_added)} scripts adicionados ao package.json")
            else:
                print("  ✅ Scripts do package.json OK")
        else:
            print("  ⚠️  package.json não encontrado")
    
    def generate_report(self):
        """Gera relatório de correções aplicadas"""
        report_path = self.project_root / '.manus' / f'auto-fix-report-{datetime.now().strftime("%Y%m%d-%H%M%S")}.json'
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'fixes_applied': self.fixes_applied,
            'total_fixes': len(self.fixes_applied)
        }
        
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2)
        
        return report_path
    
    def run(self):
        """Executa todas as correções"""
        print("="*60)
        print("🔧 AUTO-FIX - ELEVARE FULLSTACK")
        print("="*60)
        
        self.fix_jest_config()
        self.fix_test_mocks()
        self.fix_env_files()
        self.fix_package_json_scripts()
        
        print("\n" + "="*60)
        print(f"✅ Auto-fix concluído!")
        print(f"📊 Total de correções: {len(self.fixes_applied)}")
        
        if self.fixes_applied:
            print("\n📋 Correções aplicadas:")
            for i, fix in enumerate(self.fixes_applied, 1):
                print(f"  {i}. {fix}")
            
            report_path = self.generate_report()
            print(f"\n📁 Relatório salvo em: {report_path}")
        else:
            print("\n✅ Nenhuma correção necessária!")
        
        print("="*60)

if __name__ == "__main__":
    fixer = AutoFixer("/home/ubuntu/Elevare-FullStack")
    fixer.run()
